﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace BubbleSort;

public class Program{

    public static void Main(string[] args)
    {
        
        int[] arr={1,5,4,3,2,1,0,2,3};

        int length=arr.Length;

        BubbleSort(arr);
        PrintArray(arr);

    }

    public static void PrintArray(int[] arr)
    {
        foreach(int x in arr){
            System.Console.Write(x+" ");
        }
    }

    public static void BubbleSort(int[] arr)
    {
        int temp;
       
        for (int i=0; i<arr.Length;i++){

            for(int j=i+1; j<arr.Length;j++){

                if(arr[i]>arr[j]){
                    //Swap
                    temp=arr[j];
                    arr[j]=arr[i];
                    arr[i]=temp;
                }

            }

        }

        //Printing theb values

       

    }
}