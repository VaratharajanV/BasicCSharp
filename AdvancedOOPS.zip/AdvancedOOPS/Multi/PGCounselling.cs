using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Multi
{
    public enum Gender{male,female,transgender}
    public class PGCounselling :IHSCInfo,IUGInfo
    {
       /*Class PGCouncelling inherits IHSCInfo, IUGInfo
Properties: ApplicationID, DateOfApplication, FeeStatus (bool).
Method: PayFees ->500 Rs.
       */ 

       public static int s_applicationID=1000;

        

       

        public string Name { get; set; }
        public long AdharNumber { get; set; }
        public string FatherName { get; set; }
        public long Phone { get; set; }
        public DateTime DOB { get; set; }
        public Gender Gender { get; set; }
         public long HSCMarksheetNumber { get; set; }
        public int Physics { get; set; }
        public int Chemistry { get; set; }
        public int Maths { get; set; }
        public double HSCTotal { get; set; }
        public double HSCPercentage{get; set; }
         public long UGMarksheetNumber { get; set; }
        public int Sem1  { get; set; }
        public int Sem2 { get; set; }
        public int Sem3 { get; set; }
        public int Sem4 { get; set; }
        public double UGTotal { get; set; }
        public double UGPercentage { get; set; }

        public string ApplicationID { get; }
       public string DateOfApplication { get; set; }
       public bool FeeStatus { get; set; }
        public PGCounselling(string name, long adharNumber, string fatherName, long phone, DateTime dOB, Gender gender, long hSCMarksheetNumber, int physics, int chemistry, int maths, double hSCTotal, double hSCPercentage, long uGMarksheetNumber, int sem1, int sem2, int sem3, int sem4, double uGTotal, double uGPercentage, string dateOfApplication, bool feeStatus)
        {
            s_applicationID++;
            ApplicationID="AD"+s_applicationID;
            Name = name;
            AdharNumber = adharNumber;
            FatherName = fatherName;
            Phone = phone;
            DOB = dOB;
            Gender = gender;
            HSCMarksheetNumber = hSCMarksheetNumber;
            Physics = physics;
            Chemistry = chemistry;
            Maths = maths;
            HSCTotal = hSCTotal;
            HSCPercentage = hSCPercentage;
            UGMarksheetNumber = uGMarksheetNumber;
            Sem1 = sem1;
            Sem2 = sem2;
            Sem3 = sem3;
            Sem4 = sem4;
            UGTotal = uGTotal;
            UGPercentage = uGPercentage;
            //ApplicationID = applicationID;
            DateOfApplication = dateOfApplication;
            FeeStatus = feeStatus;
        }

        public void TotalMark(){
            HSCTotal=Physics+Chemistry+Maths;
        }
         public void TotalPercentage(){
            HSCPercentage=(Physics+Chemistry+Maths)/3;
         }
         public void TotalMarkCollege(){
            UGTotal=Sem1+Sem2+Sem3+Sem4;
         }
        public void TotalPercentageCollege(){
            UGPercentage=(Sem1+Sem2+Sem3+Sem4)/4;
        }

         public  void PayFees(int amount){
           // int amount=Convert.ToInt32(Console.ReadLine());
            if (amount>=500){
                FeeStatus=true;
               
            }
       

    }
}
}