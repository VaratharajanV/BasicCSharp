using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Multi
{
    public interface IUGInfo: IPersonalInfo
    {
      /*Interface IUGInfo: Inhertis IPersonalInfo
Properties: UGMarksheetNumber, Sem1, Sem2, Sem3, Sem4 Marks, Total and Percentage
Methods: CalculateUG -> Total, percentage.
      */
         long UGMarksheetNumber { get; set; }
        int Sem1  { get; set; }
        int Sem2 { get; set; }
         int Sem3 { get; set; }
         int Sem4 { get; set; }
         double UGTotal { get; set; }
        double UGPercentage { get; set; }
         void TotalMarkCollege();
         void TotalPercentageCollege();
       

    }
}