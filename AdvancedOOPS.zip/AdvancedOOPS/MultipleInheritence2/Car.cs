using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence2
{
    public class Car
    {
        private static int s_carID=2000;
        
        /*Property: FuleType, NumberOfSeats, Color, TankCapacity, NumberOfKmDriven
Method: CalculateMilage
*/
        public string CarID { get; set; }
        public string FuleType { get; set; }
        public int NumberOfSeats { get; set; }
        public string Color { get; set; }
        public double TankCapacity { get; set; }
        public double  NumberOfKmDriven { get; set; }
        public Car(string fuleType, int numberOfSeats, string color, double tankCapacity, double numberOfKmDriven)
        {
            s_carID++;
            CarID="Car"+s_carID;
            FuleType = fuleType;
            NumberOfSeats = numberOfSeats;
            Color = color;
            TankCapacity = tankCapacity;
            NumberOfKmDriven = numberOfKmDriven;
        }
         public Car(string carID,string fuleType, int numberOfSeats, string color, double tankCapacity, double numberOfKmDriven)
        {
           
            CarID=carID;
            FuleType = fuleType;
            NumberOfSeats = numberOfSeats;
            Color = color;
            TankCapacity = tankCapacity;
            NumberOfKmDriven = numberOfKmDriven;
        }
        public  void CalculateMilage(){
            System.Console.WriteLine("Milege Calculated Succeessfully ....!");
        }

    }
}