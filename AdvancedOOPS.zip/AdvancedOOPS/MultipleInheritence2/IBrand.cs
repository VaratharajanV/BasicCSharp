using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence2
{
    public interface IBrand
    {
      /*Interface  IBrand
Property: BrandName, ModelName
      */  
       string BrandName { get; set; }
       string ModelName { get; set; }
       

    }
}