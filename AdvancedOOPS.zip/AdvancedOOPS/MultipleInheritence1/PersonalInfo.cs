using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence1
{
    public enum Gender{male,female,transgender}
    public enum MaritalStatus { Married,Single }
    public class PersonalInfo
    {
        private static int s_userID=1000;
        

        //Properties: UserID, Name, Gender, DOB, phone, mobile, Marital details – Married/single
        public string UserID { get;}
        public Gender Gender { get; set; }
        public DateTime DOB { get; set; }
        public long Phone { get; set; }
        public long Mobile { get; set; }
        public MaritalStatus MaritalStatus { get; set; }

        public PersonalInfo(Gender gender, DateTime dOB, long phone, long mobile, MaritalStatus maritalStatus)
        {
            s_userID++;
            UserID="UID"+s_userID;
            Gender = gender;
            DOB = dOB;
            Phone = phone;
            Mobile = mobile;
            MaritalStatus = maritalStatus;
        }
        public PersonalInfo(string userID,Gender gender, DateTime dOB, long phone, long mobile, MaritalStatus maritalStatus)
        {
            
            UserID=userID;
            Gender = gender;
            DOB = dOB;
            Phone = phone;
            Mobile = mobile;
            MaritalStatus = maritalStatus;
        }
    }
}