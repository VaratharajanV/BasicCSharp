﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace SelectionSort;

public class Program{
    public static void Main(string[] args)
    {
        
        int[] arr=new int[6]{2,1,5,34,0,2};

        SelectionSort(arr);

        PrintArray(arr);


    }

    public static void PrintArray(int[] arr)
    {

        foreach(int x in arr){
            System.Console.Write(" "+x);
        }

       
    }

    public static void SelectionSort(int[] arr)
    {
        // int minvalue=0;
         int temp;
        
        for(int i=0;i<arr.Length-1;i++){

           
            int min=i;
            for(int j=i+1;j<arr.Length;j++){
                 {
                    if(arr[min] > arr[j])
                    {
                        min = j;
                    }
                 }

            }
            temp=arr[min];
            arr[min]=arr[i];
            arr[i]=temp;
            

        }

    }
}