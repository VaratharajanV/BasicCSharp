using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EBBillCalculator
{
    public class EBBills
    {
        //- Meter ID -(EB1001), Username, Phone number, Mail id, Units Used =0
        private int s_meterID=1000;

        public string MeterID { get; }
        public string UserName { get; set; }
        public long Phone { get; set; }
        public string MailID { get; set; }
        public double UnitsUsed { get; set; }

         public EBBills( string userName, long phone, string mailID, double unitsUsed)
        {
            s_meterID++;
            MeterID = "EB"+s_meterID;
            UserName = userName;
            Phone = phone;
            MailID = mailID;
            UnitsUsed = unitsUsed;
        }

    }
}