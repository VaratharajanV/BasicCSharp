﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace Polymorphism1;
/*
Create a set of Multiply method inside a class

Method with one argument and display the Square value of a given number.
Method with 2 arguments with same argument type and display result.
Method with 3 arguments with same argument type and display the result.
Method with 2 arguments with different argument type and display result.
Method with 3 arguments with different argument type and display the result.
Call the above 5 methods and print the results.
*/
public class Program{
    public static void Main(string[] args)
    {
       
        DisplaySquare(5);
        DisplaySquare(2,3);
        DisplaySquare(2,3,4);
        DisplaySquare(1,2.3);
        DisplaySquare(1,2.3,3.6);

        
    }

    public static void DisplaySquare(int number, double number1, double number2)
    {
        //throw new NotImplementedException();
         int Square=number*number;
        System.Console.WriteLine($"Square value of {number} is "+Square);
         double Square1=number1*number1;
        System.Console.WriteLine($"Square value of {number1} is "+Square1);
         double Square2=number2*number2;
        System.Console.WriteLine($"Square value of {number2} is "+Square2);
    }

    public static void DisplaySquare(int number)
    {
        //double Square=number1*number1;
         int Square=number*number;
        System.Console.WriteLine($"Square value of {number} is "+Square);
        //throw new NotImplementedException();

    }

    public static void DisplaySquare(int number, double number1)
    {
        double Square1=number1*number1;
         int Square=number*number;
        System.Console.WriteLine($"Square value of {number} is "+Square);
        System.Console.WriteLine($"Square value of {number1} is "+Square1);

        //throw new NotImplementedException();
    }

    public static void DisplaySquare(int number, int number1)
    {

        //throw new NotImplementedException();
        int Square=number*number;
        int Square1=number1*number1;
        System.Console.WriteLine($"Square value of {number} is "+Square);
        System.Console.WriteLine($"Square value of {number1} is "+Square1);

    }

    public static void DisplaySquare(int number, int number1,int number2)
    {
            int Square=number*number;
            int Square1=number1*number1;
            int Square2=number2*number2;
            
            System.Console.WriteLine($"Square value of {number} is "+Square);
            System.Console.WriteLine($"Square value of {number1} is "+Square1);
            System.Console.WriteLine($"Square value of {number2} is "+Square2);
    }
    
    
}