using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass
{
    public  class Hack :EmployeeInfo
    {
        public Hack(string name, string fatherName, long mobile, string mail, Gender gender, string password, int keyInfo,string storeUserID, string storePassword):base(name,fatherName,mobile,mail, gender,password,keyInfo)
        {
            StoreUserID = storeUserID;
            StorePassword = storePassword;
        }

        //Properties: StoreUserID, StorePassword
        //Method: UpdateStorePassword  
        public string StoreUserID { get; set; }
        public string StorePassword { get; set; }

        public string UpdateStorePassword(){
            string emptyString="ID : "+StoreUserID+"Password: "+StorePassword;
            return emptyString;
           
        }
        
    }
}