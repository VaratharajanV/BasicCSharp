using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass
{
    public sealed class EmployeeInfo : PersonalInfo
    {
        //Properties: UserID, Password, KeyInfo = 100
//Methods: UpdateKey, UpdatePassword
        private static int s_userID=2000;

        private int keyInfo=100;

       

        public string UserID { get; set;}
        public string Password { get; set; }
        public int KeyInfo { get; set; }

         public EmployeeInfo(string name, string fatherName, long mobile, string mail, Gender gender, string password, int keyInfo):base(name,fatherName,mobile,mail,gender)
        {
            s_userID++;
            UserID = "UID"+s_userID;
            Password = password;
            KeyInfo = keyInfo;
        }
        public int UpdateKey(){
           return KeyInfo;
        }
        public string UpdatePassword(){
          return Password;
        }

        
    }
}