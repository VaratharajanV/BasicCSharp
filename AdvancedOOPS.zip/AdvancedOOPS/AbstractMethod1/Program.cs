﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace AbstractMethod1;
public class Program{
    public static void Main(string[] args)
    {
        /*1.	Create an application for Car Information 
Class Car:
Field: No. of wheels=4, No.Of.Doors = 4, 
Properties: Engine type -Petrol,diesel,cng, No.Of.Seats, Price, CarType -hatchback, sedan,  suv
Abstract methods: get engine type, get no. of seats, get price, get car type
Class MaruthiSwift : inherit Cars
override methods: get engine type, get no. of seats, get price, get car type
class SuzukiCiaz: inherit Cars
override methods: get engine type, get no. of seats, get price, get car type
Requirement : Create objects for maruthi swift and Suzuki ciaz and call abstract methods to get information and display the details.        */

        MaruthiSwift maruti=new MaruthiSwift(EngineType.Petrol,4,6712322,CarType.sedan);
        System.Console.WriteLine(maruti.GetEngineType());
        System.Console.WriteLine(maruti.GetCarType());
        System.Console.WriteLine(maruti.GetNoSeats());
        System.Console.WriteLine(maruti.GetPrice());
        System.Console.WriteLine(maruti.GetType());
        //System.Console.WriteLine(""+maruti.CarType);
        MaruthiSwift maruthi2=new MaruthiSwift(EngineType.Petrol,4,63821216938,CarType.hatchback);
        System.Console.WriteLine(maruthi2.GetEngineType());


    }
}
