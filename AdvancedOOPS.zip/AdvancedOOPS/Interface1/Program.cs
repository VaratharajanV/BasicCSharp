﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using Interface1;
namespace interface1;
public class interface1{

    public static void Main(string[] args)
    {
        /*1.	Create An application that logs various animal info
Interface : IAnimal
Property: Name, Habitat, Eating Habit 
Class Dog interface IAnimal
Class Duck interface IAnimal
Requirement : Create two dog objects and duck objects and display object info of four in Program.cs.
        */
        Dog dog=new Dog("Eddy","Land","Mouth");
        System.Console.WriteLine(dog.EatingHabit);
        System.Console.WriteLine(dog.Habitat);
        System.Console.WriteLine(dog.Name);

        Dog dog2=new Dog("Monkye","Tree","Mouth");
        System.Console.WriteLine(dog2.EatingHabit);
        System.Console.WriteLine(dog2.Habitat);
        System.Console.WriteLine(dog2.Name);




    }

}