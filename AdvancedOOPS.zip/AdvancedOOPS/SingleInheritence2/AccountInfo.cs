using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
public enum BranchName{AnnaNagar,ChetPet,NungamBakkam}

namespace SingleInheritence2
{
    public class AccountInfo:PersonalInfo
    {
        

        /*Class AccountInfo : Inherit PersonalInfo
Properties: AccountNumber, BranchName, IFSCCode, Balance
*/
        public long AccountNumber { get; set; }
        public BranchName BranchName { get; set; }
        public string IFSCCode { get; set; }
        public double Balance { get; set; }

        public AccountInfo(string name, string fatherName, long phone, DateTime dOB, Gender gender,long accountNumber, BranchName branchName, string iFSCCode, double balance ):base(name,fatherName,phone,dOB,gender)
        {
            AccountNumber = accountNumber;
            BranchName = branchName;
            IFSCCode = iFSCCode;
            Balance = balance;
        }

        public void Deposit(double amount){
            Balance+=amount;
        }
         public void Withdraw(double amount){
            Balance-=amount;
        }
    }
}