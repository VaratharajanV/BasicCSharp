﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace MultilevelInheritence;
public class Program{
    public static void Main(string[] args)
    {
        /*1.	Program for getting showing student details:

Class PersonalInfo:
Properties: UserID, Name, FatherName,Phone,Mail, dob,Gender
Constructor to assign values
Class StudentInfo: inherits PersonalInfo
Propeties: RegistrationID, Standard, Branch, AcadamicYear
Class HSCDetails: Inherits StudentInfo
	Properties: HSCMarksheetID, Physics, Chemistry, Maths, Total, Percentage marks
	Methods:  Calculate – Total and percentage.
Requirement : Have to create two objects for each above classes (ID’s are auto incremented) in Program.cs and have to display the details and have to calculate total and percentage and have to display the details.

        */
        PersonalInfo person1=new PersonalInfo("raja","Venkatesan",6382634152,"varatharajan60782@gmail.com",new DateTime(04/07/2002),Gender.male);
        PersonalInfo person2=new PersonalInfo("ramar","VelPndian",3432634152,"rajan60782@gmail.com",new DateTime(05/07/2002),Gender.male);
        StudentInfo student1=new StudentInfo(person1.UserID,person1.Name,person1.FatherName,person1.Phone,person1.Mail,person1.DOB,person1.Gender,Standard.twelth,Branch.CIVIL,2023);
        StudentInfo student2=new StudentInfo(person2.UserID,person2.Name,person2.FatherName,person2.Phone,person2.Mail,person2.DOB,person2.Gender,Standard.twelth,Branch.CSE,2023);
        HSCDetails hSC1=new HSCDetails(student1.UserID,student1.RegistrationID,student1.Name,student1.FatherName,student1.Phone,student1.Mail,student1.DOB,student1.Gender,student1.Standard,student1.Branch,student1.AcadamicYear,98,89,98,0,0);
        HSCDetails hSC2=new HSCDetails(student2.UserID,student2.RegistrationID,student2.Name,student2.FatherName,student2.Phone,student2.Mail,student2.DOB,student2.Gender,student2.Standard,student2.Branch,student2.AcadamicYear,60,70,60,0,0);
        System.Console.WriteLine(hSC1.UserID);
        System.Console.WriteLine(hSC1.RegistrationID);
        System.Console.WriteLine(hSC1.HSCMarkSheetID);//(hSC1.UserID);
        System.Console.WriteLine(hSC2.UserID);
        System.Console.WriteLine(hSC2.RegistrationID);
        System.Console.WriteLine(hSC2.HSCMarkSheetID);
    System.Console.WriteLine("Total Amount will be : ");
    hSC1.CalculateTotal();
    System.Console.WriteLine(hSC1.Total);
    System.Console.WriteLine("Calculate Percentage will be ");
    hSC1.CalculatePercentage();
    System.Console.WriteLine(hSC1.Percentage);
     hSC2.CalculateTotal();
    System.Console.WriteLine(hSC2.Total);
    System.Console.WriteLine("Calculate Percentage will be ");
    hSC2.CalculatePercentage();
    System.Console.WriteLine(hSC2.Percentage);

        
    }
}