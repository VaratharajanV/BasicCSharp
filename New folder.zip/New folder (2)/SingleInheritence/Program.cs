﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
namespace SingleInheritence;
public class Program{
    public static List<AccountInfo> listAccounts=new List<AccountInfo>();
    public static void Main(string[] args)
    {
        /*. Single Inheritance - Manipulate bank account details
Program to  Manipulate bank account details: Create 3 account holders Show Account Info, deposit, withdraw and Show Balance.
Class PersonalInfo:
Properties: Name, FatherName, Phone, Mail, DOB, Gender
Class AccountInfo : Inherit PersonalInfo
Properties: AccountNumber, BranchName, IFSCCode, Balance
Methods: Deposit , Withdraw

        */
        PersonalInfo person1=new PersonalInfo("raja","venakt",826227827,"varatharajan60782@gmail.com",new DateTime(04/07/2002),Gender.male);
        System.Console.WriteLine("Personal Information :");
        System.Console.WriteLine("UserID :"+person1.UserID);
        System.Console.WriteLine("Father Name :"+person1.FatherName);
        System.Console.WriteLine("DOB :"+person1.DOB);
        System.Console.WriteLine("Mail : "+person1.Mail);
        System.Console.WriteLine("Gender : "+person1.Gender);
        System.Console.WriteLine("Mobile Number : "+person1.Phone);
        System.Console.WriteLine();
         PersonalInfo person2=new PersonalInfo("raju","venkatt",637377212,"rajaraja60782",new DateTime(05/07/2002),Gender.male);
        System.Console.WriteLine("Personal Information :");
        System.Console.WriteLine("UserID :"+person2.UserID);
        System.Console.WriteLine("Father Name :"+person2.FatherName);
        System.Console.WriteLine("DOB :"+person2.DOB);
        System.Console.WriteLine("Mail : "+person2.Mail);
        System.Console.WriteLine("Gender : "+person2.Gender);
        System.Console.WriteLine("Mobile Number : "+person2.Phone);
        


        AccountInfo account1=new AccountInfo(person1.UserID,person1.Name,person1.FatherName,person1.Phone,person1.Mail,person1.DOB,person1.Gender,"920119104019",BranchName.Kilpauck,"IFSC472626",1000);
        AccountInfo account2=new AccountInfo(person2.UserID,person2.Name,person2.FatherName,person2.Phone,person1.Mail,person2.DOB,person2.Gender,"912726272",BranchName.Kilpauck,"IFSC472626",1500);
         //AccountInfo account3=new AccountInfo(person1.UserID,person1.Name,person1.FatherName,person1.Phone,person1.Mail,person1.DOB,person1.Gender,"920119104019",BranchName.Kilpauck,"IFSC472626",1000);
        
        listAccounts.Add(account1);
        listAccounts.Add(account2);
       // listAccounts.Add(account3);
        
        System.Console.WriteLine("Hello Welcome to your Bank account detail informations ");
        account1.Deposit(150);
        System.Console.WriteLine("After Deposit :"+account1.Balance);
        account2.Deposit(200);
        System.Console.WriteLine("After Deposit : "+account2.Balance);
     
        account1.Withdraw(150);
        System.Console.WriteLine("After Withdraw :"+account1.Balance);
        account2.Withdraw(200);
        System.Console.WriteLine("After Withdraw : "+account2.Balance);
      
        ShowAccountInfo();
        

    }

    public static void ShowAccountInfo()
    {
       // throw new NotImplementedException();
       foreach (AccountInfo account in listAccounts){
        System.Console.WriteLine();
        System.Console.WriteLine("UserID : "+account.UserID);
        System.Console.WriteLine("AccountID : "+account.AccountID);
            System.Console.WriteLine("Name :"+account.Name);
            System.Console.WriteLine("Father Name :"+account.FatherName);
            System.Console.WriteLine("Branch Name :"+account.BranchName);
            System.Console.WriteLine("Phone : "+account.Phone);
            System.Console.WriteLine("Gender : "+account.Gender);
            System.Console.WriteLine("Balance :"+account.Balance);
            System.Console.WriteLine("---------------------------------------");
            account.Deposit(50);
            System.Console.WriteLine("Dposited rupees 50  and your Balance :"+account.Balance);
            account.Withdraw(200);
            System.Console.WriteLine("Withdraw rupees 200 and your Balance :"+account.Balance);
            System.Console.WriteLine("Information showed for that person");

       }
    }
}