using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VirtualFunctions
{
    public class AreaCalculator
    {
        

        /*Property: Radius
Method: virtual Calculate – 3.14 *r*r
*/
        public double Radius { get; set; }
        public AreaCalculator(double radius)
        {
            Radius = radius;
        }
        public virtual double Calculate(){
            double total=3.14*Radius*Radius;
            return total;
        }
    }
}