﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace VirtualFunctions;
public class Program{
    /*1.	Create an application that calculate area and volume

Class AreaCalculator
Property: Radius
Method: virtual Calculate – 3.14 *r*r
Class VolumeCalculator inherit AreaCalculator
Property: Height
Method: override Calculate - 3.14 *r*r*h

Requirements : Create two objects for volume and area calculator based on provided values display the output

    */
    public static void Main(string[] args)
    {
         AreaCalculator area1=new AreaCalculator(3.8);

        Console.WriteLine(area1.Radius);

        System.Console.WriteLine(area1.Calculate());

        VolumeCalculator volume=new VolumeCalculator(area1.Radius,5);

        System.Console.WriteLine(volume.Height);

        System.Console.WriteLine(volume.Radius);

        System.Console.WriteLine(volume.Calculate());

    }
  

    
    
    
}
