using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace VirtualFunctions
{
    public class VolumeCalculator:AreaCalculator
    {
       

        /*Class VolumeCalculator inherit AreaCalculator
Property: Height
Method: override Calculate - 3.14 *r*r*h
*/
        public double Height { get; set; }
         public VolumeCalculator(double radius,double height):base(radius)
        {
            
            Height = height;
        }

        public override double Calculate(){
            
            double total=3.14*Radius*Radius*Height;
            return total;

        }
    }
}