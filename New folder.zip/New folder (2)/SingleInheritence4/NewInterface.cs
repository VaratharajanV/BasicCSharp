using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SingleInheritence4
{
    public interface NewInterface
    {
        public void dream();
    }
    
}