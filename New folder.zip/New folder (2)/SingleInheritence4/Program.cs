﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
namespace SingleInheritence4;
public class Program{
    public static void Main(string[] args)
    {
        /*
        4.	Program to manipulate employee worklog details:
Class Attendance:
Properties: DayID, Date, NumberOfHoursWorked.

Class SalaryInfo  
Properties: SalaryID, SalaryOfTheMonth, Month
Method: CalculateSalary-> for given month  

Class EmployeeInfo: Inherits SalaryInfo
Properties: EmployeeID, Name,FatherName,Gender,Mobile,DOB, Branch, List<Attendance>,
Method: LogAttendance - > Add the attendance details objects in List<Attendance>, CalculateSalary.

Requirement : Need to create inherited class and have to create objects (ID’s are auto incremented) for the each above SalaryInfo, EmployeeInfo classes
Create 5 attendance details objects and have to add the objects to the EmployeeInfo List<Attendance> with LogAttendance method and have to display the details and have to calculate salary CalculateSalary method with attendance details and have to calculate based on 500 per 8hr using attendance for the given user in Program.cs
        */
        List<EmployeeInfo> listEmployee=new List<EmployeeInfo>();
        Attendence attendence=new Attendence(new DateTime(15/12/2023),60);
        Salary salary1=new Salary(attendence.Date,attendence.NumberOfHoursWorked,0,7);
        EmployeeInfo employee1=new EmployeeInfo(salary1.Date,salary1.NumberOfHoursWorked,salary1.SalaryOfTheMonth,salary1.Month,"raja","venkatesan",Gender.male,8277262,new DateTime(04/07/2002),Branch.AnnaNagar);
        Salary salary2=new Salary(attendence.Date,attendence.NumberOfHoursWorked,0,7);
        listEmployee.Add(employee1);
         EmployeeInfo employee2=new EmployeeInfo(salary1.Date,salary1.NumberOfHoursWorked,salary1.SalaryOfTheMonth,salary1.Month,"raja","venkatesan",Gender.male,8277262,new DateTime(04/07/2002),Branch.AnnaNagar);
        System.Console.WriteLine(employee1.EmployeeID);
        System.Console.WriteLine(salary1.SalaryID);
        System.Console.WriteLine(employee2.EmployeeID);
        System.Console.WriteLine(salary1.SalaryID);
       

        
    }
}