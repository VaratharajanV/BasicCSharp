using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SingleInheritence4
{
    public class Attendence
    {
        //Properties: DayID, Date, NumberOfHoursWorked.
        private static int s_dayID=1000;

       

        public string DayID { get; }
        public DateTime Date { get; set; }
        public int NumberOfHoursWorked { get; set; }

         public Attendence(DateTime date, int numberOfHoursWorked)
        {
            s_dayID++;
            DayID="Day"+DayID;
            Date = date;
            NumberOfHoursWorked = numberOfHoursWorked;
        }

        
    }
}