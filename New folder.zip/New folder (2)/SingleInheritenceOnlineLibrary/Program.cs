﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace SingleInheritenceOnlineLibrary;
public class Program{
    public static void Main(string[] args)
    {
        /*3.	Online Library : 
Class DepartmentDetails:
Properties: DepartmentID, DepartmentName, Degree
Class BookInfo: Inherit DepartmentDetails
Properties: BookID, BookName, AuthorName, Price
Requirement: Need to create inherited class (ID’s are auto incremented) and have to create objects for the each above two classes and have to display the details in Program.cs
        */

        DepartmentDetails department1=new DepartmentDetails("CSE","B.E");
        DepartmentDetails department2=new DepartmentDetails("ESE","B.E");
        DepartmentDetails department3=new DepartmentDetails("EEE","B.E");
        System.Console.WriteLine("Details of Department 1");
        System.Console.WriteLine("Branch :" +department1.Degree);
        System.Console.WriteLine("Degree : "+department1.DepartmentName);
        System.Console.WriteLine("DepartmentID : "+department1.DepartmentID);
        System.Console.WriteLine("---------------------------------------");
        System.Console.WriteLine("Details of Department 2");
        System.Console.WriteLine("Branch :" +department2.Degree);
        System.Console.WriteLine("Degree : "+department2.DepartmentName);
        System.Console.WriteLine("DepartmentID : "+department2.DepartmentID);
        System.Console.WriteLine("---------------------------------------");
        System.Console.WriteLine("Details of Department 3");
        System.Console.WriteLine("Branch :" +department3.Degree);

        BookInfo book1=new BookInfo(department1.DepartmentID,department1.DepartmentName,department1.Degree,"Atomic Habits","John",2000);

        BookInfo book2=new BookInfo(department2.DepartmentID,department2.DepartmentName,department2.Degree,"4 AM wakeUp","Williams",1000);
        BookInfo book3=new BookInfo(department3.DepartmentID,department1.DepartmentName,department1.Degree,"Atomic Habits","John",2000);

        System.Console.WriteLine("---------------Details of Book 1-------------");
        System.Console.WriteLine("DepartmentID : "+book1.DepartmentID);
        System.Console.WriteLine("Department Name"+book1.DepartmentName);
        System.Console.WriteLine("Degree :"+book1.Degree);
        System.Console.WriteLine("BookID :"+book1.BookId);
        System.Console.WriteLine("AuthorName :"+book1.AuthorName);
        System.Console.WriteLine("Book name :"+book1.BookName);
        System.Console.WriteLine("Total Price of the book is : "+book1.Price);

System.Console.WriteLine("---------------Details of Book 2-------------");
        System.Console.WriteLine("DepartmentID : "+book2.DepartmentID);
        System.Console.WriteLine("Department Name"+book2.DepartmentName);
        System.Console.WriteLine("Degree :"+book2.Degree);
        System.Console.WriteLine("BookID :"+book2.BookId);
        System.Console.WriteLine("AuthorName"+book2.AuthorName);
        System.Console.WriteLine("Book name"+book2.BookName);
        System.Console.WriteLine("Total Price of the book is : "+book2.Price);
        
        System.Console.WriteLine(""+book3.BookId);
        System.Console.WriteLine(""+book3.DepartmentID);



    }
}