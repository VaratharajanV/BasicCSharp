using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SingleInheritence1
{
    public enum Standard{good,best,verybest}
public enum Branch{Chetpet,Kilpauk,Madhura}
    public class StudentInfo:PersonalInfo
    {
        public static int s_registerID=1000;

        //Propeties: RegistrationID, Standard, Branch, AcadamicYear
        public string RegistrationID { get;}
        public Standard Standard { get; set; }
        //public string UserID1 { get; }
        public Branch Branch { get; set;}
        public int AcademicYear { get; set; }
       
        public StudentInfo(string userID,string name, string fatherName, long phone, string mail, DateTime dOB, Gender gende,string registrationID, Standard standard, Branch branch, int academicYear):base(userID,name,fatherName,phone,mail,dOB,gende)
        {
            //UserID=userID;
            s_registerID++;
            RegistrationID = "Reg"+s_registerID;
            Standard = standard;
            Branch = branch;
            AcademicYear = academicYear;
        }
    }
}