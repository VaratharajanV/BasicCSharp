﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
/*1.	Program for getting and showing student details:  
Class PersonalInfo:
Properties: Name, UserID, FatherName, Phone ,Mail, DOB, Gender
Constructor to assign values

Class StudentInfo: inherits PersonalInfo
Propeties: RegistrationID, Standard, Branch, AcadamicYear
*/
using System;
namespace SingleInheritence1;
public class Program{
    public static void Main(string[] args)
    {
        PersonalInfo person1=new PersonalInfo("raja","venkatesan",928267262,"varatharajan60782@gmail.com",new DateTime(04/07/2002),Gender.male);
        PersonalInfo person2=new PersonalInfo("rajesh","venkat",92826262625,"rajan60782@gmail.com",new DateTime(05/07/2002),Gender.male);
        System.Console.WriteLine("Person 1 personal details :");
        System.Console.WriteLine("UserID"+person1.UserID);
        System.Console.WriteLine("Name "+person1.Name);
        System.Console.WriteLine("Father Name "+person1.FatherName);
        System.Console.WriteLine("Gender "+person1.Gender);
        System.Console.WriteLine("Mail "+person1.Mail);
        System.Console.WriteLine("Phone "+person1.Phone);
        System.Console.WriteLine();
        System.Console.WriteLine("Person 2 personal details :");
        System.Console.WriteLine("UserID"+person2.UserID);
        System.Console.WriteLine("Name "+person2.Name);
        System.Console.WriteLine("fatherName"+person2.FatherName);
        System.Console.WriteLine("Gender"+person2.Gender);
        System.Console.WriteLine("Mail"+person2.Mail);
        System.Console.WriteLine("Phone "+person2.Phone);
        StudentInfo student1=new StudentInfo(person1.UserID,person1.Name,person1.FatherName,person1.Phone,person1.Mail,person1.DOB,person1.Gender,"735373",Standard.good,Branch.Chetpet,2023);
        StudentInfo student2=new StudentInfo(person2.UserID,person2.Name,person2.FatherName,person2.Phone,person2.Mail,person2.DOB,person2.Gender,"735373",Standard.good,Branch.Chetpet,2023);
       // StudentInfo student3=new StudentInfo(person2.UserID,person2.Name,person2.FatherName,person2.Phone,person2.Mail,person2.DOB,person2.Gender,"735373",Standard.good,Branch.Chetpet,2023);

        System.Console.WriteLine("Information of Student 1 :");
        System.Console.WriteLine("UserID :"+student1.UserID);
        System.Console.WriteLine("Name :"+student1.Name);
        System.Console.WriteLine("Father NAME :"+student1.FatherName);
        System.Console.WriteLine("Gender :"+student1.Gender);
        System.Console.WriteLine("Mail :"+student1.Mail);
        System.Console.WriteLine("Phone :"+student1.Phone);
        System.Console.WriteLine("Academic Year"+student1.AcademicYear);
        System.Console.WriteLine("Registraion"+student1.RegistrationID);
        System.Console.WriteLine("StandaRD"+student1.Standard);
        System.Console.WriteLine("DOB"+student1.DOB);
        System.Console.WriteLine("BRANCH"+student1.Branch);
        System.Console.WriteLine("");
         System.Console.WriteLine("Information of Student 2 :");
        System.Console.WriteLine("UserID"+student2.UserID);
        System.Console.WriteLine("Name"+student2.Name);
        System.Console.WriteLine("FatherName"+student2.FatherName);
        System.Console.WriteLine("Gender"+student2.Gender);
        System.Console.WriteLine("Mail "+student2.Mail);
        System.Console.WriteLine("Phone "+student2.Phone);
        System.Console.WriteLine("Academic Year "+student2.AcademicYear);
        System.Console.WriteLine("Registration "+student2.RegistrationID);
        System.Console.WriteLine("Standard "+student2.Standard);
        System.Console.WriteLine("DOB "+student2.DOB);
        System.Console.WriteLine("Branch "+student2.Branch);

      
    }
}