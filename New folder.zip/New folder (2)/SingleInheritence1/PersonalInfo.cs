using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SingleInheritence1
{
    public enum Gender{male,female,transgender}
    public class PersonalInfo
    
    {
        private static int s_userID=1000;

      
        //Properties: Name, UserID, FatherName, Phone ,Mail, DOB, Gender
        
        public string UserID { get;}
        public string Name { get; set; }
       
        public string FatherName { get; set; }
        public long Phone { get; set; }
        public string Mail { get; set; }
        public DateTime DOB { get; set; }
        public Gender Gender { get; set; }
          public PersonalInfo(string name, string fatherName, long phone, string mail, DateTime dOB, Gender gender)
        {
            s_userID++;
            UserID = "SF"+s_userID;
            Name = name;
            FatherName = fatherName;
            Phone = phone;
            Mail = mail;
            DOB = dOB;
            Gender = gender;
        }
         public PersonalInfo(string userID,string name, string fatherName, long phone, string mail, DateTime dOB, Gender gender)
        {
           
            UserID =userID;
            Name = name;
            FatherName = fatherName;
            Phone = phone;
            Mail = mail;
            DOB = dOB;
            Gender = gender;
        }

        
    }
}