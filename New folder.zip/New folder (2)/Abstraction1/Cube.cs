using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Abstraction1
{
    public  class Cube:Shape
    {
      

        //public double _calculatearea;
        //public double _calculatevolume;
        public override double Area { get;set; }
        public override double Volume { get;set; }
          public Cube(double radius,double height,double width,double a,double area, double volume)
        {

            Area = area;
            Volume = volume;
           
        }
        
        
        /*Class Cubes inherit Shape
Overridden methods: CalculateArea -  6a2 , CalculateVolume - a3 
        */
        public  override double CalculateArea(){
           Area=6*Math.Pow(A,2);
           return Area;
        }
        public override double CalculateVolume()
        {
           // throw new NotImplementedException();
           Volume=Math.Pow(A,3);
           return Volume;
        }

    }
}