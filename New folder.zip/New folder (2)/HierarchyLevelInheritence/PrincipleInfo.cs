using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchyLevelInheritence
{
    public class PrincipleInfo:PersonalInfo
    {
        public static int s_principleID=9000;
        public PrincipleInfo(string name, string fatherName, DateTime dOB, long phone, Gender gender, string mail,string qualification, int yearOfExperience, DateTime dateOfJoining):base(name,fatherName,dOB,phone,gender,mail)
        {
            s_principleID++;
            PrincipleID="Principle"+s_principleID;
            Qualification = qualification;
            YearOfExperience = yearOfExperience;
            DateOfJoining = dateOfJoining;
        }

        //Class PrincipalInfo inherit PersonalInfo
        //Properties: PrincipalID, Qualification, YearOfExperience, DateOfJoining
        public string PrincipleID { get; }
        public string Qualification { get; set; }
        public int YearOfExperience { get; set; }
        public DateTime DateOfJoining { get; set; }
    }
}