using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbstractMethod1
{
    public enum EngineType{Petrol,diesel,cng}
    public enum CarType{hatchback,sedan,suv}
    public abstract class Car
    {
       /*Field: No. of wheels=4, No.Of.Doors = 4, 
Properties: Engine type -Petrol,diesel,cng, No.Of.Seats, Price, CarType -hatchback, sedan,  suv
Abstract methods: get engine type, get no. of seats, get price, get car type
       */ 
       public int NoOfWheel=4;
       public int NoOfDoor=4;

        
        //Properties:Engine type -Petrol,diesel,cng,No.Of.Seats,Price,CarType -hatchback,sedan,suv
        public EngineType EngineType { get; set; }
        public int NoOfSeats { get; set; }
        public double Price { get; set; }
        public CarType CarType { get; set; }
       // public int MyProperty { get; set; }
        public Car(EngineType engineType, int noOfSeats, double price, CarType carType)
        {
            EngineType = engineType;
            NoOfSeats = noOfSeats;
            Price = price;
            CarType = carType;
           
        }
        //Abstract methods: get engine type, get no. of seats, get price, get car type
        public abstract EngineType GetEngineType();
        public abstract int GetNoSeats();
        public abstract double GetPrice();
        public abstract CarType GetCarType();



    }
}