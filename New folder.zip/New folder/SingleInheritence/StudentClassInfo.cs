using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public enum Branch{CSE,EEE,MECH,CIVIL,ECE}
public enum Standers{Good,Best,VeryBest}

namespace SingleInheritence
{

    public class StudentClassInfo:PersonalInfo
    {
       
        /*Class StudentInfo: inherits PersonalInfo
Propeties: RegisterNumber, Standard, Branch, AcadamicYear
Method:  ShowStudentInfo
*/
        public string RegisterNumber { get; set; }
        public Standers Standers{ get; set; }
        public Branch Branch { get; set; }
        public int AcadamicYear { get; set; }
      
        public static string fatherName { get; private set; }

        public StudentClassInfo(string name, string fatherName, long phone, string mail, DateTime dOB, Gender gender,string registerNumber, Standers standard, Branch branch, int acadamicYear):base(name,fatherName,phone,mail,dOB,gender)
        {
            RegisterNumber = registerNumber;
            Standers = standard;
            Branch = branch;
            AcadamicYear = acadamicYear;
           
        }

       
       


    
    }

}