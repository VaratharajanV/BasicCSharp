﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
namespace SingleInheritence;
/*Program for getting and showing student details: Create 2 student details

Class PersonalInfo:
Properties: Name, FatherName, Phone ,Mail, DOB, Gender
Constructor to assign values
Class StudentInfo: inherits PersonalInfo
Propeties: RegisterNumber, Standard, Branch, AcadamicYear
Method:  ShowStudentInfo
*/
public class Program{
    public static List<StudentClassInfo> listStudent=new List<StudentClassInfo>();

    public static void Main(string[] args)
    {
        StudentClassInfo student=new StudentClassInfo("Raja","Venkatesan",6382634152,"varatharajan60782@gmail.com",new DateTime(04/07/2023),Gender.Male,"SF4385",Standers.Best,Branch.CSE,2023);
        listStudent.Add(student);
        System.Console.WriteLine("----------------Student Information ----------");
        ShowStudentInfo();
        System.Console.WriteLine();
    }
     public static void ShowStudentInfo(){
        foreach(StudentClassInfo student in listStudent){
            System.Console.WriteLine("Name : "+student.Name);
            System.Console.WriteLine("Father Name : "+student.FatherName);
            System.Console.WriteLine("DOB :"+student.DOB);
            System.Console.WriteLine("Register Number  : "+student.RegisterNumber);
            System.Console.WriteLine("Mobile Number : "+student.Phone);
            System.Console.WriteLine("Academic Year :"+student.AcadamicYear);
            System.Console.WriteLine("Branch Name : "+student.Branch);
            System.Console.WriteLine("Gender : "+student.Gender);
            System.Console.WriteLine("Mail : "+student.Mail);
            System.Console.WriteLine("Standers : "+student.Standers);

        }
            
        }



}