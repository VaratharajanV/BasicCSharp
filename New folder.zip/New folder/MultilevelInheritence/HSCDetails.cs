using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultilevelInheritence
{
    public class HSCDetails:StudentInfo
    {
        /*Class HSCDetails: Inherits StudentInfo
	Properties: HSCMarksheetID, Physics, Chemistry, Maths, Total, Percentage marks
	Methods:  Calculate – Total and percentage
        */

        private static int s_hscMarkSheetID=5000;

       

        public string HSCMarkSheetID { get; }
        public int Physics { get; set; }
        public int Chemistry { get; set; }
        public int Maths { get; set; }
        public int Total { get; set; }
        public double Percentage { get; set; }
         public HSCDetails(string userID,string registrationID,string name, string fatherName, long phone, string mail, DateTime dOB, Gender gender,Standard standard, Branch branch, int acadamicYear,int physics, int chemistry, int maths, int total, double percentage):base(userID,registrationID, name,fatherName,phone, mail,dOB,gender, standard,branch,acadamicYear)
        {
            s_hscMarkSheetID++;
            HSCMarkSheetID="HSC"+s_hscMarkSheetID;
            Physics = physics;
            Chemistry = chemistry;
            Maths = maths;
            Total = total;
            Percentage = percentage;
        }
        public void CalculateTotal(){
            Total=Physics+Chemistry+Maths;
        }
         public void CalculatePercentage(){
            //double Percent=Total/3;
            Percentage=Total/3;

        }
 
    }
}