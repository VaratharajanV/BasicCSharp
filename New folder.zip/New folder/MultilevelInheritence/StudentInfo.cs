using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultilevelInheritence
{
    public enum Standard{twelth,no12th}
    public enum Branch{CSE,ECE,EE,MECH,CIVIL}
    public class StudentInfo:PersonalInfo
    {
        //Class StudentInfo: inherits PersonalInfo
//Propeties: RegistrationID, Standard, Branch, AcadamicYear

        private static int s_registration=1000;

       

        public string RegistrationID { get; }
        public Standard Standard { get; set; }
        public Branch Branch { get; set; }
        public int AcadamicYear { get; set; }
         public StudentInfo(string userID,string name, string fatherName, long phone, string mail, DateTime dOB, Gender gender,Standard standard, Branch branch, int acadamicYear):base(userID,name,fatherName,phone,mail,dOB,gender)
        {
            s_registration++;
            RegistrationID="Reg"+s_registration;
            Standard = standard;
            Branch = branch;
            AcadamicYear = acadamicYear;
        }
         public StudentInfo(string userID,string registrationID,string name, string fatherName, long phone, string mail, DateTime dOB, Gender gender,Standard standard, Branch branch, int acadamicYear):base(userID,name,fatherName,phone,mail,dOB,gender)
        {
            //UserID=userID;
            RegistrationID=registrationID;
            Standard = standard;
            Branch = branch;
            AcadamicYear = acadamicYear;
        }
    }
}