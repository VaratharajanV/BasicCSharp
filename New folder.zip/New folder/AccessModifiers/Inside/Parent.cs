using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Outside;

namespace Inside
{
    public class Parent : GrandParent
    {
        
        public int PublicNumber=10;
        private int PrivateNumber=20;
        public int PrivateOut{get {return PrivateNumber;}} 
        protected int ProtectedNumber=30;
        internal int InternalNumber=40;

        public int OutsidePINumber{get{return OutsideProtectedInternalNumber;}}
    }
}