using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Inside
{
    public class Son : Parent
    {
        public int ProtectedOut{get{return ProtectedNumber;}}
    }
}