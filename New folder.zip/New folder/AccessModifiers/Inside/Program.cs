﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace Inside;
class Program{
    public static void Main(string[] args)
    {
        Parent parent=new Parent();
        System.Console.WriteLine(parent.PublicNumber);
        System.Console.WriteLine(parent.PrivateOut);
        System.Console.WriteLine();
        Son son=new Son();
        System.Console.WriteLine(son.ProtectedOut);
        System.Console.WriteLine(son.InternalNumber);
        Console.WriteLine(parent.OutsidePublicNumber);
        System.Console.WriteLine(parent.OutsidePINumber);


    }
}