﻿namespace Outside;

public class GrandParent
{
    public int OutsidePublicNumber=50;
    internal int OutsideInternalNumber=60;
    protected internal int OutsideProtectedInternalNumber=70;
}
