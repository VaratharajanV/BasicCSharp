﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace Polymorphism2;
public class Program{
    public static void Main(string[] args)
    {
        /*
Create a set of methods that will calculate the square of given type number
Compute square of given integer
Compute square of given float
Compute square of given double
Compute square of given long
Call the above 5 methods and print the results
        */
       Square(2); 
       Square(3.4); 
       Square(272.289262); 
       Square(92626278282); 
      
    }
    public static void Square(long number)
    {
        //throw new NotImplementedException();
         long square=number*number;
        System.Console.WriteLine("Square : "+square);
    }


    public static void Square(double number)
    {
        //throw new NotImplementedException();
         double square=number*number;
        System.Console.WriteLine("Square : "+square);
    }

    public static void Square(float number)
    {
        //throw new NotImplementedException();
        float square=number*number;
        System.Console.WriteLine("Square : "+square);
    }

    public static void Square(int number)
    {
        //throw new NotImplementedException();
        int square=number*number;
        System.Console.WriteLine("Square : "+square);
    }
}
