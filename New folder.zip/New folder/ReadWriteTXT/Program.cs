﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.IO;
namespace ReadWriteTXT;
public class Program{
    public static void Main(string[] args)
    {
        if(!Directory.Exists("TestFolder")){
            System.Console.WriteLine("Creating Folder");
            Directory.CreateDirectory("TestFolder");
        }
        else{
            System.Console.WriteLine("Directory Exists");
        }
        if(!File.Exists("MyFile.txt")){
            System.Console.WriteLine("Creating File");
            File.Create("TestFolder/MyFile").Close();
        }
        else{
            System.Console.WriteLine("Already Exists");
        }

        System.Console.WriteLine("Enter Select 1. Read From File 2. Write from File ");
        int input=int.Parse(Console.ReadLine());
        switch(input){
            case 1:{
                StreamReader sr=new StreamReader("TestFolder/MyFile");
                string text=sr.ReadLine();
                System.Console.WriteLine(text);
                sr.Close();
                break;
            }
            case 2 :
            {
                break;
            }

        }
    }
}
