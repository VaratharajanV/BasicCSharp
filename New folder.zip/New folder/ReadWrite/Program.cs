﻿// See https://aka.ms/new-console-template for more information
using System;

namespace ReadWrite;

    class Program{
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter Your Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Your fathers name :");
            string fatherName = Console.ReadLine();
            //Concatenation

            /*Console.WriteLine("My name is " +name +" "+"and my father's name is "+ fatherName ) ;
            //Placeholder
            Console.WriteLine("{0} {1}",name,fatherName);    */
            //Interpolation ------> efficient method
            Console.WriteLine($"My name is : {name} and my fathers name is : {fatherName}");




        }
    }

