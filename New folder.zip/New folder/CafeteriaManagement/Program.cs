﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace CafeteriaManagement;
public class Program{
    public static void Main(string[] args)
    {
        /*
        */
        DefaultData();
        MainMenu();
    }

    public static void MainMenu()
    {
        System.Console.WriteLine("!--------Welcome to Cafeteria Managemnent--------!");
        
    }

    public  static void DefaultData()
    {
        //throw new NotImplementedException();

    }
}