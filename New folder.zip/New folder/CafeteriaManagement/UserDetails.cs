using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CafeteriaManagement
{
    public class UserDetails : PersonalDetails ,IBalance
    {
        /*
        Properties:
•	UserID (Auto Incremented – SF1001)
•	WorkStationNumber
•	Field: _balance
•	Read only property: WalletBalance.
Methods:
•	WalletRecharge, DeductAmount
        */
        private static int s_userID=1000;
        private double _balance;

        

        public string UserID { get; }
         // public int MyProperty { get; set; }
        public double WalletBalance { get{return _balance ;}}

        public UserDetails(string name, string fatherName, Gender gender, long mobile, string mailID,int workStationNumber):base(name,fatherName,gender,mobile,mailID)
        {
            s_userID++;
            UserID="SF"+s_userID;
           
            WorkStationNumber = workStationNumber;
        }
      
        public int WorkStationNumber {get;set;}
         public void WalletRecharge(double amount){
            _balance=_balance+amount;
         }
       public void DeductAmount(double amount){
            _balance=_balance+amount;
       }
    }
}