using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence1
{
    public class RegisterPerson :PersonalInfo,IFamilyInfo 
    {
        //Class RegisterPerson inherits Personalinfo, IFamilyInfo 
        //Properties: RegistrationID, DateOfRegistration
        //IFamilyInfo.fatherName;
        private static int s_registrationID=1000;

        public string RegisterationID { get;}
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string HouseAddress { get; set; }
        public int NoOfSiblings { get; set; }
        public DateTime DateRegistarion { get; set; }

        public RegisterPerson(string userID,Gender gender, DateTime dOB, long phone, long mobile, MaritalStatus maritalStatus,string fatherName, string motherName, string houseAddress, int noOfSiblings, DateTime dateRegistarion):base(userID,gender,dOB,phone,mobile,maritalStatus)
        {
            s_registrationID++;
            RegisterationID="Reg"+s_registrationID;
            FatherName = fatherName;
            MotherName = motherName;
            HouseAddress = houseAddress;
            NoOfSiblings = noOfSiblings;
            DateRegistarion = dateRegistarion;
        }

       
    }
}
