﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace MultipleInheritence1;
public class Program{
    public static void Main(string[] args)
    {
        /*1.	Create application for getting, storing person’s details create two objects for register person
Class Personalnfo inherit IShowData
Properties: UserID, Name, Gender, DOB, phone, mobile, Marital details – Married/single

Interface IFamilyInfo
Properties: FatherName, MotherName, HouseAddress, No.Of.Siblings   

Class RegisterPerson inherits Personalinfo, IFamilyInfo 
Properties: RegistrationID, DateOfRegistration
        */
        PersonalInfo person1=new PersonalInfo(Gender.male,new DateTime(04/07/2002),87263218,71286123,MaritalStatus.Single);
        PersonalInfo person2=new PersonalInfo(Gender.male,new DateTime(04/07/2002),87263218,71286123,MaritalStatus.Single);
        // PersonalInfo person3=new PersonalInfo(Gender.male,new DateTime(04/07/2002),87263218,71286123,MaritalStatus.Single);

        System.Console.WriteLine(person1.UserID);
        System.Console.WriteLine(person1.DOB);
        System.Console.WriteLine(person1.Mobile);
        System.Console.WriteLine(person1.MaritalStatus);
        System.Console.WriteLine();
        System.Console.WriteLine(person2.UserID);
        System.Console.WriteLine(person2.DOB);
        System.Console.WriteLine(person2.Gender);
        System.Console.WriteLine(person2.Phone);
        System.Console.WriteLine(person2.MaritalStatus);
        System.Console.WriteLine();
         // System.Console.WriteLine(person3.UserID);
        RegisterPerson register1=new RegisterPerson(person1.UserID,person1.Gender,person1.DOB,person1.Phone,person1.Mobile,person1.MaritalStatus,"Venkatesan","GuruDevi","Kangeyanatham Thirumangalam",1,new DateTime(15/12/2023));
        RegisterPerson register2=new RegisterPerson(person2.UserID,person1.Gender,person1.DOB,person1.Phone,person1.Mobile,person1.MaritalStatus,"Venkatesan","GuruDevi","Kangeyanatham Thirumangalam",1,new DateTime(15/12/2023));
       // RegisterPerson register3=new RegisterPerson(person1.Gender,person1.DOB,person1.Phone,person1.Mobile,person1.MaritalStatus,"Venkatesan","GuruDevi","Kangeyanatham Thirumangalam",1,new DateTime(15/12/2023));
        System.Console.WriteLine(register1.RegisterationID);
        System.Console.WriteLine(register1.DateRegistarion);
        System.Console.WriteLine(register1.FatherName);
        System.Console.WriteLine(register1.UserID);
        System.Console.WriteLine(register1.MaritalStatus);
        System.Console.WriteLine();
        System.Console.WriteLine(register2.RegisterationID);
        System.Console.WriteLine(register2.FatherName);
        System.Console.WriteLine(register2.DOB);
        System.Console.WriteLine(register2.MaritalStatus);
        System.Console.WriteLine(register2.UserID);
       // System.Console.WriteLine(register3.RegisterationID);

        
    }
}