using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence3
{
    public enum AccountType{
        Savings,
        Balance
    }
    public class SavingAccount:PersonalInfo,ICalculate
    {
        /*Class SavingAccount: Inherit PersonalInfo, ICalculate
Properties: AccountID, AccountType->Savings, Balance 
Methods: Deposit, Withdraw, Balance check
        */
        private static int s_accountID=1000;
        private double _balance=500;

        
        public string AccountID { get; }
        public double Balance { get{return _balance;} }
        public AccountType AccountType { get; set; }

        public SavingAccount(string name, Gender gender, DateTime dOB, long phone, long mobile, string pANNumber,AccountType accountType):base(name, gender,dOB, phone,mobile, pANNumber)
        {
            AccountType = accountType;
        }

        public void Deposit(double amount){
            _balance+=amount;
        }
        public void Withdraw(double amount){
            _balance-=amount;
        }
        public void BankBalance(){
           
        }
    }
}