﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace MultipleInheritence3;
public class Program{
    public static void Main(string[] args)
    {
        /*3.	Create bank account application to handle bank account manipulation create 2 accounts in each savings and recurring deposit classes. And manipulate credit, debit, show balance operations. 

Class PersonalInfo:
Properties: Name, Gender, DOB, phone, mobile, PAN number
Method: Get Details

Interface ICalculate:
Methods: Deposit, Withdraw, Balance check

Class SavingAccount: Inherit PersonalInfo, ICalculate
Properties: AccountID, AccountType->Savings, Balance 
Methods: Deposit, Withdraw, Balance check

Class RecurringDeposit: Inherit PersonalInfo, ICalculate
Properties: AccounID, AccountType->Savings, Balance
Methods: Deposit, Withdraw, Balance check

Requirement : Have to create two objects for each above classes (ID’s are auto incremented) in Program.cs and have to display the details and have to perform deposit. Withdraw and have to show balances.

        */
        PersonalInfo person1=new PersonalInfo("raja",Gender.male,new DateTime(04/07/2002),987654321,6382634152,"AXV92173218");
        PersonalInfo person2=new PersonalInfo("ram",Gender.male,new DateTime(05/07/2002),987654321,6382634152,"AXV9238773218");

        SavingAccount saving1=new SavingAccount(person1.Name,person1.Gender,person1.DOB,person1.Phone,person1.Mobile,person1.PANNumber,AccountType.Savings);
        SavingAccount saving2=new SavingAccount(person2.Name,person2.Gender,person2.DOB,person2.Phone,person2.Mobile,person2.PANNumber,AccountType.Balance);
        System.Console.WriteLine("Deposit Amount :");
        saving1.Deposit(500);
        System.Console.WriteLine(saving1.Balance);
        System.Console.WriteLine("Deposit Amount :");
        saving2.Deposit(1000);
        System.Console.WriteLine(saving2.Balance);
        saving1.Withdraw(500);
        System.Console.WriteLine(saving1.Balance);
        System.Console.WriteLine("Withdraw Amount :");
        saving2.Withdraw(1000);
        System.Console.WriteLine(saving2.Balance);
        RecurringDeposit recurring1=new RecurringDeposit(person1.Name,person1.Gender,person1.DOB,person1.Phone,person1.Mobile,person1.PANNumber,AccountType1.Savings);
        RecurringDeposit recurring2=new RecurringDeposit(person2.Name,person2.Gender,person2.DOB,person2.Phone,person2.Mobile,person2.PANNumber,AccountType1.BankBalance);
        System.Console.WriteLine("Withdraw amount :");
        recurring1.Deposit(200);
        System.Console.WriteLine(recurring1.Balance);
        System.Console.WriteLine("Withdraw Amount :");
        recurring2.Deposit(100);
        System.Console.WriteLine(recurring2.Balance);
        recurring1.Withdraw(200);
        System.Console.WriteLine(recurring1.Balance);
        System.Console.WriteLine("Withdraw Amount :");
        recurring2.Withdraw(100);
        System.Console.WriteLine(recurring2.Balance);

        System.Console.WriteLine();


    }
}
