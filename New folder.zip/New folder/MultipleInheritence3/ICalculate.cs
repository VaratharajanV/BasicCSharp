using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence3
{
    public interface ICalculate
    {
        //Methods: Deposit, Withdraw, Balance check
         void Deposit(double amount);
         void Withdraw(double amount);
         void BankBalance();
    }
}