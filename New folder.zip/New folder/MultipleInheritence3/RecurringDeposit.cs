using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence3
{
    public enum AccountType1{
        Savings,
        BankBalance
    }
    public class RecurringDeposit:PersonalInfo , ICalculate 
    {
        private static int s_accountID=1000;
        private double _balance;

        
        public string AccountID { get; }
        public double Balance { get{return _balance;} }
        public AccountType1 AccountType1 { get; set; }

        public RecurringDeposit(string name, Gender gender, DateTime dOB, long phone, long mobile, string pANNumber,AccountType1 accountType1):base(name, gender,dOB, phone,mobile, pANNumber)
        {
            s_accountID++;
            AccountID="AC"+s_accountID;
            AccountType1 = accountType1;
        }

        public void Deposit(double amount){
            _balance+=amount;
        }
        public void Withdraw(double amount){
            _balance-=amount;
        }
       
        public void BankBalance()
        {
            //throw new NotImplementedException();
            
        }
    }
}