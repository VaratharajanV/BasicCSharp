using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence3
{
    public enum Gender{
        male,
        female,
        transgender
    }
    public class PersonalInfo
    {
       

        /*Class PersonalInfo:
Properties: Name, Gender, DOB, phone, mobile, PAN number
Method: Get Details
*/
        public string Name { get; set; }
        public Gender Gender { get; set; }
        public DateTime DOB { get; set; }
        public long Phone { get; set; }
        public long Mobile { get; set; }
        public string PANNumber { get; set; }
         public PersonalInfo(string name, Gender gender, DateTime dOB, long phone, long mobile, string pANNumber)
        {
            Name = name;
            Gender = gender;
            DOB = dOB;
            Phone = phone;
            Mobile = mobile;
            PANNumber = pANNumber;
        }
    }
}