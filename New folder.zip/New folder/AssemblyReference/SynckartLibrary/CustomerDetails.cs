using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SynckartLibrary;


    public class CustomerDetails
    {
        //fields
        private static int s_customerID=1000;

      

        //proiperties
        public string CustomerID { get; }
        public string CustomerName { get; set; }
        public string City { get; set; }
        public long MobileNumber { get; set; }
        public double WalletBalance { get; set; }
        public string EmailID { get; set; }
        //constructors
          public CustomerDetails(string customerName, string city, long mobileNumber, double walletBalance, string emailID)
        {
            s_customerID++;
            CustomerID="CID"+s_customerID;
            CustomerName = customerName;
            City = city;
            MobileNumber = mobileNumber;
            WalletBalance = walletBalance;
            EmailID = emailID;
        }
        public void Recharge(int TotalAmount){
            WalletBalance+=TotalAmount;
        }
        public void DeductBalance(int TotalAmount){
            WalletBalance-=TotalAmount;
        }
    }
}