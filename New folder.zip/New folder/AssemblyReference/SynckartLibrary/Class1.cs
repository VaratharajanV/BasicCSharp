﻿namespace SynckartLibrary;

public class Class1
{

}
