﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
namespace PayRollManagementSystem;
public class Program{
    public static EmployeeDetails CurrentEmployee;
    public static AttendenceDetails CurrentAttendence;
    public static List<EmployeeDetails> employeeList=new List<EmployeeDetails>();
      public static  List<AttendenceDetails> attendenceList=new List<AttendenceDetails>();
    public static void Main(string[] args)
    {
      AddDetails();
        MainMenu();
    }
    public static void AddDetails(){
         //SF3001	Ravi	11/11/1999	9958858888	Male	Eymard	Developer
       
        
        EmployeeDetails employee1=new EmployeeDetails("Ravi",DateTime.Parse("11/11/1999"),9958858888,Gender.male,Branch.Eymard,Team.Developer);
        employeeList.Add(employee1);

        AttendenceDetails attendence1=new AttendenceDetails("SF3001",DateTime.ParseExact("15/05/2022","dd/MM/yyyy",null),DateTime.Parse("09:00 AM"),DateTime.Parse("09:00 AM"),8);
        AttendenceDetails attendence2=new AttendenceDetails("SF3002",DateTime.ParseExact("16/05/2022","dd/MM/yyyy",null),DateTime.Parse("09:10 AM"),DateTime.Parse("06:50 AM"),8);
        //AID1001	SF3001	15/05/2022	09:00 AM	6:10 PM	8
        //AID1002	SF3002	16/05/2022	9:10 AM	6:50 PM	8
        //Console.ReadLine();
        attendenceList.Add(attendence1);
        attendenceList.Add(attendence2);

    }

    public static void MainMenu(){

        
         
         bool flag=true;
         do{
             System.Console.WriteLine("Welcome to payroll Management System");
            System.Console.WriteLine("1.Employee Registration\n2.Employee Login\n3.Exit");
            int option=Convert.ToInt32(Console.ReadLine());
            switch(option){
            case 1:
            {
                EmployeeRegistration();
                break;
            }
            case 2:
            {
                EmployeeLogin();
                break;
            }
            case 3:
            {
                System.Console.WriteLine("Thank You....!");
                flag=false;
                break;
            }
            default:{
                System.Console.WriteLine("Invalid Entry");
                break;
            }
         }
         }while(flag==true);
         
        
    }

    private static void EmployeeLogin()
    {
        //throw new NotImplementedException();
        /*
        •	On selection of 2 option in main menu ask user to enter Employee ID.


•	Check whether the ID is valid. If invalid show” Invalid User ID”.
        */
        System.Console.WriteLine("Welcome to Login Page");
        System.Console.WriteLine("Enter Employee ID");
        bool flag=true;
        string userEmployeeID=Console.ReadLine();
        foreach(EmployeeDetails em in employeeList){
             if(userEmployeeID==em.EmployeeID){
                flag=false;
                CurrentEmployee=em;
                System.Console.WriteLine("Login Verification completed ....");
            Submenu();
        }
        }
        if(flag){
            System.Console.WriteLine("Invalid UserID....!");
        }
       

    }

    public static void Submenu()
    {
        bool flag2=true;
        do{
        System.Console.WriteLine("Enter1.Add Attendance \n2.Display Details\n3.Calculate Salary\n4.Exit)");
        int optionSub=Convert.ToInt32(Console.ReadLine());
        switch(optionSub){
            case 1:
            {
                AddAttendence();
                break;
            }
            case 2:
            {
                DisplayDetails();
                break;
            }
            case 3:
            {
                CalculateSalary();
                break;
            }
            case 4:
            {
                flag2=false;
                break;
            }
            default:
            {
                System.Console.WriteLine("Enter 1-4 ...Wrong Input ...OOPS!");
                break;
            }
        }

    }while(flag2);
        //throw new NotImplementedException();
        
    }

    public  static void CalculateSalary()
    {
        System.Console.WriteLine("Salary Calculated : ");
        //throw new NotImplementedException();
        //•	Traverse the Attendance Details List show the attendance details list of current users in the current month. 
//•	Calculate the total number of hours worked in the current month.
//•	Finally show the total salary of the current user for the current month. Salary is Rs. 500 /Day (8 Hours).
        
         
        foreach(AttendenceDetails attendence in attendenceList){
            
            if(CurrentEmployee.EmployeeID==attendence.EmployeeID){
                CurrentAttendence=attendence;
               int days=DateTime.DaysInMonth(CurrentAttendence.CheckInTime.Year,CurrentAttendence.CheckInTime.Month);
                
                   

               double TotalSalary=days*500;
               System.Console.WriteLine($"Your Salary is "+TotalSalary);
                
            }
        }


    }

    public static void DisplayDetails()

    {
        foreach(AttendenceDetails attendence in attendenceList){
            if(CurrentEmployee.EmployeeID==attendence.EmployeeID){
                System.Console.WriteLine("EmployeeID"+CurrentEmployee.EmployeeID);
                
                System.Console.WriteLine("FULLNAME"+CurrentEmployee.FullName);
                System.Console.WriteLine("DOB"+CurrentEmployee.DOB);
                System.Console.WriteLine("Gender"+CurrentEmployee.Gender);
                System.Console.WriteLine("MobileNumber"+CurrentEmployee.MobileNumber);
                System.Console.WriteLine("Team : "+CurrentEmployee.Team);
                System.Console.WriteLine("Branch :"+CurrentEmployee.Branch);


            }
        }
        //hrow new NotImplementedException();
    }

    public static void AddAttendence()
    {
        //throw new NotImplementedException();
        /*
        Need to ask the user whether he want to check-in.
•	If he wants to check in – Then ask the user Date and time of check in.
After that ask the user whether he want to check out. 
•	If he wants to checkout means - Then ask the user Date and time of check out.
•	Calculate Hours worked as the time difference between check in and out time.
•	If Hours Worked is greater than 8 then take it as 8 hours.
•	Create Attendance Object and add to list. Show “Check-in and Checkout Successful and today you have worked 8 Hours”.
        */
        System.Console.WriteLine("Doyou want to checkIn(yes/No) ?");
        string choice=Console.ReadLine().ToLower();
        if(choice=="yes"){
           System.Console.WriteLine("Enter Date :");
           DateTime checkedDate=DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null); 
           System.Console.WriteLine("Enter Time :");
           DateTime checkedTime=DateTime.ParseExact(Console.ReadLine(),"hh:mm tt",null);
           System.Console.WriteLine("Do you want to CheckOut Now?(yes/no)");
         string choice1=Console.ReadLine();
           if(choice1=="yes"){
             System.Console.WriteLine("Enter Date :");
           DateTime checkedOutDate=DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null); 
           System.Console.WriteLine("Enter Time :");
           DateTime checkedOutTime=DateTime.ParseExact(Console.ReadLine(),"hh:mm tt",null);
           if(checkedDate==checkedOutDate){
                //Calculate Hours worked as the time difference between check in and out time.
                TimeSpan time=checkedOutTime-checkedTime;
                if(time.Hours>=8){
                    int hoursWorked=8;
                   // EmployeeDetails employee=new EmployeeDetails(CurrentEmployee.FullName,CurrentEmployee.DOB,CurrentEmployee.MobileNumber,CurrentEmployee.Gender,CurrentEmployee.Branch,CurrentEmployee.Team);
                    //DateTime date, TimeOnly checkInTime, TimeOnly checkOutTime, TimeSpan hoursWorked
                    AttendenceDetails attendence1=new AttendenceDetails(CurrentEmployee.EmployeeID,checkedDate,checkedTime,checkedOutTime,hoursWorked);
                    attendenceList.Add(attendence1);
                    System.Console.WriteLine("Check-in and Checkout Successful and today you have worked 8 Hours.");
                }
           }
           } 
        }

    }

    public static void EmployeeRegistration(){
        /*
        Need to get the below employee details.
•	Full Name
•	DOB
•	MobileNumber
•	Gender
•	Branch 
•	Team 
After getting the above information need to create employee object add to employee details list.
Finally show “Employee added successfully your id is:  SF3001”
        */
        System.Console.WriteLine("Welcome to employee Registration .....!");
        System.Console.WriteLine("Enter Your Full Name");
        string fullName=Console.ReadLine();
        System.Console.WriteLine("Enter DOB");
        DateTime doB=DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null);
        System.Console.WriteLine("Enter Mobiloe Number : ");
        long mobileNumber=long.Parse(Console.ReadLine());
        System.Console.WriteLine("Enter Your Gender : ");
        Gender gender=Enum.Parse<Gender>(Console.ReadLine(),true);
        System.Console.WriteLine("Enter Your Branch :");
        Branch branch=Enum.Parse<Branch>(Console.ReadLine()
        ,true);
         System.Console.WriteLine("Enter Your Team :");
         Team team=Enum.Parse<Team>(Console.ReadLine(),true);
         EmployeeDetails employee1=new EmployeeDetails(fullName,doB,mobileNumber,gender,branch,team);
         employeeList.Add(employee1);
         System.Console.WriteLine($"Employee Registration successfully Completed and Your Employee Id is : {employee1.EmployeeID}");
    }
}