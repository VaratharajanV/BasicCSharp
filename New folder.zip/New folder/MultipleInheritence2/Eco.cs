using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritence2
{
    public class Eco : Car, IBrand 
    {
        /*Class Eco  inherit Car, IBrand
Property:   MakingID, EngineNumber, ChasisNumber
        */
        private static int s_makingID=1000;

        public string BrandName { get; set; }
        public string ModelName { get; set; }
        public string MakingID { get;}
        public string EngineNumber { get; set; }
        public string ChasisNumber { get; set; }
        public Eco(string carID,string fuleType, int numberOfSeats, string color, double tankCapacity, double numberOfKmDriven,string brandName,string modelName,string engineNumber, string chasisNumber):base(carID,fuleType,numberOfSeats,color,tankCapacity,numberOfKmDriven)
        {
            s_makingID++;
            MakingID="Make"+s_makingID;
            BrandName=brandName;
            ModelName=modelName;
            EngineNumber = engineNumber;
            ChasisNumber = chasisNumber;
        }

    }
}