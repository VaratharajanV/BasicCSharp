﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace MultipleInheritence2;
public class Program{
    public static void Main(string[] args)
    {
        /*2.	Create an application to handle Car Models. Create 2 objects each for ShiftDezire and Eco calculate milage, Show details of cars.
Class Car
Property: FuleType, NumberOfSeats, Color, TankCapacity, NumberOfKmDriven
Method: CalculateMilage
Interface  IBrand
Property: BrandName, ModelName
Class ShiftDezire inherit Car, IBrand
Property:   MakingID, EngineNumber, ChasisNumber
Class Eco  inherit Car, IBrand
Property:   MakingID, EngineNumber, ChasisNumber
Requirement : Have to create two objects for each above classes (ID’s are auto incremented) in Program.cs and have to display the details.

        */
        System.Console.WriteLine("Details of CAR 1: ");
        Car car=new Car("petroll",4,"red",200,3000);
        System.Console.WriteLine((car.CarID));
        System.Console.WriteLine(car.Color);
        System.Console.WriteLine(car.NumberOfKmDriven);
        System.Console.WriteLine(car.NumberOfSeats);
        System.Console.WriteLine(car.TankCapacity);
        System.Console.WriteLine("Details of car2 : ");
        car.CalculateMilage();
         Car car2=new Car("deisel",4,"blue",500,1000);
        //System.Console.WriteLine((car.CarID));
        System.Console.WriteLine((car2.CarID));
        System.Console.WriteLine(car2.Color);
        System.Console.WriteLine(car2.NumberOfKmDriven);
        System.Console.WriteLine(car2.NumberOfSeats);
        System.Console.WriteLine(car2.TankCapacity);
        car2.CalculateMilage();
        Eco eco=new Eco(car.CarID,car.FuleType,car.NumberOfSeats,car.Color,car.TankCapacity,car.NumberOfKmDriven,"Brand1","BR7000","Eng1028","gus9229");
        Eco eco2=new Eco(car2.CarID,car2.FuleType,car2.NumberOfSeats,car2.Color,car2.TankCapacity,car2.NumberOfKmDriven,"Brand2","BR8000","Eng2028","gus0229");
        System.Console.WriteLine("Details of Eco 1 :");
        System.Console.WriteLine(eco.CarID);
        System.Console.WriteLine(eco.MakingID);
        System.Console.WriteLine(eco.Color);
        System.Console.WriteLine(eco.EngineNumber);
        System.Console.WriteLine(eco.ChasisNumber);
        System.Console.WriteLine(eco.ModelName);
        System.Console.WriteLine(eco.NumberOfKmDriven);
        eco.CalculateMilage();
        System.Console.WriteLine("Details of Eco 2 : ");
         System.Console.WriteLine(eco2.CarID);
        System.Console.WriteLine(eco2.MakingID);
        
        System.Console.WriteLine(eco2.Color);
        System.Console.WriteLine(eco2.EngineNumber);
        System.Console.WriteLine(eco2.ChasisNumber);
        System.Console.WriteLine(eco2.ModelName);
        System.Console.WriteLine(eco2.NumberOfKmDriven);
        eco2.CalculateMilage();
        
        


    }
}