﻿using System;
namespace HelloWorld /* name space */
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello World!");
            Console.ReadLine();
        }
    }
}