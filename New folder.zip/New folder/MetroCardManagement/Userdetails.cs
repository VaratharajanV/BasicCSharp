using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MetroCardManagement
{
    public class Userdetails:PersonalDetails,IBalance
    {
        
        /*
        Properties:
•	CardNumber(Auto generation- CMRL101)
•	Balance
Methods:
•	WalletRecharge
•	DeductBalance
        */
        private static int s_cardNumber=100;

        public Userdetails(string userName, long mobileNumber,double balance):base(userName,mobileNumber)
        {
            s_cardNumber++;
            CardNumber="CMRL"+s_cardNumber;
            Balance = balance;
        }
         public Userdetails(string user)
        {
            string[] values=user.Split(",");
            CardNumber = values[0];
            s_cardNumber=int.Parse(values[0].Remove(0,4));
            UserName=values[1];
            MobileNumber = long.Parse(values[2]); 
            
            Balance = double.Parse(values[3]);
        }

        public string CardNumber { get;}
        public double Balance { get; set; }

        //public double Balance { get; set; }

        
        
         public void WalletRecharge(double amount){
            Balance+=amount;
        }
        public void DeductBalance(double amount){
            Balance-=amount;
        }
        

    }
}