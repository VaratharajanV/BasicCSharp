using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Multi
{
    
    public interface IPersonalInfo
    {
        //Properties: AdharNumber, Name, FatherName, Phone, DOB, Gender
        
         string Name { get; set; }
        long AdharNumber { get; set; }
        string FatherName { get; set; }
         long Phone { get; set; }
         DateTime DOB { get; set; }
         Gender Gender { get; set; }
    }
}