﻿using System;
using System.Security.Cryptography.X509Certificates;
using Multi;
namespace MULTI
{
    class Program
    {
        public static void Main(string[] args)
        {
            /*1.	Create an application to handle student Counselling information 
Interface IPersonalInfo:
Properties: AdharNumber, Name, FatherName, Phone, DOB, Gender

Interface IHSCInfo: Inherits IPersonalInfo
Properties: HSCMarksheetNumber, Physics, chemistry, maths, Total, percentage Marks
Methods: CalculateHSC -> Total, percentage.

Interface IUGInfo: Inhertis IPersonalInfo
Properties: UGMarksheetNumber, Sem1, Sem2, Sem3, Sem4 Marks, Total and Percentage
Methods: CalculateUG -> Total, percentage.

Class PGCouncelling inherits IHSCInfo, IUGInfo
Properties: ApplicationID, DateOfApplication, FeeStatus (bool).
Method: PayFees ->500 Rs. 

            */
           
            
          PGCounselling admision1=new PGCounselling("raja",893172,"venkatesan",6813212,new DateTime(04/07/2002),Gender.male,12587512798,89,79,89,0,0,127852987,80,70,60,50,0,0,"12/12/2023",false); 
          PGCounselling admision2=new PGCounselling("raj",893172,"venkat",6813212,new DateTime(04/07/2002),Gender.male,12587512798,89,79,89,0,0,127852987,80,70,60,50,0,0,"12/12/2023",false); 
            System.Console.WriteLine("ADMISSION 1 : ");
            System.Console.WriteLine("Name : "+admision1.Name);
            System.Console.WriteLine("Aadhar Number :"+admision1.AdharNumber);
            System.Console.WriteLine("Father Name :"+admision1.FatherName);
            System.Console.WriteLine("FeeStatus :"+admision1.FeeStatus);
            System.Console.WriteLine("HSCMarkSheetNumber : "+admision1.HSCMarksheetNumber);
            System.Console.WriteLine("DateOfApplication :"+admision1.DateOfApplication);
            System.Console.WriteLine("UGMarkSheetNumber :"+admision1.UGMarksheetNumber);
            System.Console.WriteLine("HSCTotal :"+admision1.HSCTotal);
            System.Console.WriteLine("HSCPercentage : "+admision1.HSCPercentage);
            System.Console.WriteLine("UGTotal :"+admision1.UGTotal);
            System.Console.WriteLine("UGPercentage :"+admision1.UGPercentage);
            System.Console.WriteLine("ApplicationID :"+admision1.ApplicationID);
            admision1.TotalMark();
            System.Console.WriteLine("HSC Total Mark : "+admision1.HSCTotal);
            admision1.TotalPercentage();
            System.Console.WriteLine("HSC Total Percentage : "+admision1.HSCPercentage);
            admision1.TotalMarkCollege();
            System.Console.WriteLine("College Total : "+admision1.UGTotal);
            admision1.TotalPercentageCollege();
            System.Console.WriteLine("College Perentage  is : "+admision1.UGPercentage);
            System.Console.WriteLine("Enter Amount :");
            int amount=Convert.ToInt32(Console.ReadLine());
            admision1.PayFees(amount);
            System.Console.WriteLine("Admission Sucessful"+admision1.FeeStatus);
            System.Console.WriteLine(admision2.ApplicationID);
            }
           
            

        }
    }
