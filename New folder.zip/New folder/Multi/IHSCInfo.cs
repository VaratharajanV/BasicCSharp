using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace Multi
{
    public interface IHSCInfo:IPersonalInfo
    {
        //Properties: HSCMarksheetNumber, Physics, chemistry, maths, Total, percentage Marks
//Methods: CalculateHSC -> Total, percentage
       
         long HSCMarksheetNumber { get; set; }
         int Physics { get; set; }
        int Chemistry { get; set; }
       int Maths { get; set; }
         double HSCTotal { get; set; }
         double HSCPercentage{get; set; }
         void TotalMark();
       
         void  TotalPercentage();
       
    }
}