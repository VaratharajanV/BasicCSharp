﻿

using System;
using System.ComponentModel;
namespace game;
class Program
{
    public static void Main(string[] args)
    {
/*        int number1 = int.Parse(Console.ReadLine());
        int number2 = int.Parse(Console.ReadLine());

        long number3=long.Parse(Console.ReadLine());
        double number4=double.Parse(Console.ReadLine());

        float number7=float.Parse(Console.ReadLine());

        Console.WriteLine($"{number7}",number7);

        Console.WriteLine($"number3:{number3}");
        Console.WriteLine($"number4:{number4}");
        
        double number5=number4+number3;

        Console.WriteLine($"Total of {number4} and {number3} is {number5}",number4,number3,number5);

        double number8=number7+number5;
        Console.WriteLine($"{number8}",number8);

        Console.WriteLine("Enter Letter");
*/

        char letter=char.Parse(Console.ReadLine());

        Console.WriteLine($"{letter}",letter);

        Console.WriteLine("Enter Integer Number : ");

        int number10=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine($"{number10}",number10);

        Console.WriteLine("Enter Long Number");
        long number11=Convert.ToInt64(Console.ReadLine());
        Console.WriteLine($"{number11}",number11);

        Console.WriteLine("Enter Double Number");
        double number12=Convert.ToDouble(Console.ReadLine());

        Console.WriteLine($"{number12}",number12);

    }
}


