using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
public enum AdmissionStatus{Select,Booked,Cancelled}

namespace StudentsAdmission
{
    public class AdmissionDetails
    {
        /*
        Properties:
a.	AdmissionID – (Auto Increment ID - AID1001)
b.	StudentID
c.	DepartmentID
d.	AdmissionDate
e.	AdmissionStatus – Enum- (Select, Booked, Cancelled)
        */
        private int s_admissionID=1000;

        public string AdmissionID { get; set; }

        public string StudentID { get; set; }
        public string DepartmentID { get; set; }
        public DateTime AdmissionDate { get; set; }
        public AdmissionStatus AdmissionStatus{get;set;}

        public AdmissionDetails(string studentID, string departmentID, DateTime admissionDate,AdmissionStatus admissionStatus)
        {
            s_admissionID++;
            AdmissionID="AID"+s_admissionID;
            StudentID = studentID;
            DepartmentID = departmentID;
            AdmissionDate = admissionDate;
            AdmissionStatus=admissionStatus;
        }
        




    }
}