﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace SealedClass;
public class Program{
    public static void Main(string[] args)
    {
        /*1.	Create an application for a employee registration application.

Class  PersonalInfo:
Properties: Name, FatherName, Mobile, Mail, Gender 
Method: UpdateInfo

Sealed Class EmployeeInfo:
Properties: UserID, Password, KeyInfo = 100
Methods: UpdateKey, UpdatePassword

Class Hack Inherit EmployeeInfo
Properties: StoreUserID, StorePassword
 Method: UpdateStorePassword 
Requirement: 
•	Create object for employeeInfo and assign values to properties display value.
•	Try to Create an object for Hack class. To Show th
•	Notice what happening in that. Check whether is the EmployeeInfo is inheritable.

        */
        PersonalInfo person1=new PersonalInfo("raja","venkatesan",87362121,"varatharajan60782@gmail.com",Gender.male);
        EmployeeInfo employee=new EmployeeInfo(person1.Name,person1.FatherName,person1.Mobile,person1.Mail,person1.Gender,"32974732",39874);
        Hack hack=new Hack();
    }
}