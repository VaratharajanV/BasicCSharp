﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
using SingleInheritence2;
namespace Program;

public class Program{
    /*
    Program to  Manipulate bank account details: Create 3 account holders Show Account Info, deposit, withdraw and Show Balance.
Class PersonalInfo:
Properties: Name, FatherName, Phone, Mail, DOB, Gender
Class AccountInfo : Inherit PersonalInfo
Properties: AccountNumber, BranchName, IFSCCode, Balance
Methods: ShowAccountInfo, Deposit , Withdraw, ShowBalance.
    */
    public static List<AccountInfo> listAccountInfo=new List<AccountInfo>();
    //public static AccountInfo CuurentAccount;
    public static void Main(string[] args)
    {
        AccountInfo account1=new AccountInfo("raja","venkatesan",6382634152,new DateTime(14/12/2023),Gender.male,987654344,BranchName.AnnaNagar,"IFSC900000",1000);
        AccountInfo account2=new AccountInfo("rani","vel",6382634152,new DateTime(14/12/2023),Gender.female,737383383,BranchName.NungamBakkam,"murugan",2000);
        AccountInfo account3=new AccountInfo("manthiri","venkatesan",6382634152,new DateTime(14/12/2023),Gender.male,8636727228,BranchName.ChetPet,"IFSC900003",3000);
        listAccountInfo.Add(account1);
        listAccountInfo.Add(account2);
        listAccountInfo.Add(account3);
        
        System.Console.WriteLine("Deposit for the Account Holder :");
        account1.Deposit(250);
       
        System.Console.WriteLine("After Deposit Your Balance for account1 is : "+account1.Balance);
        account2.Deposit(350);
        System.Console.WriteLine("After Deposit Your Balance for account2 is : "+account2.Balance);
        account3.Deposit(450);
        System.Console.WriteLine("After Deposit Your Balance for account3 is : "+account3.Balance);

        account1.Withdraw(250);
        System.Console.WriteLine("WithDrawl for the Account Holder :");
        
        System.Console.WriteLine("After Withdrawl Your Balance for account1 is : "+account1.Balance);
        account2.Withdraw(350);
        System.Console.WriteLine("After Withdrwal Your Balance for account2 is : "+account2.Balance);
        account3.Withdraw(450);
        System.Console.WriteLine("Afrter Withdrawl Your Balance for account3 is : "+account3.Balance);
        //Show Accopunt Information 
        ShowAccountInfo();
        //Show Balance Information 
        ShowBalance();
    }
    

    public static void ShowBalance(){
        foreach(AccountInfo account in listAccountInfo){
          
                System.Console.WriteLine("Your Balance is : "+account.Balance);
            
        }
        
    }
    public static void ShowAccountInfo(){
        foreach(AccountInfo account in listAccountInfo){
            System.Console.WriteLine("Account Details ...........! ");
            System.Console.WriteLine("Name : "+account.Name);
            System.Console.WriteLine("Father Name : "+account.FatherName);
            System.Console.WriteLine("Account Number : "+account.AccountNumber);
            System.Console.WriteLine("Your Balance is"+account.Balance);
            System.Console.WriteLine("Balance : "+account.BranchName);
            System.Console.WriteLine("Gender : "+account.Gender);
            System.Console.WriteLine("IFSC Code : "+account.IFSCCode);
            System.Console.WriteLine("Mobile Number : "+account.Phone);
            System.Console.WriteLine("Show Details is completed for this person.......!");
        }
        
    }
}