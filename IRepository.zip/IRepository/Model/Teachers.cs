﻿using System.ComponentModel.DataAnnotations;

namespace TeachersApi.Model
{
    public class Teachers
    {

        [Key]
        public int TeacherId { get; set; }
        [Required]
        public string TeacherName { get; set; } = string.Empty;
        public string Class { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public Teachers(int teacherId, string teacherName, string @class, string lastName)
        {
            TeacherId = teacherId;
            TeacherName = teacherName;
            Class = @class;
            LastName = lastName;
        }
    }
}
