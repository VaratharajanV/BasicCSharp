
using Microsoft
public class SqlRepository
{
    private readonly DataContext _context;

    public TeacherController(DataContext context)
    {
        _context = context;
    }
    [HttpGet("GetTeachers")]

    public async Task<IActionResult> Get()
    {
        return Ok(await _context.MyDbSetTeachers.ToListAsync());
    }

    [HttpGet("GetSingleTeacherDetails")]
    public async Task<ActionResult<List<Teachers>>> GetSingleTeacher(int id)
    {


        var FindTeacher = await _context.MyDbSetTeachers.FindAsync(id);
        if (FindTeacher == null)
        {
            return BadRequest("Invalid Data");
        }

        return Ok(FindTeacher);
    }

    [HttpPost("AddTeachers")]
    public async Task<ActionResult<List<Teachers>>> AddTeacher(Teachers request)
    {
        _context.MyDbSetTeachers.Add(request);
        await _context.SaveChangesAsync();
        return Ok(await _context.MyDbSetTeachers.ToListAsync());
    }

    [HttpDelete("DeleteTeachers")]
    public async Task<ActionResult<List<Teachers>>> DeleteTeacher(int id)
    {

        var dBFindTeacher = await _context.MyDbSetTeachers.FindAsync(id);
        if (dBFindTeacher == null)
        {
            return BadRequest("Invalid Data");
        }
        _context.Remove(dBFindTeacher);
        await _context.SaveChangesAsync();
        return Ok(await _context.MyDbSetTeachers.ToListAsync());
    }

    [HttpPut("ModifyTeachers")]
    public async Task<ActionResult<List<Teachers>>> ModifyTeacher(int id, Teachers request)
    {

        var dBFindTeacher = await _context.MyDbSetTeachers.FindAsync(id);
        if (dBFindTeacher == null)
        {
            return BadRequest("Invalid Data");
        }
        dBFindTeacher.TeacherId = id;
        dBFindTeacher.TeacherName = request.TeacherName;
        dBFindTeacher.LastName = request.LastName;
        dBFindTeacher.Class = request.Class;
        await _context.SaveChangesAsync();

        return Ok(await _context.MyDbSetTeachers.ToListAsync());
    }
}