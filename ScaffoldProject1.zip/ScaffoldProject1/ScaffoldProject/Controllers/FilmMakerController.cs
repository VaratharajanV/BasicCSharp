﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ScaffoldProject.Data;
using ScaffoldProject.Models;

namespace ScaffoldProject.Controllers
{
    public class FilmMakerController : Controller
    {
        private readonly DataContext _context;

        public FilmMakerController(DataContext context)
        {
            _context = context;
        }

        // GET: FilmMaker
        public async Task<IActionResult> Index()
        {
            return View(await _context.FilmDirectors.ToListAsync());
        }

        // GET: FilmMaker/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var filmDirectors = await _context.FilmDirectors
                .FirstOrDefaultAsync(m => m.Id == id);
            if (filmDirectors == null)
            {
                return NotFound();
            }

            return View(filmDirectors);
        }

        // GET: FilmMaker/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: FilmMaker/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DirectorName,Id,MoviesCount,HitMoviesCount,BestOfHisMovies")] FilmDirectors filmDirectors)
        {
            if (ModelState.IsValid)
            {
                _context.Add(filmDirectors);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(filmDirectors);
        }

        // GET: FilmMaker/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var filmDirectors = await _context.FilmDirectors.FindAsync(id);
            if (filmDirectors == null)
            {
                return NotFound();
            }
            return View(filmDirectors);
        }

        // POST: FilmMaker/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DirectorName,Id,MoviesCount,HitMoviesCount,BestOfHisMovies")] FilmDirectors filmDirectors)
        {
            if (id != filmDirectors.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(filmDirectors);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FilmDirectorsExists(filmDirectors.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(filmDirectors);
        }

        // GET: FilmMaker/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var filmDirectors = await _context.FilmDirectors
                .FirstOrDefaultAsync(m => m.Id == id);
            if (filmDirectors == null)
            {
                return NotFound();
            }

            return View(filmDirectors);
        }

        // POST: FilmMaker/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var filmDirectors = await _context.FilmDirectors.FindAsync(id);
            if (filmDirectors != null)
            {
                _context.FilmDirectors.Remove(filmDirectors);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FilmDirectorsExists(int id)
        {
            return _context.FilmDirectors.Any(e => e.Id == id);
        }
    }
}
