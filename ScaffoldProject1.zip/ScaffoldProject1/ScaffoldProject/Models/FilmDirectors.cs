﻿using System.ComponentModel.DataAnnotations;

namespace ScaffoldProject.Models
{
    public class FilmDirectors
    {
        [Required]
        public string DirectorName { get; set; }
        [Key]
        public int Id { get; set; }
        public int  MoviesCount { get; set; }
        public int HitMoviesCount { get; set; }
        public string BestOfHisMovies { get; set; }
    }
}
