﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Linq;
using System.Net.Mail;

namespace AggregateFunctions;

class Program
{

    public static void Main()
    {
        String[] countries = { "India", "USA", "America","Thaiwan" };
        int minCountries = countries.Min(x=>x.Length);
        int maxCountries = countries.Max(x=>x.Length);
        Console.WriteLine(minCountries);
        Console.WriteLine(maxCountries);
    }
}