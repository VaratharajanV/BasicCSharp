﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System.Net.Mail;

namespace TakePartitioningOperators;

class Program
{

    public static void Main(string[] args)
    {
        var numbers = new List<int> { 1, 2, 3, 4, 5 };
        var firstThree = numbers.Take(3); // Results in { 1, 2, 3 }
        foreach (var number in firstThree)
        {
            Console.WriteLine(number);
        }
    }
}