﻿    using System.Security.Claims;


    namespace OrderBy;

    class Program
    {

        public static void Main(string[] args)
    {

            var numbers = new List<int> { 3, 1, 4, 1, 5, 9, 2 };
            var sortedNumbers = numbers.OrderBy(n => n);

            foreach (var number in sortedNumbers)
            {
                Console.WriteLine(number);
            }
            var people = new List<string> { "Alice", "Bob", "Charlie" };
            var sortedPeople = people.OrderBy(name => name);

            foreach (var peoples in sortedPeople)
            {
                Console.WriteLine(peoples);
            }

        }
    }
 