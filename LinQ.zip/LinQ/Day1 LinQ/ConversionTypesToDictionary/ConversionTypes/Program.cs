﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;

namespace ConversionTypes;

class Program
{

    public static void Main(string[] args)
    {

        var people = new List<Person>
        {
            new Person { Name = "John", Age = 30 },
            new Person { Name = "Jane", Age = 25 }
        };
        var dictionary = people.ToDictionary(p => p.Name, p => p.Age);
        //Console.WriteLine(dictionary);
        foreach (var person in dictionary)
        {
            Console.WriteLine(person);
        }
    }
}