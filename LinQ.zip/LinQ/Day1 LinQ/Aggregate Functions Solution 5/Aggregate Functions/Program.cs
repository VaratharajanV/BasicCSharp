﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Linq;
using System.Net.Mail;

namespace AggregateFunctions;

class Program
{

    public static void Main()
    {
        int[] numbers = { 1,2,3,5,6,7,8,9,0};
        int min= numbers.Where(x=> x%2 ==0).Min();
        int max = numbers.Where(x=>x%2==0).Max();
        int sum=numbers.Where(x=>x%2==0).Sum();
        int countOfAllEvenNumbers=numbers.Where(X=>X%2==0).Count();
        double averaageOfAllNumbers=numbers.Where(x=>x%2==0).Average();
        Console.WriteLine(min );
        Console.WriteLine(max );
        Console.WriteLine(sum);
        Console.WriteLine(countOfAllEvenNumbers);
        Console.WriteLine(averaageOfAllNumbers);
    }
}