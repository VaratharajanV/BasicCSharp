﻿// See https://aka.ms/new-console-template for more information
using System.Net.Mail;

namespace SelectSelectMany;
class Program
{

    public static void Main(string[] args)
    {
        List<Book> books = new List<Book>
        {
            new Book { Title = "C# Programming", Authors = new List<string> { "Author A", "Author B" } },
            new Book { Title = "LINQ Magic", Authors = new List<string> { "Author C", "Author A" } },
            new Book { Title = "ASP.NET Core", Authors = new List<string> { "Author B", "Author D" } }
        };

        // Project each book into a new form
        var bookSummaries = books.Select(b => new { b.Title, AuthorCount = b.Authors.Count });

        foreach (var summary in bookSummaries)
        {
            Console.WriteLine($"{summary.Title} has {summary.AuthorCount} authors.");
        }

        // Create a list of unique authors from all books
        var allAuthors = books.SelectMany(b => b.Authors).Distinct();

        Console.WriteLine("\nAuthors:");
        foreach (var author in allAuthors)
        {
            Console.WriteLine(author);
        }
    }
}
