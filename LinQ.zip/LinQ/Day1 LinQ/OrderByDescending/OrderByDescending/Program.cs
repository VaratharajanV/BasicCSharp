﻿namespace OrderBy;

class Program
{

    public static void Main(string[] args)
    {
        var numbers = new List<int> { 3, 1, 4, 1, 5, 9, 2 };
        var sortedNumbersDescending = numbers.OrderByDescending(n => n);

        foreach (var number in sortedNumbersDescending)
        {
            Console.WriteLine(number);
        }
    }
}
