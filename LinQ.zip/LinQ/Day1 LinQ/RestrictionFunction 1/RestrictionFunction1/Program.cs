﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;

namespace RestrictionFunction1;
class Program
{

    public static void Main(string[] args)
    {

        List<Person> people = new List<Person>
        {
            new Person { Name = "John", Age = 22 },
            new Person { Name = "Jane", Age = 20 },
            new Person { Name = "Jake", Age = 18 },
            new Person { Name = "Doe", Age = 17 },
            new Person { Name = "Julie", Age = 25 },
            new Person { Name = "Ann", Age = 30 }

        };

        // var filteredPeople = people.Where(p => p.Age > 18 && p.Name.StartsWith("J"));
        var filteredPeople = people.Where(p=>p.Age>18 && p.Name.StartsWith("J"));
        foreach (var person in filteredPeople)
        {
            Console.WriteLine($"Name: {person.Name}, Age: {person.Age}");
        }


    }
}