﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections;

namespace ConversionTypes;

class Program
{

    public static void Main(string[] args)
    {
        ArrayList list = new ArrayList();
        list.Add(1);
        list.Add(2);
        list.Add(3);
        list.Add(4);
        list.Add("A");
        list.Add("B");

        var result=list.Cast<int>();
        foreach(int i in result)
        {
            Console.WriteLine(i);
        }
    }
}