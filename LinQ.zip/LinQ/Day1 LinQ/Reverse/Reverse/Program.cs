﻿namespace Reverse;

using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] numbers = { 1, 2, 3, 4, 5 };

        // Reverse the array
        var reversedNumbers = numbers.Reverse();

        foreach (var number in reversedNumbers)
        {
            Console.WriteLine(number);
        }
        // Output will be: 5, 4, 3, 2, 1
    }
}

