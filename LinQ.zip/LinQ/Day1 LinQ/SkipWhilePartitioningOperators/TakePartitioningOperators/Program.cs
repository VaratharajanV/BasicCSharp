﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System.Net.Mail;

namespace TakePartitioningOperators;

class Program
{

    public static void Main(string[] args)
    {
        //var numbers = new List<int> { 1, 2, 3, 4, 5 };
        var numbers = new List<int> { 1, 3, 5, 7, 4, 9 };
        // var takeWhileLessThanSix = numbers.TakeWhile(n => n < 6); // Results in { 1, 3, 5 }
        var skipWhileLessThanSix = numbers.SkipWhile(n => n < 6); // Results in { 7, 4, 9 }  
                                                                  // Results in { 4, 5 }
                                                                  // Results in { 1, 2, 3 }
        foreach (var number in skipWhileLessThanSix)
        {
            Console.WriteLine(number);
        }
    }
}