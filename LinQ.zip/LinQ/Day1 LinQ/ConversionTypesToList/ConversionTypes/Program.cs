﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
namespace ConversionTypes;

class Program
{

    public static void Main(string[] args)
    {

        var numbers = new List<int> { 1, 2, 3, 4, 5 };
        var numbersList = numbers.Where(n => n > 2).ToList();

        foreach (var number in numbersList)
        {
            Console.WriteLine(number);
        }
    }
}