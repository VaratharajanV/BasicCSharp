﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
namespace DeferredExecution;

class Program
{

    public static void Main(string[] args)
    {
        var numbers = new List<int> { 1, 2, 3, 4, 5 };
        var query = numbers.Where(n => n > 3); // Query defined here, but not executed
        numbers.Add(6);
        foreach (var number in query)
        {
            Console.WriteLine(number);
        }


    }
}