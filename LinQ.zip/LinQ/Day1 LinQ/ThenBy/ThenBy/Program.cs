﻿using System;
using ThenBy;

namespace OrderBy;

class Program
{

    public static void Main(string[] args)
    {

        var people = new List<Person>
        {
    new Person { FirstName = "John", LastName = "Boe" },
    new Person { FirstName = "Bane", LastName = "Aoe" },
    new Person { FirstName = "Aohn", LastName = "Smith" }
};
        var sortedPeople = people.OrderBy(p => p.LastName).ThenBy(p => p.FirstName);

        foreach (var person in sortedPeople)
        {
            Console.WriteLine(person.FirstName+" "+person.LastName);
        }

    }
}