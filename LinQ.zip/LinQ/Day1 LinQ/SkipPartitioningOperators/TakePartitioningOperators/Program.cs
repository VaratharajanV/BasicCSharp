﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System.Net.Mail;

namespace TakePartitioningOperators;

class Program
{

    public static void Main(string[] args)
    {
        var numbers = new List<int> { 1, 2, 3, 4, 5 };
        var nextTwo = numbers.Skip(3); // Results in { 4, 5 }
                                       // Results in { 1, 2, 3 }
        foreach (var number in nextTwo)
        {
            Console.WriteLine(number);
        }
    }
}