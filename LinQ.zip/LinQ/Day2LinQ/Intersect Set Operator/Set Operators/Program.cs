﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
namespace SetOperators;

class Program
{
    public static void Main(string[] args)
    {
        int[] first = { 1, 2, 3, 4 };
        int[] second = { 3, 4, 5, 6 };
        var commonElements = first.Intersect(second);

        // Result: 3, 4


        // Result: 1, 2, 3, 4, 5


        // Result: 1, 2, 3, 4, 5
        foreach (int number in commonElements)
        {
            Console.WriteLine(number);
        }

    }
}
