﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }
}

public class Program
{
    public static void Main()
    {
        List<Person> people = new List<Person>
        {
            new Person { Name = "Alice", Age = 30 },
            new Person { Name = "Bob", Age = 25 },
            new Person { Name = "Charlie", Age = 30 },
            new Person { Name = "David", Age = 25 },
            new Person { Name = "Eve", Age = 35 }
        };

        var groupedByAge = from person in people
                           group person by person.Age;
                      

        foreach (var group in groupedByAge)
        {
            Console.WriteLine($"Age Group: {group.Key} and count is {group.Count()}");
           
        }
    }
}
