﻿namespace OrderBy;

class Program
{

    public static void Main(string[] args)
    {
        int[] numbers = { 2, 4, 6, 8, 10 };
        var numberslist = numbers.DefaultIfEmpty(0);
        foreach (int number in numberslist)
        {
            Console.Write(number+" ");
        }
        Console.WriteLine();
        int firstNumber = numbers.First();
        Console.WriteLine(firstNumber);
        // Result: 2
        int firstOddNumber = numbers.FirstOrDefault(n => n % 2 != 0);
        // Result: 0 (since there are no odd numbers, it returns the default value for int, which is 0)
        Console.WriteLine(firstOddNumber);
        int lastNumber = numbers.Last();
        Console.WriteLine(lastNumber);
        // Result: 10
        int lastOddNumber = numbers.LastOrDefault(n => n % 2 != 0);
        // Result: 0 (since there are no odd numbers, it returns the default value for int)
        Console.WriteLine(lastOddNumber);
        int[] oneNumber = { 9 };
        int singleNumber = oneNumber.Single();
        Console.WriteLine(singleNumber);
        // Result: 9
        int[] noNumbers = { };
        int singleOrDefaultNumber = noNumbers.SingleOrDefault();
        // Result: 0 (since the array is empty, it returns the default value for int)
        Console.WriteLine(singleOrDefaultNumber);
        int thirdNumber = numbers.ElementAt(2);
        Console.WriteLine(thirdNumber);
        // Result: 6
        int tenthNumber = numbers.ElementAtOrDefault(9);
        // Result: 0 (since there is no 10th element, it returns the default value for int)
        Console.WriteLine(tenthNumber);

    }
}
