﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Person
{
    public string Name { get; set; }
    public string City { get; set; }
    public string Job { get; set; }
}

public class Program
{
    public static void Main()
    {
        List<Person> people = new List<Person>
        {
            new Person { Name = "Alice", City = "New York", Job = "Developer" },
            new Person { Name = "Bob", City = "Boston", Job = "Designer" },
            new Person { Name = "Charlie", City = "New York", Job = "Developer" },
            new Person { Name = "Diana", City = "Boston", Job = "Developer" },
            new Person { Name = "Eve", City = "New York", Job = "Designer" }
        };

        var groupedPeople = from person in people
                            group person by new { person.City, person.Job } into cityJobGroup
                            select new
                            {
                                City = cityJobGroup.Key.City,
                                Job = cityJobGroup.Key.Job,
                                Persons = cityJobGroup.ToList()
                            };

        foreach (var group in groupedPeople)
        {
            Console.WriteLine($"City: {group.City}, Job: {group.Job}");
            foreach (var person in group.Persons)
            {
                Console.WriteLine($" - {person.Name}");
            }
        }
    }
}