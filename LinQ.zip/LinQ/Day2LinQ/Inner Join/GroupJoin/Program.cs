﻿// See https://aka.ms/new-console-template for more information

namespace GroupJoin;

class Program
{

    public static void Main(string[] args)
    {

        List<Author> authors = new List<Author>
{
    new Author { AuthorId = 1, Name = "Author One" },
    new Author { AuthorId = 2, Name = "Author Two" },
    new Author { AuthorId = 3, Name = "Author Three" }
};

        List<Book> books = new List<Book>
{
    new Book { Title = "Book A", AuthorId = 1 },
    new Book { Title = "Book B", AuthorId = 1 },
    new Book { Title = "Book C", AuthorId = 2 },
    new Book { Title = "Book D", AuthorId = 2 },
   
};

        var innerJoinQuery = from book in books
                             join author in authors on book.AuthorId equals author.AuthorId
                             select new { BookTitle = book.Title, AuthorName = author.Name };


        foreach (var item in innerJoinQuery)
        {
            Console.WriteLine($"Book: {item.BookTitle}, Author: {item.AuthorName}");
        }



    }
}
public class Author
{
    public int AuthorId { get; set; }
    public string Name { get; set; }
}

public class Book
{
    public string Title { get; set; }
    public int AuthorId { get; set; }
}


