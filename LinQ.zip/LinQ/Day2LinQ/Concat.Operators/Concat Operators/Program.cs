﻿namespace OrderBy;

class Program
{

    public static void Main(string[] args)
    {

        int[] first = { 1, 2, 3 };
        int[] second = { 4, 5, 6 };

        var combined = first.Concat(second);
        foreach(var i in combined)
        {
            Console.WriteLine(i);
        }
    }
}
