﻿using System.Globalization;

namespace OrderBy;

class Program
{

    public static void Main(string[] args)
    {

        int[] sequence1 = { 1, 2, 3, 4 };
        int[] sequence2 = { 1, 2, 3, 4 };
        int[] sequence3 = { 4, 3, 2, 1 };

        bool isEqual1 = sequence1.SequenceEqual(sequence2); // true
        bool isEqual2 = sequence1.SequenceEqual(sequence3); // false
        Console.WriteLine(isEqual1);
        Console.WriteLine(isEqual2);
    }
}
