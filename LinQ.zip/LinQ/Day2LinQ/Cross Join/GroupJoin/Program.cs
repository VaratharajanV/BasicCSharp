﻿// See https://aka.ms/new-console-template for more information

namespace GroupJoin;

class Program
{

    public static void Main(string[] args)
    {

        List<Author> authors = new List<Author>
{
    new Author { AuthorId = 1, Name = "Author One" },
    new Author { AuthorId = 2, Name = "Author Two" },
    new Author { AuthorId = 3, Name = "Author Three" }
};

        List<Book> books = new List<Book>
{
    new Book { Title = "Book A", AuthorId = 1 },
    new Book { Title = "Book B", AuthorId = 1 },
    new Book { Title = "Book C", AuthorId = 2 },
    new Book { Title = "Book D", AuthorId = 2 },
   
};


        var result = from a in authors
                     from b in books
                     select new
                     {
                         a,
                         b
                     };
        foreach (var v in result)
        {
            Console.WriteLine(v.a.Name +" "+v.b.Title);
        }



    }
}
public class Author
{
    public int AuthorId { get; set; }
    public string Name { get; set; }
}

public class Book
{
    public string Title { get; set; }
    public int AuthorId { get; set; }
}


