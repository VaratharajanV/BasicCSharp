﻿namespace OrderBy;

class Program
{

    public static void Main(string[] args)
    {
        var emptySequence = Enumerable.Empty<int>();
        foreach (var sequence in emptySequence)
        {
            Console.WriteLine(emptySequence);
        }
        var repeatedSequence = Enumerable.Repeat("Hello", 3);
        // Result: "Hello", "Hello", "Hello"
        foreach (var sequence in repeatedSequence)
        {
            Console.Write(sequence+" ");
        }
        Console.WriteLine();
        var numberSequence = Enumerable.Range(1, 5);
        // Result: 1, 2, 3, 4, 5
        foreach (var sequence in numberSequence)
        {
            Console.Write(sequence+" ");
        }


    }
}
