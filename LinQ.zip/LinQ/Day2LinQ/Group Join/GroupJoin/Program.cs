﻿// See https://aka.ms/new-console-template for more information

namespace GroupJoin;

class Program
{

    public static void Main(string[] args)
    {

        List<Author> authors = new List<Author>
{
    new Author { AuthorId = 1, Name = "Author One" },
    new Author { AuthorId = 2, Name = "Author Two" },
    new Author { AuthorId = 3, Name = "Author Three" }
};

        List<Book> books = new List<Book>
{
    new Book { Title = "Book A", AuthorId = 1 },
    new Book { Title = "Book B", AuthorId = 1 },
    new Book { Title = "Book C", AuthorId = 2 }
};

        var groupJoinQuery = from author in authors
                             join book in books on author.AuthorId equals book.AuthorId into bookGroup
                             select new
                             {
                                 AuthorName = author.Name,
                                 Books = bookGroup
                             };

        foreach (var authorGroup in groupJoinQuery)
        {
            Console.WriteLine($"Author: {authorGroup.AuthorName}");
            foreach (var book in authorGroup.Books)
            {
                Console.WriteLine($"\tBook: {book.Title}");
            }
        }


    }
}
public class Author
{
    public int AuthorId { get; set; }
    public string Name { get; set; }
}

public class Book
{
    public string Title { get; set; }
    public int AuthorId { get; set; }
}


