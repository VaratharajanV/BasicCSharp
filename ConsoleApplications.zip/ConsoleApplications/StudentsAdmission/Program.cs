﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
namespace StudentsAdmission;
public class Program{
        public static List<StudentDetails> studentList=new List<StudentDetails>();
        public static List<DepartmentDetails> departmentList=new List<DepartmentDetails>();
        static List<AdmissionDetails> admissionList=new List<AdmissionDetails>();
        public static StudentDetails CurrentStudent;
        public static DepartmentDetails CurrentDepartment;
    
    public static void Main(string[] args)
    {
        
        defaultDetails();
        MainMenu();
        
    }
    public static void defaultDetails(){
         
    
        StudentDetails student1=new StudentDetails("Ravichandran E"	,"Ettapparajan"	,DateTime.Parse("11/11/1999"),Gender.Male,	95	,95	,95);
        studentList.Add(student1);
        StudentDetails student2=new StudentDetails("Baskaran S","Sethurajan",DateTime.Parse("11/11/1999"),Gender.Male,	95	,95	,95);
        studentList.Add(student2);
  
   
        DepartmentDetails department1=new DepartmentDetails("EEE",29);
        DepartmentDetails department2=new DepartmentDetails("CSE",29);
        DepartmentDetails department3=new DepartmentDetails("MECH",30);
        DepartmentDetails department4=new DepartmentDetails("ECE",30);
        departmentList.Add(department1);
        departmentList.Add(department2);
        departmentList.Add(department3);
        departmentList.Add(department4);

       

        AdmissionDetails admission1=new AdmissionDetails("SF3001"	,"DID101",DateTime.Now,AdmissionStatus.Booked);
        AdmissionDetails admission2=new AdmissionDetails("SF3002"	,"DID102",DateTime.Now,AdmissionStatus.Booked);
        admissionList.Add(admission1);
        admissionList.Add(admission2);
        }
        public static void MainMenu(){
            System.Console.WriteLine("Welcome to Application For Students Admission in College");
            bool flag=true;
            do{
                System.Console.WriteLine("Enter \n 1.	Student Registration\n2.Student Login\n3.Department wise seat availability\n4.Exit");
                int option=Convert.ToInt32(Console.ReadLine());
                switch(option){
                    case 1:
                    {
                        StudentRegistration();
                        break;
                    }
                    case 2:
                    {
                        StudentLogin();
                        break;
                    }
                    case 3:
                    {
                        DepartmentSeatAvailability();
                        break;
                    }
                    case 4:
                    {
                        flag=false;
                        break;
                    }
                }
                
            }while(flag==true);
        }


        public static void StudentRegistration(){
          

            System.Console.WriteLine("Enter Student Name");
            string studentName=Console.ReadLine().ToLower();
            System.Console.WriteLine("Enter Father Name");
            string fatherName=Console.ReadLine().ToLower();
            System.Console.WriteLine("Enter Gender");
            
            Gender gender=Enum.Parse<Gender>(Console.ReadLine(),true);

             System.Console.WriteLine("Enter your dob");
             DateTime dOB=DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null);

            System.Console.WriteLine("Enter Physics Marks");
            int physics=Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("Enter Chemsitry Marks");
            int chemistry=Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("Enter Maths Mark");
            int maths=Convert.ToInt32(Console.ReadLine());
            StudentDetails student3=new StudentDetails(studentName,fatherName,dOB,gender,physics,chemistry,maths);
            studentList.Add(student3);
            System.Console.WriteLine("Successfully User Registration Completed..!Your StudentID is "+student3.StudentID);
            
            
        }
        public static void StudentLogin(){

            //2.	If student, select option ‘2’ ask student ID of student and verify the student id is valid. If it is valid, then show following Submenu. 	
//a.	Check Eligibility
//b.	Show Details
//c.	Take Admission
//d.	Cancel Admission
//e.	Show Admission Details
//f.	Exit

            System.Console.WriteLine("Welcome To Student Login Page : ");
            System.Console.WriteLine("Enter Sudent Id ");
            string userStudentId=(Console.ReadLine());
            string choice="yes";
             bool flag=true;
            foreach(StudentDetails student in studentList){
                if(userStudentId==student.StudentID){
                      flag=false;
               
                CurrentStudent=student;
                    do{

                        System.Console.WriteLine("Enter\n 1 Check eligibility\n 2 show details\n 3 Take admission\n 4 cancell admission\n 5 show admisson details\n 6 exit");
                    int suboption=Convert.ToInt32(Console.ReadLine());

                    switch(suboption){
                        case 1:
                        {
                            ChcekEligibility();
                            break;
                        }
                        case 2:
                        {
                            ShowDetails();
                            break;
                        }
                        case 3:
                        {
                            TakeAdmission();
                            break;
                        }
                        case 4:
                        {
                            CancellAdmission();
                            break;
                        }
                        case 5:
                        {
                            ShowAdmission();
                            break;
                        }
                        case 6:
                        {
                            choice="no";
                            break;
                        }
                        default:
                        {
                            System.Console.WriteLine("You entered wrong Input");
                            break;
                        }

                    }
                    }while(choice=="yes");
                    
                }
            }
            if(flag){
                System.Console.WriteLine("Invalid LoginID");
            }
            



            

        }
        public static void  DepartmentSeatAvailability(){
            foreach(DepartmentDetails department in departmentList){
                System.Console.Write(department.DepartmentName);
                System.Console.WriteLine(" "+department.NumberOfSeats);
            }
        }
        public static void ChcekEligibility(){
                if(CurrentStudent.CheckEligibility(75)){
                    System.Console.WriteLine("Student is Eligible ....!");
                }
                else{
                    System.Console.WriteLine("Student is not Eligible ...!");
                }

        }
        public static void ShowDetails(){
            foreach(StudentDetails student in studentList){
                System.Console.WriteLine(""+student.StudentID);
                System.Console.WriteLine(""+student.StudentName);
                System.Console.WriteLine(" "+student.FatherName);
                System.Console.WriteLine(" "+student.Maths);
                System.Console.WriteLine(" "+student.Chemistry);
                System.Console.WriteLine(" "+student.Physics);
                System.Console.WriteLine(""+student.DOB);
                System.Console.WriteLine(""+student.Gender);
                System.Console.WriteLine();
            }
        }
         public static void CancellAdmission(){
            /*
            •	Show the current logged in student’s admission detail by traversing the list which AdmissionStatus Property is Booked. If fount then show it.
•	Change the Admission status property to Cancelled.
•	Return the seat to Department Details list
•	Finally show admission cancelled successfully.
            */
            foreach(AdmissionDetails admission in admissionList){
                if(CurrentStudent.StudentID==admission.StudentID) {
                   
                    if(AdmissionStatus.Booked==admission.AdmissionStatus){
                        System.Console.WriteLine("Property is Cancelled..!!!");
                        admission.AdmissionStatus=AdmissionStatus.Cancelled;
                        CurrentDepartment.NumberOfSeats+=1;
                        //System.Console.WriteLine("");
                         System.Console.WriteLine();
                    System.Console.WriteLine("Admission Date : "+admission.AdmissionDate);
                    System.Console.WriteLine("Admission ID : "+admission.AdmissionID);
                    System.Console.WriteLine("Department ID :"+admission.DepartmentID);
                    System.Console.WriteLine("Admission Status : "+admission.AdmissionStatus);
                    System.Console.WriteLine();

                        
                    }
                }
            }

            
        }
        public static void TakeAdmission(){
            /*
            •	Show the list of available departments and number of seats available by traversing the department details list
•	Ask the student to pick one DepartmentID.
•	Validate the DepartmentID is present in the list. If it is present, then check whether he is eligible to take admission.
•	If he is eligible, check whether seat available or not, if seats available then Check whether the student has already taken any admission by traversing admission details list. If he didn’t took any admission previously. 
•	Then, Reduce the seat count in department list and create admission details object by using StudentID, DepartmentID, AdmissionDate as Now, AdmissionStatus and Booked and add it to list.
•	Finally show “Admission took successfully. Your admission ID – SF3001”.
            */
            foreach(DepartmentDetails department in departmentList){
                System.Console.WriteLine(" "+department.DepartmentID);
                System.Console.WriteLine(" "+department.DepartmentName);
                System.Console.WriteLine(" "+department.NumberOfSeats);
            }

            System.Console.WriteLine("Enter your Picked DepartmentID : ");
            string userDepartID=Console.ReadLine();
            bool flagDep=true;
             bool flag=true;
            foreach(DepartmentDetails department in departmentList){
                if(userDepartID==department.DepartmentID){
                    CurrentDepartment=department;
                    flagDep=false;
                    bool x=CurrentStudent.CheckEligibility(75);
                    if(x){
                        System.Console.WriteLine("Great News . You are Eligible ....");
                        if(department.NumberOfSeats>0){
                            System.Console.WriteLine("Seat Available");
                           
                           foreach(AdmissionDetails admission in admissionList){
                                if(CurrentStudent.StudentID==admission.StudentID){
                                    flag=false;
                                    CurrentDepartment=department;
                                    System.Console.WriteLine("You already enrolled..!"+admission.StudentID);
                                }   
                                                        
                           }if(flag){
                                System.Console.WriteLine("");
                                department.NumberOfSeats-=1;
                                //string studentID, string departmentID, DateTime admissionDate,AdmissionStatus admissionStatus
                                AdmissionDetails admission=new AdmissionDetails(CurrentStudent.StudentID,department.DepartmentID,DateTime.Now,AdmissionStatus.Booked);
                                admissionList.Add(admission);
                                System.Console.WriteLine("Admission took successfully. Your admission ID : "+admission.AdmissionID);
                                System.Console.WriteLine("Have a great journey with Us...!!!!");
                           }
                           

                        }
                    }
                    

                }
                
                
             
            }
               if(flagDep){
                    System.Console.WriteLine("Enter Coorect Department ID...!");
                }
            
        }
        public static void ShowAdmission(){
            foreach(AdmissionDetails admission in admissionList){
                if(admission.StudentID==CurrentStudent.StudentID){
                      System.Console.WriteLine();
                    System.Console.WriteLine("Admission Date : "+admission.AdmissionDate);
                    System.Console.WriteLine("Admission ID : "+admission.AdmissionID);
                    System.Console.WriteLine("Department ID :"+admission.DepartmentID);
                    System.Console.WriteLine("Admission Status : "+admission.AdmissionStatus);
                    System.Console.WriteLine();
            }
            }
            
        }





}