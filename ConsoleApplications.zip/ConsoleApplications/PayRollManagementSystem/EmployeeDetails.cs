using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
public enum Gender{male,female,transgender}
public enum Branch{Enum , Eymard, Karuna, Madhura}
public enum Team{Network, Hardware, Developer, Facility}

namespace PayRollManagementSystem
{
    public class EmployeeDetails
    {
        //Employee Details Class

//Properties:
//•	EmployeeID – (Auto Generated- SF3000)
//•	Full Name
//•	DOB
//•	MobileNumber
//•	Gender
//•	Branch – (Enum – Eymard, Karuna, Madhura)
//•	Team – (Network, Hardware, Developer, Facility)
//Default Employee Details:
//EmployeeID	Full Name
//	DOB
//	MobileNumber
//	Gender
//	Branch Enum – Eymard, Karuna, Madhura)
//•	Team – (Network, Hardware, Developer, Facility)

    private int s_employeeID=2999;

        

        public string EmployeeID { get; set; }
    public string FullName { get; set; }
    public DateTime DOB { get; set; }
    public long MobileNumber { get; set; }
    public Enum Gender { get; set; }
    public Enum Branch { get; set; }
    public Enum Team  { get; set; }


    public EmployeeDetails( string fullName, DateTime dOB, long mobileNumber, Enum gender, Enum branch, Enum team)
        {
            s_employeeID++;
            EmployeeID = "SF"+s_employeeID;
            FullName = fullName;
            DOB = dOB;
            MobileNumber = mobileNumber;
            Gender = gender;
            Branch = branch;
            Team = team;
        }

    }
}