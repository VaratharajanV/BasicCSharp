using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineGroceryShop
{
    
    public class CustomerDetails : PersonalDetails, IBalance
    {

        private double _balance;
        private static int s_customerID = 1000;
        public string CustomerID { get; }
        public double WalletBalance { get { return _balance; } }
        public CustomerDetails(double balance, string name, string fatherName, Gender gender, long mobileNumber, DateTime dOB, string mailID) : base(name, fatherName, gender, mobileNumber, dOB, mailID)
        {
            s_customerID++;
            CustomerID = "CID" + s_customerID;
            _balance = balance;
        }
        public void WalletRecharge(double amount)
        {
            _balance += amount;
        }
        public void DeductBalance(double amount){
            _balance-=amount;
        }
    }
}