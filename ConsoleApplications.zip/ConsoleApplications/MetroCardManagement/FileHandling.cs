using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MetroCardManagement
{
    public class FileHandling
    {
        public static void Create()
        {
           
            //create folder
            if (!Directory.Exists("MetroCardManagement"))
            {
                System.Console.WriteLine("Creating Folder");
                Directory.CreateDirectory("MetroCardManagement");
            }


            //File for UserDetails

            if (!File.Exists("MetroCardManagement/UserDetails.csv"))
            {
                System.Console.WriteLine("Creating File");
                File.Create("MetroCardManagement/UserDetails.csv").Close();
            }

            //File for TravelDetails
            if (!File.Exists("MetroCardManagement/TravelDetails.csv"))
            {
                System.Console.WriteLine("Creating File");
                File.Create("MetroCardManagement/TravelDetails.csv").Close();
            }
            //File for TicketFairDetails 
            if (!File.Exists("MetroCardManagement/TicketFairDetails.csv"))
            {
                System.Console.WriteLine("Creating File");
                File.Create("MetroCardManagement/TicketFairDetails.csv").Close();
            }
        }
        public static void WriteToCSV()
        {
            //Students
            string[] UserDetails = new string[Program.listUserDetails.Count()];
            for (int i = 0; i < Program.listUserDetails.Count; i++)
            {

                UserDetails[i] = Program.listUserDetails[i].CardNumber + "," + Program.listUserDetails[i].UserName + "," + Program.listUserDetails[i].MobileNumber + "," + Program.listUserDetails[i].Balance;
            }
            File.WriteAllLines("MetroCardManagement/UserDetails.csv", UserDetails);

            //TraVEL Details
            string[] TravelDetails = new string[Program.listTravelDetails.Count];
            for (int i = 0; i < Program.listTravelDetails.Count; i++)
            {
                TravelDetails[i] = Program.listTravelDetails[i].TravelID + "," + Program.listTravelDetails[i].CardNumber + "," + Program.listTravelDetails[i].FromLocation + "," + Program.listTravelDetails[i].ToLocation + "," +Program.listTravelDetails[i].Date.ToString("dd/MM/yyyy")+","+ Program.listTravelDetails[i].TravelCost;
            }
            File.WriteAllLines("MetroCardManagement/TravelDetails.csv", TravelDetails);
            //Ticket FairDetails

            string[] TicketFairDetails = new string[Program.listTicketFairDetails.Count];

            for (int i = 0; i < Program.listTicketFairDetails.Count; i++)
            {
                TicketFairDetails[i] = Program.listTicketFairDetails[i].TicketID + "," + Program.listTicketFairDetails[i].FromLocation + "," + Program.listTicketFairDetails[i].ToLocation + "," + Program.listTicketFairDetails[i].TicketPrice;

            }
            File.WriteAllLines("MetroCardManagement/TicketFairDetails.csv ", TicketFairDetails);
        }

        public static void ReadFromCsv(){
            string[] UserInfo = File.ReadAllLines("MetroCardManagement/UserDetails.csv");
            foreach(string user in UserInfo){
                Userdetails user1=new Userdetails(user);
                Program.listUserDetails.Add(user1);
            }

            string[] TravelInfo = File.ReadAllLines("MetroCardManagement/TravelDetails.csv");
            foreach(string travel in TravelInfo){
                TravelDetails travel1=new TravelDetails(travel);
                Program.listTravelDetails.Add(travel1);
            }
            string[] TicketFairInfo = File.ReadAllLines("MetroCardManagement/TicketFairDetails.csv");
            foreach(string ticketFair in TicketFairInfo){
                TicketFairDetails ticketFair1=new TicketFairDetails(ticketFair);
                Program.listTicketFairDetails.Add(ticketFair1);
            }


        }
    }
}