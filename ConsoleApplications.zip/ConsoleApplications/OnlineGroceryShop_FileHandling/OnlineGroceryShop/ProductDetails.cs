using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineGroceryShop
{
    public class ProductDetails
    {
      // Properties: ProductID {Auto Increment – PID2000}, ProductName, QuantityAvailable, PricePerQuantity
       private static int s_productID=2000;
       public string  ProductID { get;  }
       public string ProductName { get; set; }
       public int QuantityAvailable { get; set; }
       public double PricePerQuantity { get; set; }


        public ProductDetails( string productName, int quantityAvailable, double pricePerQuantity)
        {
            s_productID++;
            ProductID ="PID"+ s_productID;
            ProductName = productName;
            QuantityAvailable = quantityAvailable;
            PricePerQuantity = pricePerQuantity;
        }

        public ProductDetails(string productDetails1)
        {
            //ProductID	ProductName	QuantityAvailable	PricePerQuantity
            string[] value = productDetails1.Split(',');
            ProductID=value[0];
            s_productID=int.Parse(value[0].Remove(0,3));
            ProductName=value[1];
            QuantityAvailable=int.Parse(value[2]);
            PricePerQuantity=double.Parse(value[3]);

            
        }
    } 
}