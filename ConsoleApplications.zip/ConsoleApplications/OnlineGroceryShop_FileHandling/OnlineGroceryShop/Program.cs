﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
namespace OnlineGroceryShop;
public class Program
{

    public static void Main(string[] args)
    {
        FileHandling.CreatingFolders();
        Operations.LoadDefaultDatas();
        FileHandling.WriteToCSV();
        Operations.MainMenu();
        //FileHandling.ReadFromCSV();
    }

}