using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineGroceryShop
{
    public class Operations
    {
        public static List<CustomerDetails> customerDetailsList = new List<CustomerDetails>();
        public static List<ProductDetails> productDetailsList = new List<ProductDetails>();
        public static List<BookingDetails> bookingDetailsList = new List<BookingDetails>();
        public static List<OrderDetails> orderDetailsList = new List<OrderDetails>();

        public static CustomerDetails currentCusotmerDetail;



        public static void MainMenu()
        {
            string flag = "yes";
            do
            {
                System.Console.WriteLine("Main Manu:");
                System.Console.WriteLine("1.	Customer Registration");
                System.Console.WriteLine("2.	Customer Login");
                System.Console.WriteLine("3.	Exit");
                System.Console.Write("Enter Your Choice : ");
                int choice;
                while (!int.TryParse(Console.ReadLine(), null, out choice))
                {
                    System.Console.WriteLine("Invalid Choice. Enter Again.");
                }
                switch (choice)
                {
                    case 1:
                        {
                            Registration();
                            break;
                        }
                    case 2:
                        {
                            Login();
                            break;
                        }
                    case 3:
                        {
                            flag = "No";
                            System.Console.WriteLine("Exiting. Thankyou for visiiting ");
                            break;
                        }
                }


            } while (flag == "yes");
        }

        public static void Registration()
        {
            System.Console.WriteLine("Welcome to Registration");
            System.Console.WriteLine();
            System.Console.Write("Enter the Balance Amount :");
            double balance;
            while (!double.TryParse(Console.ReadLine(), null, out balance))
            {
                System.Console.Write("Invalid Amount.Enter Again");
            }
            System.Console.Write("Enter Your Name: ");
            string name = Console.ReadLine();
            System.Console.Write("Enter your FatherName:");
            string fatherName = Console.ReadLine();

            System.Console.Write("Select Your Gender Either by Number or BY Gender Types: (1.Male 2.Female 3.Transgender): ");
            Gender gender;
            while (!Enum.TryParse<Gender>(Console.ReadLine(), true, out gender))
            {
                System.Console.Write("Invalid Selection. Enter Again.");
            }


            System.Console.Write("Enter Your Mobile Number: ");
            long mobileNumber;
            while (!long.TryParse(Console.ReadLine(), null, out mobileNumber))
            {
                System.Console.Write("Invalid Mobile Number.");
            }

            System.Console.Write("Enter Your DOB:");
            DateTime dob;
            while (!DateTime.TryParseExact(Console.ReadLine(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out dob))
            {
                System.Console.Write("Invalid DateOFBirth.enter Again");

            }
            System.Console.Write("Enter the MailID");
            string mailID = Console.ReadLine();

            CustomerDetails customerDetails = new CustomerDetails(balance, name, fatherName, gender, mobileNumber, dob, mailID);
            customerDetailsList.Add(customerDetails);
            System.Console.WriteLine("Your CustomerID is : " + customerDetails.CustomerID);
            System.Console.WriteLine("Your Registration Successfully Completed :)");

        }
        public static void Login()
        {
            System.Console.WriteLine("Login");
            System.Console.Write("Enter your Customer ID:");
            string userLoginID = Console.ReadLine().ToUpper();
            bool flag1 = true;
            foreach (CustomerDetails customerDetails in customerDetailsList)
            {
                if (customerDetails.CustomerID == userLoginID)
                {
                    flag1 = false;
                    currentCusotmerDetail = customerDetails;
                    System.Console.WriteLine("Login Validated.");
                    SubMenu();
                }
            }
            if (flag1)
            {
                System.Console.WriteLine("Invalid ID.");
            }

        }
        public static void SubMenu()
        {
            string flag = "yes";
            do
            {
                System.Console.WriteLine("Sub Menu");
                System.Console.WriteLine("a)	Show Customer Details");
                System.Console.WriteLine("b)	Show Product Details");
                System.Console.WriteLine("c)	Wallet Recharge");
                System.Console.WriteLine("d)	Take Order");
                System.Console.WriteLine("e)	Modify Order Quantity");
                System.Console.WriteLine("f)	Cancel Order");
                System.Console.WriteLine("g)	Show Balance");
                System.Console.WriteLine("h)    Booked History");
                System.Console.WriteLine("i)	Exit");
                System.Console.WriteLine("Enter Your option");
                char menu = char.Parse(Console.ReadLine());
                switch (menu)
                {
                    case 'a':
                        {
                            ShowCustomerDetails();
                            break;
                        }
                    case 'b':
                        {
                            ShowProductDetails();
                            break;
                        }
                    case 'c':
                        {
                            WalletRecharge();
                            break;
                        }
                    case 'd':
                        {
                            TakeOrder();
                            break;
                        }
                    case 'e':
                        {
                            ModifyOrderQuantity();
                            break;
                        }
                    case 'f':
                        {
                            CancelOrder();
                            break;
                        }
                    case 'g':
                        {
                            ShowBalance();
                            break;
                        }
                    case 'h':
                        {
                            BookedHistory();
                            break;
                        }
                    case 'i':
                        {
                            flag = "No";
                            break;
                        }

                }

            } while (flag == "yes");
        }
        //CustomerDetails
        public static void ShowCustomerDetails()
        {
            System.Console.WriteLine("Customer Details");
            foreach (CustomerDetails customerDetails in customerDetailsList)
            {
                if (currentCusotmerDetail.CustomerID == customerDetails.CustomerID)
                {
                    System.Console.WriteLine(customerDetails.CustomerID + "|" + customerDetails.WalletBalance + "|" + customerDetails.Name + "|" + customerDetails.FatherName + "|" + customerDetails.DOB);
                }
            }


        }
        //Available Stock Details
        public static void ShowProductDetails()
        {
            System.Console.WriteLine("Product Details");
            foreach (ProductDetails productDetails in productDetailsList)
            {
                if (productDetails.QuantityAvailable > 0)
                {
                    System.Console.WriteLine(productDetails.ProductID + "|" + productDetails.ProductName + "|" + productDetails.PricePerQuantity + "| " + productDetails.QuantityAvailable);
                }
            }
        }
        //Recharge
        public static void WalletRecharge()
        {
            System.Console.WriteLine("Enter the amount :");
            double amount = double.Parse(Console.ReadLine(), null);
            currentCusotmerDetail.WalletRecharge(amount);
            System.Console.WriteLine("Recharged Successfully..:)");
        }
        public static void TakeOrder()
        {
            List<OrderDetails> tempOrderDetailsList = new List<OrderDetails>();
            string flag4 = "YES";
            do
            {
                //     a.Ask customer that whether he want to purchase / not.
                System.Console.WriteLine("Enter Your choice If you want to purchase then enter YES .If you dont want to purchase then enter NO");
                string choice = Console.ReadLine().ToUpper();
                double totalPurchaseAmount = 0;

                switch (choice)
                {
                    case "YES":
                        {
                            //  If “Yes” means Create booking details object with Customer id, Total price = 0,
                            //  Booking status = Initiated.
                            BookingDetails bookingDetails = new BookingDetails(currentCusotmerDetail.CustomerID, 0, DateTime.Now, BookingStatus.Initiated);



                            //b.	Create a local order list named tempOrderList
                            ShowProductDetails();
                            //c.	Show product details of available stock. 

                            //d.	Ask the user to select a product by using ProductID validate it,

                            System.Console.Write("Enter Product ID that you want to purchase: ");
                            string requestedProductID = Console.ReadLine().ToUpper();
                            bool flag3 = true;
                            foreach (ProductDetails productDetails in productDetailsList)
                            {
                                if (requestedProductID == productDetails.ProductID)
                                {
                                    flag3 = false;
                                    System.Console.Write("Enter the Quantity You want: ");
                                    int quantity = int.Parse(Console.ReadLine());

                                    if (productDetails.QuantityAvailable >= quantity)
                                    {

                                        //e.Check whether the selected Purchase quantity is available in stock.
                                        double price = quantity * productDetails.PricePerQuantity;

                                        OrderDetails orderDetails1 = new OrderDetails(bookingDetails.BookingID, productDetails.ProductID, quantity, price);
                                        tempOrderDetailsList.Add(orderDetails1);
                                        // f.	If it is available means create order object with created BookingID,
                                        //  productID, quantity and price of order and store in tempOrder details list.

                                        productDetails.QuantityAvailable -= quantity;

                                        //   Deduct the purchase count from product details. 
                                        foreach (OrderDetails orderDetails in tempOrderDetailsList)
                                        {

                                            totalPurchaseAmount += orderDetails.PriceOfOrder;


                                        }

                                        // Calculate totalPurchaseAmount. And show Product successfully added to cart.
                                        System.Console.WriteLine("Product added successfully to the Cart.");
                                        System.Console.WriteLine("");
                                        //g.	Ask the customer whether he want to book another product.
                                        //If “yes” means again show Product details and repeat step “C” to “f” create new order object.
                                        // Repeat this process until he press “No”.

                                        //h.	After the above loop ask user Do you want to confirm the order.
                                        System.Console.WriteLine("DO You want to Confirm the order.");
                                        string choices = Console.ReadLine().ToUpper();

                                        while (choices == "YES")
                                        {

                                            // If he selects “yes” then check the user has enough balance. 
                                            if (currentCusotmerDetail.WalletBalance >= totalPurchaseAmount)
                                            {

                                                //If he has it means deduct the
                                                //  totalPurchaseAmount from wallet. Update the booking status to Booked, update total price, 
                                                currentCusotmerDetail.DeductBalance(totalPurchaseAmount);

                                                bookingDetails.BookingStatus = BookingStatus.Booked;
                                                bookingDetails.TotalPrice = totalPurchaseAmount;

                                                bookingDetailsList.Add(bookingDetails);
                                                orderDetailsList.AddRange(tempOrderDetailsList);
                                                //  and add the object to list. Add the tempOrderList to orderList. Show “Booking successful”.

                                                System.Console.WriteLine("Booked Successfully.");
                                                break;

                                            }
                                            else
                                            {
                                                //j.	If he don’t have it means show “Insufficient account balance recharge with”+totalPurchaseAmount and proceed with recharge option.
                                                // Repeat i step until he had enough balance
                                                System.Console.WriteLine("Insufficient account balance recharge with" + totalPurchaseAmount);
                                                WalletRecharge();
                                            }



                                        }
                                        if (choices == "NO")
                                        {
                                            //k.	If user select “No” then traverse tempOrderList update product count to product detail list.
                                            // And show cart removed successfully.
                                            foreach (OrderDetails orderDetails in tempOrderDetailsList)
                                            {
                                                if (productDetails.ProductID == orderDetails.ProductID)
                                                {
                                                    productDetails.QuantityAvailable += orderDetails.PurchaseCount;
                                                    System.Console.WriteLine("Cart Removed Successfully.");
                                                    break;
                                                }
                                            }
                                        }


                                    }
                                    else
                                    {
                                        System.Console.WriteLine("Quantity Available is less than your requested Quantity.");
                                    }

                                }
                            }
                            if (flag3)
                            {
                                // if it is ok then ask Purchase quantity else show “Invalid Product ID”.
                                System.Console.WriteLine("Invalid ProductID.");
                            }

                            break;
                        }
                    case "NO":
                        {
                            System.Console.WriteLine("Thankyou");
                            flag4 = "NO";
                            break;
                        }
                }


            } while (flag4 == "YES");
        }
        public static void ModifyOrderQuantity()
        {
            // a.	Show the booking details of current logged in user to pick a booking detail by using BookingID and whose status is “Booked”.
            // Check whether the booking details is present. If yes then,
            bool flag1 = true;
            double totalAmount = 0;
            foreach (BookingDetails bookingDetails in bookingDetailsList)
            {
                if (bookingDetails != null && currentCusotmerDetail.CustomerID == bookingDetails.CustomerID && bookingDetails.BookingStatus == BookingStatus.Booked)
                {
                    flag1 = false;
                    // b.	Show list of order details and ask the user to pick an order id.
                    foreach (OrderDetails orderDetails in orderDetailsList)
                    {
                        if (orderDetails.BookingID == bookingDetails.BookingID)
                        {
                            System.Console.WriteLine(orderDetails.OrderID + " | " + orderDetails.BookingID + "|" + orderDetails.ProductID + "|" + orderDetails.PriceOfOrder + "|" + orderDetails.PurchaseCount);
                        }
                    }
                    System.Console.Write("Enter the orderID you want to modify: ");
                    string requestedOrderID = Console.ReadLine().ToUpper();
                    // c.	Ensure the order ID is available and 

                    foreach (OrderDetails orderDetails in orderDetailsList)
                    {
                        if (orderDetails != null && orderDetails.OrderID == requestedOrderID && orderDetails.BookingID == bookingDetails.BookingID)
                        {
                            ////ask the user to enter the new quantity of the product.
                            System.Console.WriteLine("Enter the new product quantity.");
                            int requestedQuantity = int.Parse(Console.ReadLine());

                            foreach (ProductDetails productDetails in productDetailsList)
                            {
                                if (productDetails.ProductID == orderDetails.ProductID && requestedQuantity < productDetails.QuantityAvailable)
                                {
                                    // Calculate the order price and update in the order price.
                                    // d.	Calculate the total price of order and update in booking details entry. 
                                    // e.	Show order modified successfully.  
                                    int difference = 0;
                                    if (requestedQuantity > orderDetails.PurchaseCount)
                                    {
                                        difference = requestedQuantity - orderDetails.PurchaseCount;
                                        productDetails.QuantityAvailable -= requestedQuantity;
                                    }
                                    if (requestedQuantity < orderDetails.PurchaseCount)
                                    {
                                        difference = orderDetails.PurchaseCount - requestedQuantity;
                                        productDetails.QuantityAvailable += requestedQuantity;
                                    }
                                    double price = difference * productDetails.PricePerQuantity;
                                    orderDetails.PriceOfOrder = price;

                                    totalAmount += price;
                                    System.Console.WriteLine("Order Modified.");
                                    break;


                                }
                            }

                        }

                    }

                }
            }
            if (flag1)
            {
                System.Console.WriteLine("Not booked.");
            }
        }
        public static void CancelOrder()
        {

            foreach (BookingDetails bookingDetails in bookingDetailsList)
            {
                if (bookingDetails.BookingStatus == BookingStatus.Booked && bookingDetails.CustomerID == currentCusotmerDetail.CustomerID)
                {
                    // a.	Show the list of Bookings placed by current logged in user whose status is “Booked”.
                    System.Console.WriteLine(bookingDetails.CustomerID + "|" + bookingDetails.BookingID + "|" + bookingDetails.DateOfBooking + "|" + bookingDetails.TotalPrice + "|" + bookingDetails.BookingStatus);

                }

            }
            System.Console.Write("Enter the bookID you want to cancel: ");
            string requestedBookID = Console.ReadLine().ToUpper();
            // b.	Ask the user to pick a booking id.
            // If booking id is present, then change the booking status to “Cancelled”.
            foreach (BookingDetails bookingDetails in bookingDetailsList)
            {
                if (bookingDetails != null && bookingDetails.BookingID == requestedBookID)
                {
                    // c.	Refund the total price amount to current user. 
                    currentCusotmerDetail.WalletRecharge(bookingDetails.TotalPrice);
                    // d.	Return the product purchase count to product details.
                    foreach (OrderDetails orderDetails in orderDetailsList)
                    {
                        foreach (ProductDetails productDetails in productDetailsList)
                        {
                            if (productDetails.ProductID == orderDetails.ProductID)
                            {
                                productDetails.QuantityAvailable += orderDetails.PurchaseCount;
                                bookingDetails.BookingStatus = BookingStatus.Cancelled;
                                // e.	Show booking cancelled successfully.
                                System.Console.WriteLine("Booking cancelled Succesfully");
                                break;
                            }
                        }
                    }


                }
            }





        }
        public static void BookedHistory()
        {
            System.Console.WriteLine("Booked History");

            foreach (BookingDetails bookingDetails in bookingDetailsList)
            {
                if (currentCusotmerDetail.CustomerID == bookingDetails.CustomerID)
                {
                    System.Console.WriteLine(bookingDetails.BookingID + "|" + bookingDetails.BookingStatus + "|" + bookingDetails.CustomerID + "|" + bookingDetails.DateOfBooking.ToString("dd/MM/yyyy") + "|" + bookingDetails.TotalPrice);
                }
            }
        }
        public static void ShowBalance()
        {
            System.Console.WriteLine("Your Avail Balance: " + currentCusotmerDetail.WalletBalance);
        }

        //Load Default Data
        public static void LoadDefaultDatas()
        {


            CustomerDetails customerDetails1 = new CustomerDetails(10000, "Ravi", "	Ettapparajan", Gender.Male, 974774646, DateTime.ParseExact("11/11/1999", "dd/MM/yyyy", null), "ravi@gmail.com10000");
            customerDetailsList.Add(customerDetails1);
            CustomerDetails customerDetails2 = new CustomerDetails(150000, "Baskaran", "Sethurajan", Gender.Male, 847575775, DateTime.ParseExact("11/11/1999", "dd/MM/yyyy", null), "baskaran@gmail.com");
            customerDetailsList.Add(customerDetails2);

            //Product Details
            ProductDetails productDetails1 = new ProductDetails("Sugar", 20, 40);
            ProductDetails productDetails2 = new ProductDetails("Rice", 100, 50);
            ProductDetails productDetails3 = new ProductDetails("Milk", 10, 40);
            ProductDetails productDetails4 = new ProductDetails("Coffee", 10, 10);
            ProductDetails productDetails5 = new ProductDetails("Tea", 10, 10);
            ProductDetails productDetails6 = new ProductDetails("Masala Powder	", 10, 20);
            ProductDetails productDetails7 = new ProductDetails("Salt", 10, 10);
            ProductDetails productDetails8 = new ProductDetails("Turmeric Powder	", 10, 25);
            ProductDetails productDetails9 = new ProductDetails("Chilli Powder", 10, 20);
            ProductDetails productDetails10 = new ProductDetails("Groundnut Oil", 10, 140);
            productDetailsList.Add(productDetails1);
            productDetailsList.Add(productDetails2);
            productDetailsList.Add(productDetails3);
            productDetailsList.Add(productDetails4);
            productDetailsList.Add(productDetails5);
            productDetailsList.Add(productDetails6);
            productDetailsList.Add(productDetails7);
            productDetailsList.Add(productDetails8);
            productDetailsList.Add(productDetails9);
            productDetailsList.Add(productDetails10);

            BookingDetails bookingDetails1 = new BookingDetails("CID1001", 220, DateTime.ParseExact("26/07/2022", "dd/MM/yyyy", null), BookingStatus.Booked);

            BookingDetails bookingDetails2 = new BookingDetails("CID1002", 400, DateTime.ParseExact("26/07/2022", "dd/MM/yyyy", null), BookingStatus.Booked);
            BookingDetails bookingDetails3 = new BookingDetails("CID1001", 280, DateTime.ParseExact("26/07/2022", "dd/MM/yyyy", null), BookingStatus.Cancelled);

            BookingDetails bookingDetails4 = new BookingDetails("CID1002", 0, DateTime.ParseExact("26/07/2022", "dd/MM/yyyy", null), BookingStatus.Initiated);
            bookingDetailsList.Add(bookingDetails1);
            bookingDetailsList.Add(bookingDetails2);
            bookingDetailsList.Add(bookingDetails3);
            bookingDetailsList.Add(bookingDetails4);

            OrderDetails orderDetails1 = new OrderDetails("BID3001", "PID2001", 2, 80);
            OrderDetails orderDetails2 = new OrderDetails("BID3001", "PID2002", 2, 100);
            OrderDetails orderDetails3 = new OrderDetails("BID3001", "PID2003", 1, 40);
            OrderDetails orderDetails4 = new OrderDetails("BID3002", "PID2001", 1, 40);
            OrderDetails orderDetails5 = new OrderDetails("BID3002", "PID2002", 4, 200);
            OrderDetails orderDetails6 = new OrderDetails("BID3002", "PID2010", 1, 140);
            OrderDetails orderDetails7 = new OrderDetails("BID3002", "PID2009", 1, 20);
            OrderDetails orderDetails8 = new OrderDetails("BID3003", "PID2002", 2, 100);
            OrderDetails orderDetails9 = new OrderDetails("BID3003", "PID2008", 4, 100);
            OrderDetails orderDetails10 = new OrderDetails("BID3003", "PID2001", 2, 80);
            orderDetailsList.Add(orderDetails1);
            orderDetailsList.Add(orderDetails2);
            orderDetailsList.Add(orderDetails3);
            orderDetailsList.Add(orderDetails4);
            orderDetailsList.Add(orderDetails5);
            orderDetailsList.Add(orderDetails6);
            orderDetailsList.Add(orderDetails7);
            orderDetailsList.Add(orderDetails8);
            orderDetailsList.Add(orderDetails9);
            orderDetailsList.Add(orderDetails10);
            System.Console.WriteLine();
            foreach (OrderDetails orderDetails in orderDetailsList)
            {
                System.Console.WriteLine(orderDetails.OrderID + " | " + orderDetails.BookingID + "|" + orderDetails.ProductID + "|" + orderDetails.PriceOfOrder + "|" + orderDetails.PurchaseCount);
            }


        }


    }
}