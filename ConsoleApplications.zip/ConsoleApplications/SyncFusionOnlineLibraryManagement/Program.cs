﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
using SyncFusionOnlineLibraryManagement;
namespace SyncfusionOnlineLibraryManagement;
public class Program
{
    public static List<UserDetails> listUserDetails = new List<UserDetails>();
    public static List<BookDetails> listBookDetails = new List<BookDetails>();
    public static List<BorrowDetails> listBorrowDetails = new List<BorrowDetails>();

    public static UserDetails CurrentLoggedInUser;
    public static void Main(string[] args)
    {
        //SyncfusionOnlineLibraryManagement....!
        System.Console.WriteLine("!--------------Welcome To Online Synckart Library------!");
        DefaultData();
        MainMenu();
    }

    public static void DefaultData()
    {
        //UserDetails of Default
        UserDetails user1 = new UserDetails("Ravichandran", Gender.male, Department.EEE, 9938388333, "ravi@gmail.com", 100);
        UserDetails user2 = new UserDetails("Priyadharshini", Gender.female, Department.CSE, 9944444455, "priya@gmail.com", 150);
        listUserDetails.Add(user1);
        listUserDetails.Add(user2);
        //BookDetails of Default DataList
        BookDetails book1 = new BookDetails("C#", "Author1", 3);
        BookDetails book2 = new BookDetails("C", "Author2", 5);
        BookDetails book3 = new BookDetails("CSS", "Author1", 3);
        BookDetails book4 = new BookDetails("JS", "Author1", 3);
        BookDetails book5 = new BookDetails("TS", "Author2", 2);
        listBookDetails.Add(book1);
        listBookDetails.Add(book2);
        listBookDetails.Add(book3);
        listBookDetails.Add(book4);
        listBookDetails.Add(book5);
        //BorrowList of BorrowDefaultData List of Datas
        BorrowDetails borrow1 = new BorrowDetails("BID1001", "SF3001", new DateTime(10 / 09 / 2023), 2, Status.Borrowed, 0);
        //BID1003	SF3001	12/09/2023	1	Borrowed	0
        BorrowDetails borrow2 = new BorrowDetails("BID1003", "SF3001", new DateTime(12 / 09 / 2023), 1, Status.Borrowed, 0);
        //BID1004	SF3001	14/09/2023	1	Returned	16
        BorrowDetails borrow3 = new BorrowDetails("BID1004", "SF3001", new DateTime(14 / 09 / 2023), 1, Status.Returned, 0);
        //BID1002	SF3002	11/09/2023	2	Borrowed	0
        BorrowDetails borrow4 = new BorrowDetails("BID1002", "SF3002", new DateTime(11 / 09 / 2023), 2, Status.Borrowed, 0);
        //BID1005	SF3002	09/09/2023	1	Returned	20
        BorrowDetails borrow5 = new BorrowDetails("BID1005", "SF3002", new DateTime(09 / 09 / 2023), 1, Status.Returned, 20);
        listBorrowDetails.Add(borrow1);
        listBorrowDetails.Add(borrow2);
        listBorrowDetails.Add(borrow3);
        listBorrowDetails.Add(borrow4);
        listBorrowDetails.Add(borrow5);



    }

    public static void MainMenu()
    {
        /*1.	UserRegistration
2.	UserLogin
3.	Exit
If the user selects Option 3. Exit, then the application should be closed.
        */
        bool choice = true;
        do
        {

            System.Console.WriteLine("Enter \n1.UserRegistration\n2.UserLogin\n3.Exit");
            int option = int.Parse(Console.ReadLine());
            switch (option)
            {
                case 1:
                    {
                        UserRegistration();
                        break;
                    }
                case 2:
                    {
                        UserLogin();
                        break;
                    }
                case 3:
                    {
                        System.Console.WriteLine("!---------Thank For Coming--------!");
                        choice = false;
                        break;
                    }
                default:
                    {
                        System.Console.WriteLine("OOPS..! You Entered Wrong Input. Just Enter from 1- 3.....!");
                        break;
                    }
            }
        } while (choice == true);
    }



    public static void UserRegistration()
    {
        //throw new NotImplementedException();
        System.Console.WriteLine("-------Welcome To User Registration Page -----------");

        /*1.	UserRegistration:
On selection of the option “1. User Registration” from the main menu,
1.	Need to get the below details from the user for the user registration.
a.	Username
b.	Gender (Enum – Select, Male, Female, Transgender)
c.	Department  
d.	MobileNumber
e.	MailID
f.	WalletBalance
2.	On completion of the user registration, we need to display the UserID (auto generated UserID).
3.	Then need to show the Main menu again.
        */
        System.Console.WriteLine("Enter Your Name :");
        string name = Console.ReadLine();
        System.Console.WriteLine("Enter Your Gender :");
        Gender gender = Gender.Parse<Gender>(Console.ReadLine().ToLower());
        System.Console.WriteLine("Enter Your Department :");
        Department department = Department.Parse<Department>(Console.ReadLine().ToUpper());
        System.Console.WriteLine("Enter Your Mobile Number :");
        long mobileNumber = long.Parse(Console.ReadLine());
        System.Console.WriteLine("Enter Your EmailID :");
        string mailID = Console.ReadLine();
        System.Console.WriteLine("Enter Your WalletBalance");
        double walletBalance = double.Parse(Console.ReadLine());

        UserDetails user = new UserDetails(name, gender, department, mobileNumber, mailID, walletBalance);
        listUserDetails.Add(user);
        System.Console.WriteLine("!............User Registration is Completed.....!");
        System.Console.WriteLine();
        System.Console.WriteLine("Your User Registraionm ID is :  " + user.UserID);
        System.Console.WriteLine();
    }

    public static void UserLogin()
    {
        //throw new NotImplementedException();
        System.Console.WriteLine("----------Welcome To Login Page--------------------------");
        System.Console.WriteLine("Enter Your Login ID : ");
        string loginID = Console.ReadLine().ToUpper();
        bool flag = true;
        foreach (UserDetails user in listUserDetails)
        {
            if (loginID == user.UserID)
            {
                flag = false;
                CurrentLoggedInUser = user;
                System.Console.WriteLine();
                System.Console.WriteLine("Login Successfully");
                SubMenu();
                break;
            }
        }
        if (flag == true)
        {
            System.Console.WriteLine("OOPS...!.Please Enter Correct Login ID ");
        }


    }

    public static void SubMenu()
    {
        System.Console.WriteLine("Welcome to SubMenu ");
        bool flagSub = true;
        do
        {
            System.Console.WriteLine("Enter\n1.Borrowbook\n2.ShowBorrowedhistory.\n3.ReturnBooks\n4.WalletRecharge \n5.Exit");
            int choice2 = int.Parse(Console.ReadLine());
            switch (choice2)
            {
                case 1:
                    {
                        BorrowBooks();
                        break;
                    }
                case 2:
                    {
                        ShowBorrowedHistory();
                        break;
                    }
                case 3:
                    {
                        ReturnBooks();
                        break;
                    }
                case 4:
                    {
                        WalletRecharge();
                        break;
                    }
                case 5:
                    {
                        flagSub = false;
                        break;
                    }
                default:
                    {
                        System.Console.WriteLine("OOPPS...! You Entered Wrong input .Plz Enter 1-5");
                        break;
                    }
            }

        } while (flagSub == true);

    }

    public static void WalletRecharge()
    {
        // throw new NotImplementedException();
        System.Console.WriteLine("!........Welcome To Wallet Reachrge ...!");

        /*1.	Ask the customer whether he wish to recharge the wallet. 
 2.	If “Yes” then ask for the amount to be recharged and update the amount in the wallet and display the updated wallet balance.
 3.	Else go the submenu.
        */

        System.Console.WriteLine("Do You Want to Recharge ?(yes/no) ");
        string choice = Console.ReadLine().ToLower();
        if (choice == "yes")
        {
            System.Console.WriteLine("Enter Amount You need to Recharge ... !");
            double amount = double.Parse(Console.ReadLine());
            CurrentLoggedInUser.WalletBalance += amount;
        }

        System.Console.WriteLine("After Recharge Your Balance is : " + CurrentLoggedInUser.WalletBalance);



    }

    public static void ReturnBooks()
    {
        // throw new NotImplementedException();
        System.Console.WriteLine("!---------Welcome To Return Books Page -------!");
        /*
  1.	Show the borrowed book details of current user whose status is “borrowed” also Print the return date of each book (Return date will be 15 days after borrowing a book).  
 2.	If the return date is elapsed more than 15 days then calculate and show the fine amount (Rs. 1 / Day) for each book.
 3.	Ask him to select the BorrowedID to return book and validate that ID. 
 4.	If return date is elapsed, 
 a.	then check whether the user have sufficient balance for the fine amount, 
 b.	if he has sufficient balance then deduct the fine amount from his Wallet balance and change the Status in Booking History to “Returned” and update the fine amount to the “PaidFineAmount” calculated and show “Book returned successfully”. Also, update the “BookCount”.
 c.	else show “Insufficient balance. Please rechange and proceed”. 
 5.	Else, change the Status in Booking History to “Returned” and show Book returned successfully. Also, update the “BookCount”.

        */
        //Show the borrowed book details of current user whose status is “borrowed” also Print the return date of each book (Return date will be 15 days after borrowing a book).


        foreach (BorrowDetails borrow in listBorrowDetails)
        {
            if (CurrentLoggedInUser.UserID == borrow.UserID && borrow.Status == Status.Borrowed)
            {

                System.Console.WriteLine("Borrow ID :" + borrow.BorrowID);
                System.Console.Write("Return date will be 15 days after borrowing a book Date is : ");
                DateTime newDate = borrow.BorrowedDate.AddDays(15);
                System.Console.WriteLine();
            }
        }
        System.Console.WriteLine("Select the BorrowID : ");
        string UserBorrowID = Console.ReadLine();
        bool flagBorrowID = true;
        foreach (BorrowDetails borrow in listBorrowDetails)
        {



            //If the return date is elapsed more than 15 days then calculate and show the fine amount (Rs. 1 / Day) for each book.

            //Ask him to select the BorrowedID to return book and validate that ID. 

            if (CurrentLoggedInUser.UserID == borrow.UserID)
            {


                if (UserBorrowID == borrow.BorrowID)
                {
                    flagBorrowID = false;

                    //then check whether the user have sufficient balance for the fine amount, 

                    if (CurrentLoggedInUser.WalletBalance >= borrow.PaidFineAmount)
                    {
                        //if he has sufficient balance then deduct the fine amount from his Wallet balance and change the Status in Booking History to “Returned” and update the fine amount to the “PaidFineAmount” calculated and show “Book returned successfully”. Also, update the “BookCount”.
                        if (DateTime.Now > borrow.BorrowedDate.AddDays(15))
                        {
                            TimeSpan extraDate = DateTime.Now - borrow.BorrowedDate.AddDays(15);
                            int daysDifference = extraDate.Days;
                            // System.Console.WriteLine(daysDifference);
                            borrow.PaidFineAmount += daysDifference;
                        }
                        CurrentLoggedInUser.DeductBalance(borrow.PaidFineAmount);
                        borrow.Status = Status.Returned;

                        foreach (BookDetails book in listBookDetails)
                        {
                            if (borrow.BookID == book.BookID )
                            {
                                book.BookCount += 1;

                            }
                        }
                        System.Console.WriteLine("Book Returned Successfully....!");
                    }
                    else
                    {
                        //else show “Insufficient balance. Please rechange and proceed”.
                        System.Console.WriteLine("Insufficient Balance .Please Do Recharge in the submenu Option");
                        break;
                    }
                }
            }
        }if (flagBorrowID == true)
        {
            System.Console.WriteLine("OOPS.Entered Wrong Borrow Id .Please Try Again...");
        }


    }
        




public static void ShowBorrowedHistory()
{
    // throw new NotImplementedException();
    System.Console.WriteLine("!----------Wlcome to the ShowBorrowedHistory Page-------------!");
    foreach (BorrowDetails borrow in listBorrowDetails)
    {
        if (CurrentLoggedInUser.UserID == borrow.UserID)
        {
            System.Console.WriteLine("BookID :" + borrow.BookID);
            System.Console.WriteLine("Borrowed Date" + borrow.BorrowedDate);
            System.Console.WriteLine("Book Count Borrowd" + borrow.BorrowBookCount);
            System.Console.WriteLine("Paid Fine Amount" + borrow.PaidFineAmount);
            System.Console.WriteLine("Staus : "+borrow.Status);
            System.Console.WriteLine();
            //System.Console.WriteLine(""+borrow.);

        }
    }

}

public static void BorrowBooks()
{
    //  throw new NotImplementedException();
    System.Console.WriteLine("!-----------------Welcome To Borrow Books Page --------------------------!");
    /*1.	Show the list of Books available by printing BookID, BookName, AuthorName, BookCount.
2.	Then Ask the user to pick one book by Asking “Enter Book ID to borrow”.
3.	Check whether “BookID” is available or not. 
4.	If not available display “ Invalid Book ID, Please enter valid ID”, else ask the user to “Enter the count of the book”. Then,
5.	Check the book count availability of the book selected. 
o	If there is no book available, display as “Books are not available for the selected count”. 
o	And print the next available date of book by getting that book’s “BorrowedDate” from the borrowed history information and adding with 15 days  the borrowed date of that book. 
o	Show “The book will be available on {borrowed date + 15 days}”.  
6.	If the book is available to borrow, 
o	need to check whether the user already have any borrowed book. Because user can have a maximum of only 3 borrowed books at a time. 
o	If user having 3 borrowed books already then show “You have borrowed 3 books already”.
o	If the user’s already borrowed book count and requested book count exceeds 3 count, then show “You can have maximum of 3 borrowed books. Your already borrowed books count is {BorrowBookCount} and requested count is {Current Requested Count}, which exceeds 3 ”.
7.	Else allocate the book to the user and set status of the Booking Details as "Borrowed” and set the “BorrowedDate” as today’s date and “PaidFineAmount” as 0. 
o	Create the Borrow Details object then store it and show “Book Borrowed successfully”.

    */
    ///Show the list of Books available by printing BookID, BookName, AuthorName, BookCount.

    foreach (BookDetails book in listBookDetails)
    {
        System.Console.WriteLine("BookID :" + book.BookID);
        System.Console.WriteLine("Author Name :" + book.AuthorName);
        System.Console.WriteLine("Book Count : " + book.BookCount);
        System.Console.WriteLine("Book Name : " + book.BookName);
    }
    //Then Ask the user to pick one book by Asking “Enter Book ID to borrow”.
    System.Console.WriteLine("Enter Book ID to borrow");
    string userBookID = Console.ReadLine();
    //Check whether “BookID” is available or not
    bool flagBookID = true;
    // bool falgBookCount=true;
    foreach (BookDetails book in listBookDetails)
    {
        if (book.BookID == userBookID)
        {
            flagBookID = false;
            //“Enter the count of the book”.
            System.Console.WriteLine("Enter the Book Count ");
            int userBookCount = int.Parse(Console.ReadLine());
            //Check the book count availability of the book selected.
            if (userBookCount <= book.BookCount)
            {
                /*need to check whether the user already have any borrowed book. Because user can have a maximum of only 3 borrowed books at a time. 
o	If user having 3 borrowed books already then show “You have borrowed 3 books already”.
                */

                foreach (BorrowDetails borrow in listBorrowDetails)
                {
                    if (borrow.UserID == CurrentLoggedInUser.UserID)
                    {



                        /*If the user’s already borrowed book count and requested book count exceeds 3 count, then show “You can have maximum of 3 borrowed books. Your already borrowed books count is {BorrowBookCount} and requested count is {Current Requested Count}, which exceeds 3 ”.
                        */
                        if (borrow.BorrowBookCount + userBookCount > 3 && borrow.BorrowBookCount > 3)
                        {
                            System.Console.WriteLine("You have borrowed 3 books Already .");
                            System.Console.WriteLine($"You can have maximum of 3 borrowed books. Your already borrowed books count is {borrow.BorrowBookCount} and requested count is {userBookCount}, which exceeds 3 .");
                        }
                        else
                        {
                            /*
                            Else allocate the book to the user and set status of the Booking Details as "Borrowed” and set the “BorrowedDate” as today’s date and “PaidFineAmount” as 0. 
o	Create the Borrow Details object then store it and show “Book Borrowed successfully”.
                           */
                            borrow.Status = Status.Borrowed;
                            borrow.BorrowedDate = DateTime.Now;
                            borrow.PaidFineAmount = 0;
                            BorrowDetails borrowed = new BorrowDetails(book.BookID, borrow.UserID, borrow.BorrowedDate, borrow.BorrowBookCount, borrow.Status, borrow.PaidFineAmount);
                            listBorrowDetails.Add(borrowed);
                            System.Console.WriteLine("Book Borrowed Sucessfully ...!");
                            System.Console.WriteLine("Your Borrow ID is : " + borrowed.BorrowID);
                            System.Console.WriteLine("Your Borrowed Date is :" + borrowed.BorrowedDate);
                            System.Console.WriteLine("Your Borrowed Status is : " + borrowed.Status);
                            //  System.Console.WriteLine(""+CurrentLoggedInUser.UserID);
                        }
                    }
                    break;
                }
            }
            else
            {
                System.Console.WriteLine("Books are not available for the selected count");
                /*And print the next available date of book by getting that book’s “BorrowedDate” from the borrowed history information and adding with 15 days  the borrowed date of that book. 
o	Show “The book will be available on {borrowed date + 15 days}”.
                */
                foreach (BorrowDetails borrow1 in listBorrowDetails)
                {
                    if (userBookID == borrow1.BookID)
                    {
                        System.Console.WriteLine("“The book will be available on" + borrow1.BorrowedDate.AddDays(15));
                    }

                }

            }

        }
    }
    if (flagBookID == true)
    {
        System.Console.WriteLine("Invalid Book ID, Please enter valid ID");
    }


}
}