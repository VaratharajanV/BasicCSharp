using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

public enum Gender{male,female,transgender}
public enum Department{ECE,EEE,CSE}

namespace OnlineLibraryManagement
{
    public class UserDetails
    {
        //feilds
       // User Details Class:
/*User Details class should have below properties.
Properties:
a.	
b.	UserName
c.	Gender
d.	Department – (Enum – ECE, EEE, CSE)
e.	MobileNumber
f.	MailID
g.	WalletBalance*/

        //properties
        //methods

        //UserID (Auto Increment – SF3000)
        private static int s_UserID=2999;

        

        public string UserID { get; set; }
        public string UserName { get; set; }
        public Enum Gender { get; set; }
        public Enum Department { get; set; }
        public long MobileNumber { get; set; }

        public string MailID { get; set; }
        public double WalletBalance { get; set; }

        public UserDetails(string userName, Enum gender, Enum department, long mobileNumber, string mailID, double walletBalance)
        {
            s_UserID++;
            UserID="SF"+s_UserID;
            UserName = userName;
            Gender = gender;
            Department = department;
            MobileNumber = mobileNumber;
            MailID = mailID;
            WalletBalance = walletBalance;
        }


        
        public static void DeductBalance(){

        }


    }
}