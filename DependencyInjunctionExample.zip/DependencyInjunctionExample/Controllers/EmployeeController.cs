﻿using DependencyInjunctionExample.Models;
using DependencyInjunctionExample.Models.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DependencyInjunctionExample.Controllers
{
    public class EmployeeController : Controller
    {
        private IEmployee _employeeRepository;

        public EmployeeController(IEmployee obj)
        {
            _employeeRepository=obj;
        }


        public IActionResult Index()
        {
            List<Employee> listOfEmployees = new List<Employee>();
            listOfEmployees = _employeeRepository.GetEmployeeDetails();
            return View(listOfEmployees);
        }
    }
}
