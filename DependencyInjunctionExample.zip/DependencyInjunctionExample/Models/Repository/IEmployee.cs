﻿namespace DependencyInjunctionExample.Models.Repository
{
    public interface IEmployee
    {
       public List<Employee> GetEmployeeDetails();
   
    }
}
