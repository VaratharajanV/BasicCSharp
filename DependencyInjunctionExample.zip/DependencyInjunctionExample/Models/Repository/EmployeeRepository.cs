﻿

namespace DependencyInjunctionExample.Models.Repository
{
    public class EmployeeRepository : IEmployee
    {
        public List<Employee> GetEmployeeDetails()
        {
            return new List<Employee>
            {
                new Employee(1,"Raja","varatha","rajan"),
                new Employee(2, "Regu", "Yoges", "waran"),
                new Employee(3, "Raju", "Vino", "Krishnan")

            };
                
               
        }
    }
}
