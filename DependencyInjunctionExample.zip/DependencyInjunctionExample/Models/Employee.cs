﻿namespace DependencyInjunctionExample.Models
{
    public class Employee
    {
       

        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string FirstName { get; set; }
        public string Lastname { get; set; }

        public Employee(int employeeId, string employeeName, string firstName, string lastname)
        {
            EmployeeId = employeeId;
            EmployeeName = employeeName;
            FirstName = firstName;
            Lastname = lastname;
        }
    }
}
