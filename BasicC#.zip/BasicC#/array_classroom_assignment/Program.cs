﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Threading;
namespace array_classroom_assignment;

class Program
{
    /*1.  Create a program that have an array with the size 5
2.   Add array of names that inclusive of your name
3.   Print all names using for loop
4.   Get a name from the user to search in array
5.   Ensure the presence of that name in the array for loop if name is present then print "The name is present in array" and print the index value of that name. else "The name is not present in array" (Only one time)
6.   Find the presence of that name in the array using foreach loop and print "The name is present in array" , else " The name is not present in array" (Only one time)
Inputs: Mani, Ganesh, Venkat, Suresh, Venkat
*/
    public static void Main(string[] args)
    {
        string[] name = new string[5];
        /*for (int i = 0; i < name.Length; i++)
        {
            name[i] = Console.ReadLine();
        }
        */
        name[0]="Mani";
        name[1]="Ganesh";
        name[2]="Venkat";
        name[3]="Suresh";
        name[4]="Venkat";



        for (int i = 0; i < name.Length; i++)
        {
            Console.WriteLine(name[i]);
        }
        Console.WriteLine("Enter the name for search");
        String Search = Console.ReadLine();
        int count = 0;

        for (int i = 0; i < name.Length; i++)
        {
            if (Search == name[i])
            {
                count += 1;
            }

        }


        if (count > 0)
        {

            Console.WriteLine("The name is present in the array");

        }

        else
        {
            Console.WriteLine("The name is not present in the array");
        }

    

        foreach(string x in name){
             if (Search == x)
            {
                count += 1;
            }
        }
            if (count > 0)
        {

            Console.WriteLine("The name is present in the array");

        }

        else
        {
            Console.WriteLine("The name is not present in the array");
        }



    }
}
