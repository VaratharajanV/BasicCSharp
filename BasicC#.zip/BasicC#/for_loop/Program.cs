﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//Calculate the sum of the square of the numbers present between the two number limit.
using System;
using System.Diagnostics.CodeAnalysis;
namespace for_loop;
class Program{
    public static void Main(string[] args)
    {
        int num1=Convert.ToInt32(Console.ReadLine());
        int num2=Convert.ToInt32(Console.ReadLine());
        int sum=0;

        for(int i=num1+1;i<num2;i++){
            sum=sum+(i*i);
        }
        Console.WriteLine(sum);

    }

}
