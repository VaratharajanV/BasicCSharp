﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Transactions;
namespace switch_statement;
/*
You need to get two Input values from user and ask the user about which operation needed to perform

If user enters '+' you need to perform addition with above data and print the result value,  
If user enters '-' you need to perform subtraction with above data and print the result value,  
If user enters '*' you need to perform multiplication with above data and print the result value,  
If user enters '/' you need to perform division with above data and print the result value,  
If user enters '%' you need to perform modulo division with above data and print the result value, 


If user enters anything else you need to show the user that Operation is Invalid. 

**Design a clear user interface that clearly tells the user what is needed to be entered in that asked position
*/

class Program
{
    public static void Main(string[] args)
    {
        
        Console.WriteLine("Enter n1");
        int n1=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter n2");
        int n2=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter + or - or * or / or %");
        
        string s=Console.ReadLine();
        switch(s){
            case "+" :
                int ans=n1+n2;
                Console.WriteLine(ans);
                break;
            case "-":
                ans=n1-n2;
                Console.WriteLine(ans);
                break;
            case "*":
                ans=n1*n2;
                Console.WriteLine(ans);
                break;
            case "/":
                ans=n1/n2;
                Console.WriteLine(ans);
                break;
            case "%":
                ans=n1%n2;
                Console.WriteLine(ans);
                break;
            default :
                Console.WriteLine("Operation is Invalid");
                break;
        
        }
        



    }
}