﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace StringClassroom;
/*
Write C# program on manipulation with string properties and method
1. You need to get longer Main string as input from the user (Refer example below).
2. You need to get the shorter string as input from the user (Refer example below) which is the sub string of the first input.
3. You need to find the number of occurrences of the substring in the main string.
Ex:
Input:
Main String: blablablabla
String to be searched: la
Output: string searched count is 4
*/
class Program{
    public static void Main(string[] args)
    {
        Console.WriteLine("Main string :");
        string main=Console.ReadLine();
        Console.WriteLine("Searching string");
        string search=Console.ReadLine();
        if(main.Contains(search)){
            int count=Count(main,search);
            Console.WriteLine($"string searched count is {count}");
        }
        else{
            Console.WriteLine("substring not found in the string");
        }

    }
    static int Count(string main,string search){
        int count=0;
        int index=main.IndexOf(search);
        while(index!=-1){
            count+=1;
            index=main.IndexOf(search,index+1);
        }
        return count;
    }
} 