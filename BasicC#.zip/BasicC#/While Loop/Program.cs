﻿// See https://aka.ms/new-console-template for more information
/*
Exercise 1:
Create a while loop that print 0 to 25 even numbers  
Exercise 2:
Need to get a valid number from the user.
Using the while loop,  validate the number input.
If the input number is a valid number, break the loop and print the number.
If the input number is not in a valid format, show the message as "Invalid input format. Please enter the input in number format". Until the user provides a valid number input.

*/

using System;
using System.Globalization;
using System.Threading;

///Console.WriteLine("Hello, World!");
int i=0;
while(i<25){
    Console.WriteLine(i);
    i+=2;
}
int num=Convert.ToInt32(Console.ReadLine());
i=0;
int count=0;
while(i<25){
    if (num==i){
        
        Console.WriteLine($"Num is {i}",i);
        count+=1;
        break;
    }
    i+=2;
}
if(count>0){
    Console.WriteLine("Valid input");



}
else{
    Console.WriteLine("Invalid input format. Please enter the input in number format");

}
