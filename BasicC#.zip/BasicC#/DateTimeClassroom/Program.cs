﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
/*
Write C# program on DateTime properties and methods
Create a DateTime object with values (2021,8,10,10,40,32).
1. Display the Year, Month, Day, Hours, Minutes, and Seconds of the above DateTime Object individually.
2. Convert the Datetime to string.
Split that string into years, Month, Day, Hours, Minutes and Seconds.
Print it in reverse order.
Output : AM 32 40 10 10 8 2021
3. Get date time object in string format (yyyy/MM/dd hh:mm:ss tt) from user and print the year, month, and day.
*/
using System;
namespace DateTimeClassroom;
class Program{
    public static void Main(string[] args)
    {
        DateTime d=new DateTime(2021,8,10,10,40,32);
        Console.WriteLine(d.ToString("yyyy/MM/dd hh:mm:ss  tt"));
        Console.WriteLine(d.ToString("tt ss mm hh dd MM yyyy"));
        DateTime d1=DateTime.ParseExact(Console.ReadLine(),"yyyy/MM/dd hh:mm:ss tt",null);
        Console.WriteLine(d1);
        
    }

}