﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;
using System.Reflection;
using System.Transactions;
namespace Methods;
/*
Create an application to perform basic mathematical operations Like Addition, Subtraction, Multiplication and Division using return type methods that are with arguments .
Ask for two number to do the selected mathematical operation.
After accepting the numbers, Display the Menu like below and ask the user to choose an option. Use Switch for the option selection.
Addition
Subtraction
Multiplication
Division
Use "Do while" to repeat do the above operation by asking the user whether he wants to continue. If he enters "Yes", then you need to repeat the process again from asking for the numbers.
*/
class Program
{
    public static void Main(string[] args)
    {

            string enter="";
        do
        {
            //gettimng two numbers
            Console.WriteLine("Enter first number");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number");
            int num2 = Convert.ToInt32(Console.ReadLine());
            //getting the sign of function via switch
            Console.WriteLine("Write Symbol + - * / ");
            string a = Console.ReadLine();
            switch (a)
            {
                case "+":
                    Addition(num1, num2);
                    
                    break;
                case "-":
                    Subtraction(num1, num2);
                    break;
                case "*":
                    Multiplication(num1, num2);
                    break;
                case "/":
                    Division(num1, num2);
                    break;
            }
            Console.WriteLine("say yes or no");
            enter = Console.ReadLine();
        }while (enter == "yes");
    }
    //addition function
    static void Addition(int num1, int num2)
    {
        int num3 = num1 + num2;
        Console.WriteLine(num3);

    }
    //subtraction function
    static void Subtraction(int num1, int num2)
    {
        int num3 = num1 - num2;
        Console.WriteLine(num3);
    }
    //multiplication function
    static void Multiplication(int num1, int num2)
    {
        int num3 = num1 * num2;
        Console.WriteLine(num3);

    }
    //division function
    static void Division(int num1, int num2)
    {
        int num3 = num1 / num2;
        Console.WriteLine(num3);
    }
}
