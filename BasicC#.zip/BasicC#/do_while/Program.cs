﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
/*
Write a program to identify whether the user provided number is Odd or Even.
Then ask for the user opinion whether to repeat the process with another number with "Yes" or "No" options.
- If the user wants to check with another number and chooses "Yes" then need to get input from user again and identify the number is Odd or Even. Again need to ask "Yes" or "No" opinion for repeating the process.
- If user choose "No" then end the program.
- If user provide wrong input (other than "Yes" or "No"), then need to mention the provided input is wrong and ask for a valid input.*/
using System;
using System.Globalization;
using System.Threading;
namespace do_while;
class Program{
    public static void Main(string[] args)
    {
        string text1="";

        do{
            int number=Convert.ToInt32(Console.ReadLine());


            if(number%2==0){
                Console.WriteLine("Even number");

            }
            else{
                Console.WriteLine("Odd Number");

            }
            
            Console.WriteLine("Enter yes or No");
            text1=Console.ReadLine();
           /*if(text1=="yes"){
                bool count=true;
            }
            else{
                bool count=false;
            }
            */
        }while(text1=="yes");
    }
}
