create table raja(
name varchar(255),
id  serial
);
alter table raja
rename to studentraja;
alter table studentraja
add column mobile_number bigInt;
select * from studentraja;

alter table studentraja
drop column mobile_number;

alter table studentraja 
alter column name type text;
