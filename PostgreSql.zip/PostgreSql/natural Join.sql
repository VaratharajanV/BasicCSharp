select *
from cars 
natural join persons;