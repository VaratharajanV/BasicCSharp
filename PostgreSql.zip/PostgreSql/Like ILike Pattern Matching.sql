--Like
select * from cars
where brand like 'B%' ;

--Like Operator Pattern Matching
select * from cars
where brand like '%u%';

--Not Like Operator 
select * from cars where brand not like 'B%' ;





