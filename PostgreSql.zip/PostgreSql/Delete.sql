---Query all columns for all American cities in the 
---CITY table with populations larger than 100000. 
--The CountryCode for America is USA.

create table city(
id serial,
name varchar(17),
countrycode varchar(3),
district varchar(20),
population bigint
);
insert into city(name,countrycode,district,population)
values
('raja','usa','arisona',16212321),
('raja','usa','arisona',16212321);
select * from city;

delete from city where id=1;