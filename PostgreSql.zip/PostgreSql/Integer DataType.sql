
create table books1(
pageNo smallint,
MobileNo int,
binaryValues bigInt
);
insert into books1(pageNo,MobileNo,binaryValues)(
values
(32000,638263415,328573246363126)
);