create table EmployeesTable(
employee_id serial primary key,
first_name varchar(255),
last_name varchar(255),
birth_date date not null,
hire_date date not null
);
insert into employeesTable(first_name,last_name,birth_date,hire_date)
values
('Shannon','Freeman','1980-01-01','2005-01-01'),
('Sheila','Wells','1978-02-05','2003-01-01'),
('Ethel','Webb','1975-01-01','2001-01-01');
select current_date;
select to_char(now() :: date,'dd/mm/yyyy');
select to_char(now() :: date,'Mon dd,yyyy');
select 
first_name,
last_name,
now()-hire_date as diff
from emploYeesTable;

--Calculate Ages in Years,months,days
select 
employee_id,
first_name,
last_name,
age(birth_date)
from
employeesTable;

--Extract Function

select 
employee_id,
first_name,
last_name,
extract (year from birth_date) as year,
extract (month from birth_date) as month,
extract (day from birth_date)as day
from employeestable ;