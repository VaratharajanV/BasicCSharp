CREATE TABLE orders12 (
    ID serial NOT NULL PRIMARY KEY,
    info json NOT NULL
);
INSERT INTO orders12 (info)
VALUES
    (
        '{ "customer": "Raju Kumar", "items": {"product": "coffee", "qty": 6}}'
    );
select info from orders12;
