select * from customers;
select * from cars;

select first_name || ' ' || last_name full_name,
count(referal_id)
from customers
group by full_name,referal_id 
having count(referal_id)>0;
