create table filmss(
title varchar(255),
rating varchar(10),
rating_description varchar(256)
);

insert into filmss(title,rating)
values
('the God father','G'),
('the God father','PG'),
('the God father','PG-13'),
('the God father','R');

select distinct  title,
       rating,
       CASE rating
           WHEN 'G' THEN 'General Audiences'
           WHEN 'PG' THEN 'Parental Guidance Suggested'
           WHEN 'PG-13' THEN 'Parents Strongly Cautioned'
           WHEN 'R' THEN 'Restricted'
           WHEN 'NC-17' THEN 'Adults Only'
       END rating_description
FROM filmss
ORDER BY title;