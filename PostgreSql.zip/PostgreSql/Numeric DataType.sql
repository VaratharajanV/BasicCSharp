drop table if exists productsNew;
create table productsNew(
id serial primary key,
name varchar(100) not null,
price numeric(5,2)
);
insert into productsNew(name,price)
values
('phone',500.215),
('Tablet',500.214);

select * from productsNew;

update productsnew
set price='NaN'
where id='1';
--Nan(Not a Number) is the greater things among all
select * from productsNew p order by price desc;