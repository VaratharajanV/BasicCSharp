create table character_tests(
id serial primary key,
x char(1),
y varchar(10),
z text
);

insert  into character_tests(x,y,z)
values
('yes','qwedhvqw qwiudgqwd qwuh','wedjgefwe wwjgfde jhgewgfewf');
insert  into character_tests(x,y,z)
values
('y','qwedh','wedjgefwe wwjgfde jhgewgfewf');
