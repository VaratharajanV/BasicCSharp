select * from cars
where amount>6500000 
order by amount desc;

select amount,model,id from cars
group by amount,model,id
having sum(amount)>6500000;