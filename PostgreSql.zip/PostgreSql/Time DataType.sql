--Time Data

create table shifts(
id serial primary key,
shift_name varchar not null,
start_at time not null,
end_at time not null
);
insert into shifts(shift_name,start_at,end_at)
values
('Morning', '08:00:00', '12:00:00'),
('Afternoon', '13:00:00', '17:00:00'),
('Night', '18:00:00', '22:00:00');

select * from shifts;

select localtime at time zone 'UTC-7';

select localtime,
extract(hour from localtime) as hour,
extract(minute from localtime) as minute,
extract (second from localtime) as second,
extract (millisecond from localtime)as milliseconds;
