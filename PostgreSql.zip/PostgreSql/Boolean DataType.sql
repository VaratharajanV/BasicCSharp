drop table if exists stock_availability;
create table stock_availability(
product_id int primary key,
available boolean not null
);
insert into stock_availability(product_id,available)
values
(100,true),
(200,false),
(300,'t'),
(400,'1'),
(500,'y'),
(600,'yes'),
(700,'no'),
(800,'0');

select * 
from stock_availability
where available='yes';

select * 
from stock_availability
where available='false';

select * 
from stock_availability
where not available;

alter table stock_availability 
alter column available set default false;
insert into stock_availability(product_id)
values
(900);
select * from stock_availability where product_id=900;
