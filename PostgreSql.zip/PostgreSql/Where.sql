select  * from cars
where amount>100000
order by amount desc;

select brand,amount from cars where brand='Audi' and amount>100000 ;

select brand,amount from cars where brand='Audi' or amount>100000 order by amount desc;

---In Operator
select * from cars where brand IN('Audi'); 
--Like 
select * from cars where brand like 'A%' ;
--End with Like
select * from cars where brand like '%i' ;
--Between Operator
select brand,length(brand)brandName from cars 
where length(brand) between 4 and 6 
order by brandName desc;
--Not Equals to Operator <>
select * from cars where brand <> 'Audi' ;
--Not Equals to Operator != 
select * from cars where brand!='Audi'  order by id desc;







