select * from cars;
select * from customers; 
select customer_id,id,first_name 
from cars
left join customers on customers.customer_id =cars.id 
order by id desc;