select 
id,customer_id,first_name 
from 
customers
right join cars
on cars.id =customers.customer_id ;
