create table documentationsProcedure(
document_id serial primary key,
HeaderText varchar(255) not null,
posting_date date not null default current_date
);
insert into documentationsProcedure(HeaderText)
values
('Billed to the customer X .'),
('Billed to the customer Y .'),
('Billed to the customer Z .');

select  * from documentationsProcedure
order by document_id desc;
