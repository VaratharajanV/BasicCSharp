--Check
DROP TABLE IF EXISTS employees1;
CREATE TABLE employees1 (
	id SERIAL PRIMARY KEY,
	first_name VARCHAR (50) not null,
	last_name VARCHAR (50) not null,
	birth_date DATE CHECK (birth_date > '1900-01-01'),
	joined_date DATE CHECK (joined_date > birth_date),
	salary numeric CHECK(salary > 0),
	email varchar(255) Unique
);

INSERT INTO employees1 (first_name, last_name, birth_date, joined_date, salary,email)
VALUES ('John', 'Doe', '1900-01-02', '1900-01-03',  100000,'varatharajan607822gmail.com');

INSERT INTO employees1 (first_name, last_name, birth_date, joined_date, salary,email)
VALUES ('John', 'Doe', '1972-01-01', '2015-07-01', 100000,'varatharaja607822gmail.com');
