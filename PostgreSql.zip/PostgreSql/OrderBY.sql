--PostGreSql OrderBy Clause
select *
from cars
order by id;
--DescendingOrder
select * from cars order by id desc ;
--sort id in ascending order and price in the descending order 
select 
id,amount
from cars
order by
id asc ,
amount desc;
--Length Function
select brand , LENGTH(brand) len from car order by len desc;
--Create a new Table

