select * from customers ;

select first_name,
last_name
from customers
where not exists 
(select customer_id 
from customers
where customers.customer_id >3 and customers.customer_id <5
)
order by first_name,
last_name ;

select first_name,
last_name
from customers
where customer_id = any 
(select customer_id 
from customers
where customers.customer_id >3 and customers.customer_id <5
)
order by first_name,
last_name ;

select first_name,
last_name
from customers
where customer_id = all
(select customer_id 
from customers
where customers.customer_id >3 and customers.customer_id <5
)
order by first_name,
last_name ;

