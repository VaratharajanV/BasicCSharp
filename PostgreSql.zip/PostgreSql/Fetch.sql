select * from cars order by id fetch first row only ;
--Fetch
select id , brand from cars 
order by id 
fetch first 5 row only ;
--With Offset
select id , brand , model from cars 
order by id 
offset 3 rows 
fetch first 3 rows only;
