create table contacts1(
id serial primary key,
name varchar(100),
phones text[]
);
insert into contacts1(name,phones)
values
('John Doe',array['327464378','237463271']),
('Lily Bush','{"9832423","8329463"}');

select * from contacts1;
select name,phones[2] from contacts1;

