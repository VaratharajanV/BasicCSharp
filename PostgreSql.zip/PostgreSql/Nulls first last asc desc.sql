create table demo2(
num int

);
insert into demo2(num)
values (1),(2),(null);
select distinct num from demo2 order by num;
--nulls last

select distinct num from demo2 order by num nulls last;
--nulls first

select distinct num from demo2 order by num nulls first;
--nulls first descending

select distinct num from demo2 order by num desc nulls first;
--nulls last descending

select distinct num from demo2 order by num desc nulls last;
