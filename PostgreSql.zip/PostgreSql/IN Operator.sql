select * from cars 
where id in(1,2)
order by 
manufacturingdate desc;
--= or
select * from cars 
where id=1 or id=2 
order by 
manufacturingdate desc;
--Not In Operator
select * from cars where id not in(1,2) order by id desc;
--Not equals to Operators
select * from cars where id <>1 order by  id desc;

--SubQuery 
select * from cars where
id IN(
select id
from cars 
where id='1'
)
order by id;

