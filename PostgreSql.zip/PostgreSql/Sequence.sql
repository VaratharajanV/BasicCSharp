create sequence mysequence
increment 5
start 100;

select nextval('mysequence');

create sequence three
increment -1
minvalue 1
maxvalue 3
start 3;

select nextval('three');