--Union ,Union All
drop table if exists top_rated_films;
create table top_rated_films(
title varchar not null,
release_year smallint
);
drop table if exists nost_popular_films;
create table most_popular_films(
title varchar not null,
release_year smallint
);
insert into top_rated_films(title,release_year)
values
('The shawshank Redemption',1984),
('The God Father',1972),
('12 Angry Men',1957);
INSERT INTO 
   most_popular_films(title,release_year)
VALUES
   ('An American Pickle',2020),
   ('The God Father',1972),
   ('Greyhound',2020);
  
select * from top_rated_films;
select * from most_popular_films;
--Intersector
SELECT * 
FROM most_popular_films 
INTERSECT
SELECT * 
FROM top_rated_films;
