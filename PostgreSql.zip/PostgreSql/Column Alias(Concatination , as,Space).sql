--Assigning a coloumn alias to a column example
select brand,amount as Price from cars;
select * from cars;
--Concatination Tool 
select brand ||' - '||model as BrandModel from cars;
select brand ||' - '||model as "Brand Model" from cars;
