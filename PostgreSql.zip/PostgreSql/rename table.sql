create table raja(
name varchar(255),
id  serial
);
alter table raja
rename to studentraja;