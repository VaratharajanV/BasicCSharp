--Like
select * from cars
where brand like 'B%' ;

--Like Operator Pattern Matching
select * from cars
where brand like '%u%';

--Not Like Operator 
select * from cars where brand not like 'B%' ;

insert into cars(id,brand,model) (
	values
	(9,'UNOVA',null)
);
select distinct * from cars
where model isnull ;

select distinct * from cars 
where model is not null ;





