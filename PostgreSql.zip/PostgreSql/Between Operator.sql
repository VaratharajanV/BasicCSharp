--Between is for low and high value (low,high)
select * from cars
where id between 3 and 5 
order by id;

--Not Between Operator

select * from cars c where id not between 1 and 2 order by id desc ; 

select manufacturingdate,model from cars
where manufacturingdate between '1000-01-01' and '2999-12-12' 
order by manufacturingdate desc;


