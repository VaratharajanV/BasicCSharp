select * from employee;
drop table if exists  employee;
DROP TABLE if exists employee cascade;
CREATE TABLE employee(
  id int not null PRIMARY key,
  name VARCHAR(255) not null,
  age int not null,
  address text not null,
  mobileNumber text not null
);