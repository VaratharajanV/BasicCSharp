drop table if exists t1;
create table t1(label char(1) primary key);
drop table if exists t2;
create table t2(score int primary key);
insert into t1(label)
values
('A'),
('B');
insert into t2(score)
values
(1),
(2),
(3);
select * 
from t1
cross join t2;