drop table if exists links;

create table links(
link_id serial primary key,
title varchar(512) not null
);
alter table links
add column active boolean;
select * from links;
alter table links 
rename column title to link_title;
alter table links
add column target varchar(10);
alter table links rename to urls;
select * from urls;
alter table urls 
add constraint unique_url unique(link_id);
