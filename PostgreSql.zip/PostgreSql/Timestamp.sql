CREATE TABLE timestamp_demo (
    ts TIMESTAMP, 
    tstz TIMESTAMPTZ
);

SET timezone = 'America/Los_Angeles';

show timezone;

INSERT INTO timestamp_demo (ts, tstz)
VALUES('2016-06-22 19:10:25-07','2016-06-22 19:10:25-07');

SELECT 
   ts, tstz
FROM 
   timestamp_demo;
  
select now();

select current_timestamp ;

select timeofday();

show timezone;

