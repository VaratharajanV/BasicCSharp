--Display all elements in the cars table
select * from cars;
--Single Column Example :
select brand from cars;
--Multiple Columns example
select model,manufacturingdate from cars;
--Full car name with their manufacturing date (Here used Concatenation Operator)
select 
brand || ' - ' || manufacturingdate || ' - ' || maxspeed as CarDetails ,
amount as Price
from cars;
--select postgreSql with Expressions Example 
select 3*2;


