select * from customers;
select * from cars;
select customer_id,brand,model
from
cars 
inner join 
customers 
on customer_id=cars.id
order by id desc;
select * from colour;