create temp table raja(
id serial,
name varchar(255)
);
select * from raja;
