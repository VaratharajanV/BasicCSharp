create table distinct_demo(
	id int,
	bcolor varchar,
	fcolor varchar
);
insert into distinct_demo(bcolor,fcolor)
values
('red','red'),
('red','red'),
('red',null),
(null,'red') ;

select distinct  id,bcolor,fcolor from distinct_demo
order by 
bcolor ,
fcolor desc;
