DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS employees1;

CREATE TABLE departments (
	department_id serial PRIMARY KEY,
	department_name VARCHAR (255) NOT NULL
);

CREATE TABLE employees1(
	employee_id serial PRIMARY KEY,
	employee_name VARCHAR (255),
	department_id INTEGER
);
INSERT INTO departments (department_name)
VALUES
	('Sales'),
	('Marketing'),
	('HR'),
	('IT'),
	('Production');

INSERT INTO employees1 (
	employee_name,
	department_id
)
VALUES
	('Bette Nicholson', 1),
	('Christian Gable', 1),
	('Joe Swank', 2),
	('Fred Costner', 3),
	('Sandra Kilmer', 4),
	('Julia Mcqueen', NULL);
	
SELECT
	employee_name,
	department_name
FROM
	employees1 e
FULL OUTER JOIN departments d 
        ON d.department_id = e.department_id
where 
d.department_name is not null and e.department_id is null
order by 
d.department_id;

