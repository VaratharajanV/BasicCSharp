using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineGroceryShop
{
    public class OrderDetails
    {
        
        //Properties: OrderID {Auto Increment – OID4000}, BookingID, ProductID, PurchaseCount, PriceOfOrder
        private static int s_orderID=4000;
        public string  OrderID { get;  }
        public string  BookingID { get; set; }
        public string ProductID{ get; set; }
        public int PurchaseCount{ get; set; }
        public double PriceOfOrder { get; set; }


        public OrderDetails( string bookingID, string productID, int purchaseCount, double priceOfOrder)
        {
            s_orderID++;
            OrderID = "OID"+s_orderID;
            BookingID = bookingID;
            ProductID = productID;
            PurchaseCount = purchaseCount;
            PriceOfOrder = priceOfOrder;
        }

        public OrderDetails(string orderDetails)
        {//OrderID	BookingID	ProductID	PurchaseCount	PriceOfOrder
            string[] value = orderDetails.Split(',');
            OrderID=value[0];
            s_orderID=int.Parse(value[0].Remove(0,3));
            BookingID=value[1];
            ProductID=value[2];
            PurchaseCount=int.Parse(value[3]);
            PriceOfOrder=int.Parse(value[4]);



        }
    }
}