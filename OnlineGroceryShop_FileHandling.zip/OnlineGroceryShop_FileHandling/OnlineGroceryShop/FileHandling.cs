using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineGroceryShop
{
    public class FileHandling
    {
        public static void CreatingFolders()
        {
            if (!Directory.Exists("OnlineGroceryShop"))
            {
                System.Console.WriteLine("Creating Directory");
                Directory.CreateDirectory("OnlineGroceryShop");
            }
            if (!File.Exists("OnlineGroceryShop/orderDetails.csv"))
            {
                System.Console.WriteLine("Creating File");
                File.Create("OnlineGroceryShop/orderDetails.csv").Close();
            }
            if (!File.Exists("OnlineGroceryShop/productDetails.csv"))
            {
                System.Console.WriteLine("Creating File");
                File.Create("OnlineGroceryShop/productDetails.csv").Close();
            }
            if (!File.Exists("OnlineGroceryShop/customerDetails.csv"))
            {
                System.Console.WriteLine("Creating File");
                File.Create("OnlineGroceryShop/customerDetails.csv").Close();
            }
            if (!File.Exists("OnlineGroceryShop/bookingDetails.csv"))
            {
                System.Console.WriteLine("Creating File");
                File.Create("OnlineGroceryShop/bookingDetails.csv").Close();
            }


        }
        public static void WriteToCSV()
        {
            string[] customerDetails = new string[Operations.customerDetailsList.Count];
            for (int i = 0; i < Operations.customerDetailsList.Count; i++)
            {
                customerDetails[i] = Operations.customerDetailsList[i].CustomerID + ","
                  + Operations.customerDetailsList[i].WalletBalance + Operations.customerDetailsList[i].Name + ","
                + Operations.customerDetailsList[i].FatherName + ","
                + Operations.customerDetailsList[i].Gender + ","
                + Operations.customerDetailsList[i].DOB.ToString("dd/MM/yyyy") + ","
                + Operations.customerDetailsList[i].MailID;
            }
            File.WriteAllLines("OnlineGroceryShop/CustomerDetails.csv", customerDetails);
            //OrderID	BookingID	ProductID	PurchaseCount	PriceOfOrder

            string[] orderDetails = new string[Operations.orderDetailsList.Count];
            for (int i = 0; i < Operations.orderDetailsList.Count; i++)
            {
                orderDetails[i] = Operations.orderDetailsList[i].OrderID + "," + Operations.orderDetailsList[i].BookingID + "," + Operations.orderDetailsList[i].ProductID + "," + Operations.orderDetailsList[i].PurchaseCount + "," + Operations.orderDetailsList[i].PriceOfOrder;
            }
            File.WriteAllLines("OnlineGroceryShop/OrderDetails.csv", orderDetails);
            string[] bookingDetails = new string[Operations.bookingDetailsList.Count];
            for (int i = 0; i < Operations.bookingDetailsList.Count; i++)
            {
                //BookingID	CustomerID	TotalPrice	DateOfBooking	BookingStatus
                bookingDetails[i] = Operations.bookingDetailsList[i].BookingID + "," + Operations.bookingDetailsList[i].CustomerID + "," + Operations.bookingDetailsList[i].TotalPrice + "," + Operations.bookingDetailsList[i].DateOfBooking.ToString("dd/MM/yyyy") + "," + Operations.bookingDetailsList[i].BookingStatus;
            }
            File.WriteAllLines("OnlineGroceryShop/bookingDetails.csv", bookingDetails);
             string[] productDetails= new string[Operations.productDetailsList.Count];
            for (int i = 0; i < Operations.productDetailsList.Count; i++)
            {
               //ProductID	ProductName	QuantityAvailable	PricePerQuantity
                productDetails[i] = Operations.productDetailsList[i].ProductID+ "," + Operations.productDetailsList[i].ProductName+ ","+Operations.productDetailsList[i].QuantityAvailable+ ","+Operations.productDetailsList[i].PricePerQuantity  ;
            }
            File.WriteAllLines("OnlineGroceryShop/productDetails.csv", bookingDetails);

        }
    
        public static void ReadFromCSV(){
            string [] customerDetails= File.ReadAllLines("OnlineGroceryShop/customerDetails.csv");
            foreach(string customerDetails1 in customerDetails){
               CustomerDetails customerDetails2= new CustomerDetails(customerDetails1);
               Operations.customerDetailsList.Add(customerDetails2);
            }
             string [] orderDetails= File.ReadAllLines("OnlineGroceryShop/orderDetails.csv");
            foreach(string orderDetails1 in orderDetails){
               OrderDetails orderDetails2= new OrderDetails( orderDetails1);
               Operations.orderDetailsList.Add(orderDetails2);
            }
             string [] bookingDetail= File.ReadAllLines("OnlineGroceryShop/bookingDetails.csv");
            foreach(string bookingDetails1 in bookingDetail){
               BookingDetails bookingDetails2 = new BookingDetails(bookingDetails1);
               Operations.bookingDetailsList.Add(bookingDetails2);
            }
             string [] productDetails= File.ReadAllLines("OnlineGroceryShop/productDetails.csv");
            foreach(string productDetails1 in productDetails){
              ProductDetails productDetails2= new ProductDetails(productDetails1);
               Operations.productDetailsList.Add(productDetails2);
            }

        }
    }
}