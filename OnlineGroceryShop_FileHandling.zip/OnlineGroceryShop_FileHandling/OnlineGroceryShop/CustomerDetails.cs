using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineGroceryShop
{
    
    public class CustomerDetails : PersonalDetails, IBalance
    {

        private double _balance;
        private static int s_customerID = 1000;
        public string CustomerID { get; }
        public double WalletBalance { get { return _balance; }}
        public CustomerDetails(double balance, string name, string fatherName, Gender gender, long mobileNumber, DateTime dOB, string mailID) : base(name, fatherName, gender, mobileNumber, dOB, mailID)
        {
            s_customerID++;
            CustomerID = "CID" + s_customerID;
            _balance = balance;
        }

        public CustomerDetails(string customerDetails1)
        {
            string[] value = customerDetails1.Split(',');
            CustomerID=value[0];
            s_customerID = int.Parse(value[0].Remove(0, 3));
            _balance=double.Parse(value[1]);
            Name =value[2];
            FatherName = value[3];
            Gender = Enum.Parse<Gender>(value[4]);
            MobileNumber =long.Parse(value[5]);
            DOB = DateTime.ParseExact(value[6],"dd/MM/yyyy",null);
            MailID =value[7];
        }

        public void WalletRecharge(double amount)
        {
            _balance += amount;
        }
        public void DeductBalance(double amount){
            _balance-=amount;
        }
    }
}