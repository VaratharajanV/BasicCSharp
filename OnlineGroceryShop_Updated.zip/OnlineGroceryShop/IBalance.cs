using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineGroceryShop
{
    public interface IBalance
    {
   
        // Properties: WalletBalance
        // Method: WalletRecharge
        public double WalletBalance{ get; }
        public void WalletRecharge(double amount);
        public void DeductBalance(double amount);

    }
}