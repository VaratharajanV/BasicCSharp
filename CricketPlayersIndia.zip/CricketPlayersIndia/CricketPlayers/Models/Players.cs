﻿using System.ComponentModel.DataAnnotations;

namespace CricketPlayers.Models
{
    public class Players
    {
        [Required]
        public string Name { get; set; }
        [Key]
        public int Id { get; set; }
        public string Country { get; set; }
     
        public string Specialization { get; set; }
        
    }
}
