﻿

using CricketPlayers.Data;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;

namespace CricketPlayers.Models.Repositoy
{
    public class SqlRepository : IPlayers
    {
        private readonly MyDbContext _context;

        public SqlRepository(MyDbContext context)
        {
            _context = context;
        }
        //For Add Players
        public void Add(Players entity)
        {
            _context.Set<Players>().Add(entity);
            _context.SaveChanges();

        }
        //For Delete Players in the database
        public void Delete(Players entity)
        {
            _context.Set<Players>().Remove(entity);
            _context.SaveChanges();

        }

        public IEnumerable<Players> GetAll()
        {
            return _context.Set<Players>().ToList();
        }

        public Players GetById(int id)
        {
            var OnePlayer=_context.Set<Players>().Find(id);
            return OnePlayer;
        }

        public void Update(Players entity)
        {
            _context.Set<Players>().Update(entity);
            _context.SaveChanges();

        }
    }
}
