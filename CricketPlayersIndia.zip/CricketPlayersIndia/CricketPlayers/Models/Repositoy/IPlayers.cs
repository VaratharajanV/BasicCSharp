﻿namespace CricketPlayers.Models.Repositoy
{
    public interface IPlayers
    {
        public Players GetById(int id);
        IEnumerable<Players> GetAll();
        void Add(Players entity);
        void Update(Players entity);
        void Delete(Players entity);
    }
}
