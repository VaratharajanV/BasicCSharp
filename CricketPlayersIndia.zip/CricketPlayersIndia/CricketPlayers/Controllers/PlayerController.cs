﻿using CricketPlayers.Models;
using CricketPlayers.Models.Repositoy;
using Microsoft.AspNetCore.Mvc;

namespace CricketPlayers.Controllers
{
    public class PlayerController : Controller
    {
        private readonly IPlayers _sqlRepository;

        public PlayerController(IPlayers sqlRepository)
        {
            _sqlRepository= sqlRepository;
        }
        public IActionResult Index()
        {
            var allPlayers=_sqlRepository.GetAll();
            return View(allPlayers);
        }
        public IActionResult Details(int id)
        {
            var product = _sqlRepository.GetById(id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Players player)
        {
            if (ModelState.IsValid)
            {
                _sqlRepository.Add(player);
                return RedirectToAction("Index");
            }

            return View(player);
        }

        public IActionResult Edit(int id)
        {
            var player = _sqlRepository.GetById(id);

            if (player == null)
            {
                return NotFound();
            }

            return View(player);
        }

        [HttpPost]
        public IActionResult Edit( Players player)
        {

            if (ModelState.IsValid)
            {
                _sqlRepository.Update(player);
                return RedirectToAction("Index");
            }

            return View(player);
        }
        public IActionResult Delete(int id)
        {
            var product = _sqlRepository.GetById(id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        [Route("Player/Delete")]
        public IActionResult ConfirmDelete(int id)
        {
            var product = _sqlRepository.GetById(id);

            if (product == null)
            {
                return NotFound();
            }

            _sqlRepository.Delete(product);
            return RedirectToAction("Index");
        }









    }
}
