﻿using System.Collections.Generic;
using System;
using CricketPlayers.Models;
using Microsoft.EntityFrameworkCore;

namespace CricketPlayers.Data
{
    public class MyDbContext:DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
        {
        }

        public DbSet<Players> PlayersDbSet { get; set; }

    }
}
