﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics.Arm;
using System.Threading;
namespace MetroCardManagement;

public class Program
{

    public static List<Userdetails> listUserDetails = new List<Userdetails>();
    public static List<TravelDetails> listTravelDetails = new List<TravelDetails>();
    public static List<TicketFairDetails> listTicketFairDetails = new List<TicketFairDetails>();
    public static Userdetails CurrentLoggedInUser;
    public static void Main(string[] args)
    {
        FileHandling.Create();
        FileHandling.ReadFromCsv();
        //DefaultData();
        MainMenu();
        FileHandling.WriteToCSV();
    }

    public static void MainMenu()
    {
        //throw new NotImplementedException();
        System.Console.WriteLine("!-----------------Welcome to MainMenu Page-------------------------!");
        /*
        1.	New User Registration
2.	Login User
3.	Exit
        */
        bool flag=true;
        do{
            System.Console.WriteLine("Enter\n1.New User Registration\n2.Login User\n3.Exit ");
            int input=int.Parse(Console.ReadLine());
            switch(input){
                case 1:
                {
                    UserRegistration();
                    break;
                }
                case 2:
                {
                    Login();
                    break;
                }
                case 3:
                {
                    flag=false;
                    System.Console.WriteLine("Thanks for Coming");
                    break;
                }
                default:{
                    System.Console.WriteLine("You entered Wrong Input ");
                    break;
                }
            }
        }while(flag==true);
    }

    public static void Login()
    {
       System.Console.WriteLine("!---------------Welcome to Login Page ------------------! ");
       System.Console.WriteLine();
       System.Console.WriteLine("Enter Your Login Id :");
       string userLogin=Console.ReadLine();
       foreach(Userdetails user in listUserDetails){
            if(userLogin==user.CardNumber){
                CurrentLoggedInUser=user;
                System.Console.WriteLine("Verification Successfully");
                SubMenu();
            }
       }
    }

    public static void SubMenu()
    {
        /*
        a.	Balance Check
b.	Rechange
c.	View Travel History	
d.	Travel
e.	Exit 
        */
        bool flagSub=true;
        do{
             System.Console.WriteLine("Enter\na.Balance Check\nb.Rechange\nc.View Travel History\nd.Travel\ne.Exit "); 
        string userInputString=Console.ReadLine().ToLower();
        switch(userInputString){
            case "a":{
                BalanceCheckUp();
                break;
            }
           case "b":{
                Recharge();
                break;
            }
            case "c":{
                ViewTravelHistory();
                break;
            }
            case "d":{
                Travel();
                break;
            }
            case "e":{
                flagSub=false;
                break;
            }
            default :{
                System.Console.WriteLine("You Entered Wrong Character.......~~! Enter a-e only");
                break;
            }
        }
        
        }while(flagSub==true);
       
    }

    public static void ViewTravelHistory()
    {
      //  throw new NotImplementedException();
      System.Console.WriteLine("!------------Welcome to ViewTravelHistory Page ---------!");
      bool flagHistory=true;
      foreach(TravelDetails travel in listTravelDetails){
        if(CurrentLoggedInUser.CardNumber==travel.CardNumber){
            flagHistory=false;
           // System.Console.WriteLine("Card Number "+travel.CardNumber);
            System.Console.WriteLine(""+travel.FromLocation);
            System.Console.WriteLine(""+travel.ToLocation);
            System.Console.WriteLine(""+travel.TravelCost);
            System.Console.WriteLine(""+travel.TravelCost);
            System.Console.WriteLine();
        }
      }
      if(flagHistory==true){
        System.Console.WriteLine("You have No previous travel History..Book Your First Travel and Enjoy With Us....!");
      }
      
    }

    public static void Travel()
    {
        //throw new NotImplementedException();
        System.Console.WriteLine("!------------Welcome to Travel Page ---------!");
        /*
        1.	Show the Ticket fair details where the user wishes to travel by getting TicketID.
2.	Check the ticketID is valid. Else show “Invalid user id”.
3.	IF ticket is valid then, Check the balance from the user object whether it has sufficient balance to travel.
4.	If “Yes” deduct the respective amount from the balance and add the travel details like Card number, From and ToLocation, Travel Date, Travel cost, Travel ID (auto generation) in his travel history.
5.	If “No” ask him to recharge and go to the “Existing User Service” menu.
        */
        foreach(TicketFairDetails tickets in listTicketFairDetails){
            System.Console.WriteLine("From Location  : "+tickets.FromLocation);
            System.Console.WriteLine("To Location  : "+tickets.ToLocation);
            System.Console.WriteLine("Ticket ID  : "+tickets.TicketID);
            System.Console.WriteLine("Ticket Prize  : "+tickets.TicketPrice);
        }
        System.Console.WriteLine();

        System.Console.WriteLine("Enter the TicketID you want to travel :");
        string userTicktID=Console.ReadLine();
        bool flagTicketID=true;
        foreach(TicketFairDetails tickets in listTicketFairDetails){
            if(userTicktID==tickets.TicketID){
                flagTicketID=false;
                //System.Console.WriteLine("TicketID is correct");
                //Check the balance from the user object whether it has sufficient balance to travel.
                if(CurrentLoggedInUser.Balance>=tickets.TicketPrice){
                    CurrentLoggedInUser.DeductBalance(tickets.TicketPrice);
                    TravelDetails travel=new TravelDetails(CurrentLoggedInUser.CardNumber,tickets.FromLocation,tickets.ToLocation,DateTime.Now,tickets.TicketPrice);
                    listTravelDetails.Add(travel);
                    System.Console.WriteLine("Travel Booked Successfully ....Your Booking ID is "+travel.TravelID);
                }
                else{
                    System.Console.WriteLine("Plz Recharge Because You have no sufficient Balanvce ..........  !  ");
                }
            }
        }
        if(flagTicketID==true){
            System.Console.WriteLine("You Entered Wromng Ticket ID ...!");
        }
    }

    public static void Recharge()
    {
        //throw new NotImplementedException();
        System.Console.WriteLine("!------------Welcome to Recharge Page ---------!");
        System.Console.WriteLine("Enter the Amount you want to be recharged :");
        double amount=double.Parse(Console.ReadLine());
        CurrentLoggedInUser.WalletRecharge(amount);
        System.Console.WriteLine("Your Balance is After Recharge : "+CurrentLoggedInUser.Balance);
    }

    public static void BalanceCheckUp()
    {
      //  throw new NotImplementedException();
       System.Console.WriteLine("!------------Welcome to BalanceCheckUp Page ---------!");
       System.Console.WriteLine("Your Balance is : "+CurrentLoggedInUser.Balance);
    }

    public static void UserRegistration()
    {
        System.Console.WriteLine("!------------Welcome to User Registration Page ---------!");
        /*
        Need to get the below User’s details and add new user to the system
•	UserName
•	Phone Number
•	Balance
            Add the above details to the User Registration Details and display the message “your card number is CMRL101” -Card number(Auto generation- CMRL1001).
        */
        System.Console.WriteLine("Enter Your User Name :");
        string userName=Console.ReadLine();
        System.Console.WriteLine("Enter Your Mobile Number");
        long mobileNumber=long.Parse(Console.ReadLine());
        System.Console.WriteLine("Enter Your Balance");
        double balance=double.Parse(Console.ReadLine());
        Userdetails user=new Userdetails(userName,mobileNumber,balance);
        listUserDetails.Add(user);
        System.Console.WriteLine("Congratulations !!!! Your User Registration Process is Successful . Your Registration Card Number is : "+user.CardNumber);
    }

    public static void DefaultData()
    {
        /*CMRL101	Ravi	98488	1000
CMRL102	Baskaran	99488	1000
        */
        Userdetails user1 = new Userdetails("Ravi", 98488, 1000);
        Userdetails user2 = new Userdetails("Baskaran", 98488, 1000);
        listUserDetails.Add(user1);
        listUserDetails.Add(user2);
        /*
        TravelID	CardNumber	FromLocation	ToLocation	Date	TravelCost
TID101	CMRL101	Airport	Egmore	10/10/2022	55
TID102	CMRL101	Egmore	Koyambedu	10/10/2022	32
TID103	CMRL102	Alandur	Koyambedu	10/11/2022	25
TID103	CMRL102	Egmore	Thirumangalam	10/11/2022	25
        */
        TravelDetails travel1 = new TravelDetails("CMRL101", "Airport", "Egmore", DateTime.ParseExact("10/10/2022", "dd/MM/yyyy", null), 55);
        TravelDetails travel2 = new TravelDetails("CMRL101", "Egmore", "Koyambedu", DateTime.ParseExact("10/10/2022", "dd/MM/yyyy", null), 32);

        TravelDetails travel3 = new TravelDetails("CMRL102", "Alandur", "Koyambedu", DateTime.ParseExact("10/11/2022", "dd/MM/yyyy", null), 25);

        TravelDetails travel4 = new TravelDetails("CMRL102", "Egmore", "Thirumangalam", DateTime.ParseExact("10/11/2022", "dd/MM/yyyy", null), 25);
        listTravelDetails.Add(travel1);
        listTravelDetails.Add(travel2);
        listTravelDetails.Add(travel3);
        listTravelDetails.Add(travel4);

        /*
        MR101	Airport	Egmore	55
MR102	Airport	Koyambedu	25
MR103	Alandur	Koyambedu	25
MR104	Koyambedu	Egmore	32
MR105	Vadapalani	Egmore	45
MR106	Arumbakkam	Egmore	25
MR107	Vadapalani	Koyambedu	25
MR108	Arumbakkam	Koyambedu	16
        */
        TicketFairDetails ticket1=new TicketFairDetails("Airport","Egmore",55);
        TicketFairDetails ticket2=new TicketFairDetails("Airport","Koyambedu",25);
        TicketFairDetails ticket3=new TicketFairDetails("Alandur","Koyambedu",25);
        TicketFairDetails ticket4=new TicketFairDetails("Koyambedu","Egmore",32);
        TicketFairDetails ticket5=new TicketFairDetails("Vadapalani	","Egmore",45);
        TicketFairDetails ticket6=new TicketFairDetails("Arumbakkam","Egmore",25);
        TicketFairDetails ticket7=new TicketFairDetails("Vadapalani	","Koyambedu",25);
        TicketFairDetails ticket8=new TicketFairDetails("Arumbakkam","Koyambedu",16);

        listTicketFairDetails.Add(ticket1);
        listTicketFairDetails.Add(ticket2);
        listTicketFairDetails.Add(ticket3);
        listTicketFairDetails.Add(ticket4);
        listTicketFairDetails.Add(ticket5);
        listTicketFairDetails.Add(ticket6);
        listTicketFairDetails.Add(ticket7);
        listTicketFairDetails.Add(ticket8);




    }
}