using System;
using System.Runtime.CompilerServices;
namespace BankAccountOpening;
public enum Gender{Male,Female,TransGender}
class BankAccount{
    /*Properties - Customer Id -(HDFC1001), Customer name, Balance, Gender (enum), Phone, Mail Id, Date of Birth
    */

    //fields
    private static int s_customerId=1000;
    //Properties
    public string CustomerId{get;set;}
    public string CustomerName{get;set;}
    public double Balance{get;set;}
    public Gender Gender{get;set;}
    public string Phone{get;set;}
    public string EmailId{get;set;}
    public DateTime DateOfBirth{get;set;}
    /*Methods - Deposit, Withdraw
    */
   
    public BankAccount(string customerName,long balance,Gender gender,string phone,string emailId,DateTime dob){
        s_customerId++;
        CustomerId="HDFC"+s_customerId;
        CustomerName=customerName;
        Balance=balance;
        Gender=gender;
        Phone=phone;
        EmailId=emailId;
        DateOfBirth=dob;
    }


}