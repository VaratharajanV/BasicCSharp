using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
public enum WorkLocation{madhura,annaNagar}
public enum Team{developer,tester}
public enum Gender{male,female}

namespace EmployeePayroll
{
    public class EmployeeDetails
    {
        /*
        – EmployeeID - (SF1001), Employee name, Role, WorkLocation (enum), Team name, Date of Joining, Number of Working Days in Month, Number of Leave Taken, Gender (enum – Male, Female )
        */
        private static int s_employeeID=1000;

       

        public string EmployeeID { get;}
        public string EmployeeName { get; set; }
        public string Role { get; set; }
        public WorkLocation WorkLocation { get; set; }  
        public Team Team { get; set; }
        public DateTime Doj { get; set; }
        public int NumberOfWorkingDays { get; set; }
        public int NumberOfLeaveTaken { get; set; }
        public Gender Gender { get; set; }

         public EmployeeDetails(string employeeName, string role, WorkLocation workLocation, Team team, DateTime doj, int numberOfWorkingDays, int numberOfLeaveTaken, Gender gender)
        {
            s_employeeID++;
            EmployeeID="SF"+s_employeeID;
            EmployeeName = employeeName;
            Role = role;
            WorkLocation = workLocation;
            Team = team;
            Doj = doj;
            NumberOfWorkingDays = numberOfWorkingDays;
            NumberOfLeaveTaken = numberOfLeaveTaken;
            Gender = gender;
        }
        public double SalaryCalculation(){
            NumberOfWorkingDays-=NumberOfLeaveTaken;
            double TotalSalary=(double)NumberOfWorkingDays*500;
            return TotalSalary;

        }
    }
}