﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Categories1
{
    public int CategoryId { get; set; }

    public string CategoryName { get; set; } = null!;
}
