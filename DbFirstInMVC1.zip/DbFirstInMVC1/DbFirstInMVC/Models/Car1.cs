﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Car1
{
    public int Id { get; set; }

    public string? Brand { get; set; }

    public string? Model { get; set; }

    public DateOnly? Manufacturingdate { get; set; }

    public int? Fuelcapacity { get; set; }

    public decimal? Amount { get; set; }

    public decimal? Maxspeed { get; set; }

    public virtual Person1? Person1 { get; set; }
}
