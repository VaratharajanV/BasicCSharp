﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class StockAvailability
{
    public int ProductId { get; set; }

    public bool Available { get; set; }
}
