﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Employees1
{
    public int Id { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public DateOnly? BirthDate { get; set; }

    public DateOnly? JoinedDate { get; set; }

    public decimal? Salary { get; set; }

    public string? Email { get; set; }
}
