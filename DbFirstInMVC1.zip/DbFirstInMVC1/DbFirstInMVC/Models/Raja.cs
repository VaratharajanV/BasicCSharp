﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Raja
{
    public string? Name { get; set; }

    public int Id { get; set; }
}
