﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Category
{
    public int Id { get; set; }

    public string ProductName { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public DateOnly CreatedDateTime { get; set; }
}
