﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Car
{
    public string? Brand { get; set; }

    public string? Model { get; set; }

    public int? Year { get; set; }

    public string? Color { get; set; }
}
