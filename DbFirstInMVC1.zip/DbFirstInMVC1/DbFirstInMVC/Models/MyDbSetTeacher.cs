﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class MyDbSetTeacher
{
    public int TeacherId { get; set; }

    public string TeacherName { get; set; } = null!;

    public string Class { get; set; } = null!;

    public string LastName { get; set; } = null!;
}
