﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Mytable
{
    public string? Somevalue { get; set; }
}
