﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Weightclass
{
    public int ClassId { get; set; }

    public string WeightclassName { get; set; } = null!;
}
