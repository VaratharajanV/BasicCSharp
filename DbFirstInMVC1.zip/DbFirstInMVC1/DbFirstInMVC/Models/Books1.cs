﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Books1
{
    public short? Pageno { get; set; }

    public int? Mobileno { get; set; }

    public long? Binaryvalues { get; set; }
}
