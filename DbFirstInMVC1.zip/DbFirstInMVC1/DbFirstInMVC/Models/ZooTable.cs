﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class ZooTable
{
    public int EmployeeId { get; set; }

    public int CageId { get; set; }

    public string Name { get; set; } = null!;

    public int Age { get; set; }

    public string? Phone { get; set; }

    public string? Email { get; set; }
}
