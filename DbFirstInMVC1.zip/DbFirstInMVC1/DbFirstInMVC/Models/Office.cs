﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Office
{
    public int Id { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public int? PersonalMobileNo { get; set; }

    public int? OfficeMobileNo { get; set; }

    public int? HousePhoneNo { get; set; }
}
