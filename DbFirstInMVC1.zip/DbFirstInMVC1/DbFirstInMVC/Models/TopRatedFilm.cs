﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class TopRatedFilm
{
    public string Title { get; set; } = null!;

    public short? ReleaseYear { get; set; }
}
