﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Pythonclass
{
    public int SNo { get; set; }

    public int SId { get; set; }

    public string? PythonStudent { get; set; }

    public string? Department { get; set; }

    public char? Gender { get; set; }

    public string? EMail { get; set; }

    public double? Fees { get; set; }
}
