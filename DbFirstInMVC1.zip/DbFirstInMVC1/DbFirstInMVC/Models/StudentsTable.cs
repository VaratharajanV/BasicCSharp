﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class StudentsTable
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public DateTime MyDateTime { get; set; }
}
