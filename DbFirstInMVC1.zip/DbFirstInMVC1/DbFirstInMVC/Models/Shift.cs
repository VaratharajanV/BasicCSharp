﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Shift
{
    public int Id { get; set; }

    public string ShiftName { get; set; } = null!;

    public TimeOnly StartAt { get; set; }

    public TimeOnly EndAt { get; set; }
}
