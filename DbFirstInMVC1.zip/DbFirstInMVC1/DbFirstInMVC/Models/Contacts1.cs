﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Contacts1
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public List<string>? Phones { get; set; }
}
