﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Documentationsprocedure
{
    public int DocumentId { get; set; }

    public string Headertext { get; set; } = null!;

    public DateOnly PostingDate { get; set; }
}
