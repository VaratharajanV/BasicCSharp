﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Employeestable
{
    public int EmployeeId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public DateOnly BirthDate { get; set; }

    public DateOnly HireDate { get; set; }
}
