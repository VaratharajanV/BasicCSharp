﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class BigBoxTable
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int Price { get; set; }
}
