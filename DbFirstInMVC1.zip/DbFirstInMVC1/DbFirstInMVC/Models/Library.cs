﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Library
{
    public int? StudentId { get; set; }

    public string? Boughtbook { get; set; }
}
