﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Colour
{
    public int ColorId { get; set; }

    public string? ColorName { get; set; }
}
