﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class MovieTable
{
    public int Id { get; set; }

    public string MovieName { get; set; } = null!;

    public DateTime MyDate { get; set; }

    public int Price { get; set; }
}
