﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DbFirstInMVC.Models;

public partial class MyDbContext : DbContext
{
    public MyDbContext()
    {
    }

    public MyDbContext(DbContextOptions<MyDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<BigBoxTable> BigBoxTables { get; set; }

    public virtual DbSet<Book> Books { get; set; }

    public virtual DbSet<Books1> Books1s { get; set; }

    public virtual DbSet<Car> Cars { get; set; }

    public virtual DbSet<Car1> Cars1 { get; set; }

    public virtual DbSet<Categories1> Categories1s { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<CharacterTest> CharacterTests { get; set; }

    public virtual DbSet<City> Cities { get; set; }

    public virtual DbSet<Coloridentity> Coloridentities { get; set; }

    public virtual DbSet<Colour> Colours { get; set; }

    public virtual DbSet<Contact> Contacts { get; set; }

    public virtual DbSet<Contacts1> Contacts1s { get; set; }

    public virtual DbSet<Country> Countries { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Demo> Demos { get; set; }

    public virtual DbSet<Demo2> Demo2s { get; set; }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<DistinctDemo> DistinctDemos { get; set; }

    public virtual DbSet<Documentationsprocedure> Documentationsprocedures { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Employee1> Employees1 { get; set; }

    public virtual DbSet<Employee11> Employee1s { get; set; }

    public virtual DbSet<Employees1> Employees1s { get; set; }

    public virtual DbSet<EmployeesDept> EmployeesDepts { get; set; }

    public virtual DbSet<EmployeesDetail> EmployeesDetails { get; set; }

    public virtual DbSet<Employeestable> Employeestables { get; set; }

    public virtual DbSet<Fighter> Fighters { get; set; }

    public virtual DbSet<FilmDirector> FilmDirectors { get; set; }

    public virtual DbSet<Filmss> Filmsses { get; set; }

    public virtual DbSet<Javaclass> Javaclasses { get; set; }

    public virtual DbSet<Library> Libraries { get; set; }

    public virtual DbSet<MarkSystem> MarkSystems { get; set; }

    public virtual DbSet<MostPopularFilm> MostPopularFilms { get; set; }

    public virtual DbSet<MovieTable> MovieTables { get; set; }

    public virtual DbSet<MyDbSetTeacher> MyDbSetTeachers { get; set; }

    public virtual DbSet<Mytable> Mytables { get; set; }

    public virtual DbSet<Netflix> Netflixes { get; set; }

    public virtual DbSet<Office> Offices { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<Orders1> Orders1s { get; set; }

    public virtual DbSet<Orders12> Orders12s { get; set; }

    public virtual DbSet<Person> People { get; set; }

    public virtual DbSet<Person1> Persons { get; set; }

    public virtual DbSet<PlayersDbSet> PlayersDbSets { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Productsnew> Productsnews { get; set; }

    public virtual DbSet<Pythonclass> Pythonclasses { get; set; }

    public virtual DbSet<Raja> Rajas { get; set; }

    public virtual DbSet<Raja2> Raja2s { get; set; }

    public virtual DbSet<SampleTable> SampleTables { get; set; }

    public virtual DbSet<Shift> Shifts { get; set; }

    public virtual DbSet<StockAvailability> StockAvailabilities { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    public virtual DbSet<Student1> Students1 { get; set; }

    public virtual DbSet<StudentsList> StudentsLists { get; set; }

    public virtual DbSet<StudentsTable> StudentsTables { get; set; }

    public virtual DbSet<T1> T1s { get; set; }

    public virtual DbSet<T2> T2s { get; set; }

    public virtual DbSet<TimestampDemo> TimestampDemos { get; set; }

    public virtual DbSet<TopRatedFilm> TopRatedFilms { get; set; }

    public virtual DbSet<Url> Urls { get; set; }

    public virtual DbSet<VivoTable> VivoTables { get; set; }

    public virtual DbSet<Weightclass> Weightclasses { get; set; }

    public virtual DbSet<YopRatedFilm> YopRatedFilms { get; set; }

    public virtual DbSet<ZooTable> ZooTables { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseNpgsql("Host=34.23.55.201;Database=training-db;UserName=freshers-training;Password=kV1O1st2Uukp9=2");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasPostgresExtension("uuid-ossp");

        modelBuilder.Entity<BigBoxTable>(entity =>
        {
            entity.ToTable("BigBoxTable");

            entity.Property(e => e.Name).HasColumnName("name");
        });

        modelBuilder.Entity<Book>(entity =>
        {
            entity.ToTable("Book");
        });

        modelBuilder.Entity<Books1>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("books1");

            entity.Property(e => e.Binaryvalues).HasColumnName("binaryvalues");
            entity.Property(e => e.Mobileno).HasColumnName("mobileno");
            entity.Property(e => e.Pageno).HasColumnName("pageno");
        });

        modelBuilder.Entity<Car>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("car");

            entity.Property(e => e.Brand)
                .HasMaxLength(255)
                .HasColumnName("brand");
            entity.Property(e => e.Color)
                .HasMaxLength(255)
                .HasColumnName("color");
            entity.Property(e => e.Model)
                .HasMaxLength(255)
                .HasColumnName("model");
            entity.Property(e => e.Year).HasColumnName("year");
        });

        modelBuilder.Entity<Car1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("cars_pkey");

            entity.ToTable("cars");

            entity.HasIndex(e => e.Id, "u_carid").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.Brand)
                .HasMaxLength(20)
                .HasColumnName("brand");
            entity.Property(e => e.Fuelcapacity).HasColumnName("fuelcapacity");
            entity.Property(e => e.Manufacturingdate).HasColumnName("manufacturingdate");
            entity.Property(e => e.Maxspeed).HasColumnName("maxspeed");
            entity.Property(e => e.Model)
                .HasMaxLength(20)
                .HasColumnName("model");
        });

        modelBuilder.Entity<Categories1>(entity =>
        {
            entity.HasKey(e => e.CategoryId).HasName("categories1_pkey");

            entity.ToTable("categories1");

            entity.Property(e => e.CategoryId).HasColumnName("category_id");
            entity.Property(e => e.CategoryName)
                .HasMaxLength(255)
                .HasColumnName("category_name");
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.ToTable("categories");

            entity.Property(e => e.Id).HasColumnName("ID");
        });

        modelBuilder.Entity<CharacterTest>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("character_tests_pkey");

            entity.ToTable("character_tests");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.X)
                .HasMaxLength(1)
                .HasColumnName("x");
            entity.Property(e => e.Y)
                .HasMaxLength(10)
                .HasColumnName("y");
            entity.Property(e => e.Z).HasColumnName("z");
        });

        modelBuilder.Entity<City>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("city");

            entity.Property(e => e.Countrycode)
                .HasMaxLength(3)
                .HasColumnName("countrycode");
            entity.Property(e => e.District)
                .HasMaxLength(20)
                .HasColumnName("district");
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(17)
                .HasColumnName("name");
            entity.Property(e => e.Population).HasColumnName("population");
        });

        modelBuilder.Entity<Coloridentity>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("coloridentity");

            entity.Property(e => e.ColorId)
                .ValueGeneratedOnAdd()
                .UseIdentityAlwaysColumn()
                .HasColumnName("color_id");
            entity.Property(e => e.ColorName)
                .HasColumnType("character varying")
                .HasColumnName("color_name");
        });

        modelBuilder.Entity<Colour>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("colour");

            entity.Property(e => e.ColorId)
                .ValueGeneratedOnAdd()
                .HasColumnName("color_id");
            entity.Property(e => e.ColorName)
                .HasMaxLength(20)
                .HasColumnName("color_name");
        });

        modelBuilder.Entity<Contact>(entity =>
        {
            entity.HasKey(e => e.ContactId).HasName("contacts_pkey");

            entity.ToTable("contacts");

            entity.Property(e => e.ContactId)
                .HasDefaultValueSql("uuid_generate_v4()")
                .HasColumnName("contact_id");
            entity.Property(e => e.Email)
                .HasColumnType("character varying")
                .HasColumnName("email");
            entity.Property(e => e.FirstName)
                .HasColumnType("character varying")
                .HasColumnName("first_name");
            entity.Property(e => e.LastName)
                .HasColumnType("character varying")
                .HasColumnName("last_name");
            entity.Property(e => e.Phone)
                .HasColumnType("character varying")
                .HasColumnName("phone");
        });

        modelBuilder.Entity<Contacts1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("contacts1_pkey");

            entity.ToTable("contacts1");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.Phones).HasColumnName("phones");
        });

        modelBuilder.Entity<Country>(entity =>
        {
            entity.Property(e => e.CountryCode).HasMaxLength(10);
            entity.Property(e => e.ShortName).HasMaxLength(5);
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("customers_pkey");

            entity.ToTable("customers");

            entity.Property(e => e.CustomerId).HasColumnName("customer_id");
            entity.Property(e => e.FirstName)
                .HasMaxLength(20)
                .HasColumnName("first_name");
            entity.Property(e => e.LastName)
                .HasMaxLength(20)
                .HasColumnName("last_name");
            entity.Property(e => e.ReferalId).HasColumnName("referal_id");
        });

        modelBuilder.Entity<Demo>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("demo");

            entity.Property(e => e.Num).HasColumnName("num");
        });

        modelBuilder.Entity<Demo2>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("demo2");

            entity.Property(e => e.Num).HasColumnName("num");
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.DepartmentId).HasName("departments_pkey");

            entity.ToTable("departments");

            entity.Property(e => e.DepartmentId).HasColumnName("department_id");
            entity.Property(e => e.DepartmentName)
                .HasMaxLength(255)
                .HasColumnName("department_name");
        });

        modelBuilder.Entity<DistinctDemo>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("distinct_demo");

            entity.Property(e => e.Bcolor)
                .HasColumnType("character varying")
                .HasColumnName("bcolor");
            entity.Property(e => e.Fcolor)
                .HasColumnType("character varying")
                .HasColumnName("fcolor");
            entity.Property(e => e.Id).HasColumnName("id");
        });

        modelBuilder.Entity<Documentationsprocedure>(entity =>
        {
            entity.HasKey(e => e.DocumentId).HasName("documentationsprocedure_pkey");

            entity.ToTable("documentationsprocedure");

            entity.Property(e => e.DocumentId).HasColumnName("document_id");
            entity.Property(e => e.Headertext)
                .HasMaxLength(255)
                .HasColumnName("headertext");
            entity.Property(e => e.PostingDate)
                .HasDefaultValueSql("CURRENT_DATE")
                .HasColumnName("posting_date");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("employee_pkey");

            entity.ToTable("employee");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Address).HasColumnName("address");
            entity.Property(e => e.Age).HasColumnName("age");
            entity.Property(e => e.Mobilenumber).HasColumnName("mobilenumber");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Employee1>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("employees_pkey");

            entity.ToTable("employees");

            entity.HasIndex(e => e.Email, "employees_email_key").IsUnique();

            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Designation)
                .HasMaxLength(20)
                .HasColumnName("designation");
            entity.Property(e => e.Email)
                .HasMaxLength(255)
                .HasColumnName("email");
            entity.Property(e => e.Gender)
                .HasMaxLength(30)
                .HasColumnName("gender");
            entity.Property(e => e.Name)
                .HasMaxLength(30)
                .HasColumnName("name");
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(10)
                .HasColumnName("phone_number");
            entity.Property(e => e.Salary).HasColumnName("salary");
            entity.Property(e => e.TeamName)
                .HasMaxLength(20)
                .HasColumnName("team_name");
        });

        modelBuilder.Entity<Employee11>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("employee1_pkey");

            entity.ToTable("employee1");

            entity.Property(e => e.EmployeeId)
                .ValueGeneratedNever()
                .HasColumnName("employee_id");
            entity.Property(e => e.FirstName)
                .HasMaxLength(255)
                .HasColumnName("first_name");
            entity.Property(e => e.LastName)
                .HasMaxLength(255)
                .HasColumnName("last_name");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
        });

        modelBuilder.Entity<Employees1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("employees1_pkey");

            entity.ToTable("employees1");

            entity.HasIndex(e => e.Email, "employees1_email_key").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.BirthDate).HasColumnName("birth_date");
            entity.Property(e => e.Email)
                .HasMaxLength(255)
                .HasColumnName("email");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .HasColumnName("first_name");
            entity.Property(e => e.JoinedDate).HasColumnName("joined_date");
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .HasColumnName("last_name");
            entity.Property(e => e.Salary).HasColumnName("salary");
        });

        modelBuilder.Entity<EmployeesDept>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("employees_dept");

            entity.Property(e => e.Experience).HasColumnName("experience");
            entity.Property(e => e.LeaveTaken).HasColumnName("leave_taken");
            entity.Property(e => e.Name)
                .HasMaxLength(20)
                .HasColumnName("name");
            entity.Property(e => e.TeamName)
                .HasMaxLength(20)
                .HasColumnName("team_name");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("userid_fk");
        });

        modelBuilder.Entity<Employeestable>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("employeestable_pkey");

            entity.ToTable("employeestable");

            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.BirthDate).HasColumnName("birth_date");
            entity.Property(e => e.FirstName)
                .HasMaxLength(255)
                .HasColumnName("first_name");
            entity.Property(e => e.HireDate).HasColumnName("hire_date");
            entity.Property(e => e.LastName)
                .HasMaxLength(255)
                .HasColumnName("last_name");
        });

        modelBuilder.Entity<Fighter>(entity =>
        {
            entity.HasKey(e => e.FighterId).HasName("fighters_pkey");

            entity.ToTable("fighters");

            entity.Property(e => e.FighterId).HasColumnName("fighter_id");
            entity.Property(e => e.ClassId).HasColumnName("class_id");
            entity.Property(e => e.Country)
                .HasMaxLength(30)
                .HasColumnName("country");
            entity.Property(e => e.FighterName)
                .HasMaxLength(255)
                .HasColumnName("fighter_name");
            entity.Property(e => e.Gender)
                .HasMaxLength(11)
                .HasColumnName("gender");
            entity.Property(e => e.Salary).HasColumnName("salary");
        });

        modelBuilder.Entity<Filmss>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("filmss");

            entity.Property(e => e.Rating)
                .HasMaxLength(10)
                .HasColumnName("rating");
            entity.Property(e => e.RatingDescription)
                .HasMaxLength(256)
                .HasColumnName("rating_description");
            entity.Property(e => e.Title)
                .HasMaxLength(255)
                .HasColumnName("title");
        });

        modelBuilder.Entity<Javaclass>(entity =>
        {
            entity.HasKey(e => e.SId).HasName("javaclass_pkey");

            entity.ToTable("javaclass");

            entity.HasIndex(e => e.EMail, "javaclass_e_mail_key").IsUnique();

            entity.Property(e => e.SId)
                .ValueGeneratedNever()
                .HasColumnName("s_id");
            entity.Property(e => e.Department)
                .HasMaxLength(5)
                .HasColumnName("department");
            entity.Property(e => e.EMail).HasColumnName("e_mail");
            entity.Property(e => e.Fees).HasColumnName("fees");
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .HasColumnName("gender");
            entity.Property(e => e.JavaStudent)
                .HasMaxLength(20)
                .HasColumnName("java_student");
            entity.Property(e => e.SNo)
                .ValueGeneratedOnAdd()
                .HasColumnName("s_no");
        });

        modelBuilder.Entity<Library>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("library");

            entity.Property(e => e.Boughtbook)
                .HasMaxLength(255)
                .HasColumnName("boughtbook");
            entity.Property(e => e.StudentId).HasColumnName("student_id");
        });

        modelBuilder.Entity<MarkSystem>(entity =>
        {
            entity.HasKey(e => e.StudentId);

            entity.ToTable("MarkSystem");

            entity.Property(e => e.StudentId).HasColumnName("StudentID");
            entity.Property(e => e.MarkId).HasColumnName("MarkID");
        });

        modelBuilder.Entity<MostPopularFilm>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("most_popular_films");

            entity.Property(e => e.ReleaseYear).HasColumnName("release_year");
            entity.Property(e => e.Title)
                .HasColumnType("character varying")
                .HasColumnName("title");
        });

        modelBuilder.Entity<MovieTable>(entity =>
        {
            entity.ToTable("MovieTable");

            entity.Property(e => e.Id).HasColumnName("id");
        });

        modelBuilder.Entity<MyDbSetTeacher>(entity =>
        {
            entity.HasKey(e => e.TeacherId);
        });

        modelBuilder.Entity<Mytable>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("mytable");

            entity.Property(e => e.Somevalue)
                .HasMaxLength(20)
                .HasColumnName("somevalue");
        });

        modelBuilder.Entity<Netflix>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("netflix_pkey");

            entity.ToTable("netflix");

            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Gender)
                .HasMaxLength(30)
                .HasColumnName("gender");
            entity.Property(e => e.Name)
                .HasMaxLength(30)
                .HasColumnName("name");
            entity.Property(e => e.Premium)
                .HasMaxLength(20)
                .HasColumnName("premium");
        });

        modelBuilder.Entity<Office>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("office_pkey");

            entity.ToTable("office");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.FirstName)
                .HasMaxLength(30)
                .HasColumnName("first_name");
            entity.Property(e => e.HousePhoneNo).HasColumnName("house_phone_no");
            entity.Property(e => e.LastName)
                .HasMaxLength(30)
                .HasColumnName("last_name");
            entity.Property(e => e.OfficeMobileNo).HasColumnName("office_mobile_no");
            entity.Property(e => e.PersonalMobileNo).HasColumnName("personal_mobile_no");
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("orders_pkey");

            entity.ToTable("orders");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Info)
                .HasColumnType("json")
                .HasColumnName("info");
        });

        modelBuilder.Entity<Orders1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("orders1_pkey");

            entity.ToTable("orders1");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Info)
                .HasColumnType("json")
                .HasColumnName("info");
        });

        modelBuilder.Entity<Orders12>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("orders12_pkey");

            entity.ToTable("orders12");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Info)
                .HasColumnType("json")
                .HasColumnName("info");
        });

        modelBuilder.Entity<Person1>(entity =>
        {
            entity.HasKey(e => e.StudentId).HasName("studentdetails_pkey");

            entity.ToTable("persons");

            entity.HasIndex(e => e.Email, "studentdetails_email_key").IsUnique();

            entity.HasIndex(e => e.CarId, "u_fkey").IsUnique();

            entity.Property(e => e.StudentId)
                .HasDefaultValueSql("nextval('studentdetails_student_id_seq'::regclass)")
                .HasColumnName("student_id");
            entity.Property(e => e.Address).HasColumnName("address");
            entity.Property(e => e.CarId).HasColumnName("car_id");
            entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .HasColumnName("first_name");
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .HasColumnName("gender");
            entity.Property(e => e.Gpa)
                .HasPrecision(3, 2)
                .HasColumnName("gpa");
            entity.Property(e => e.GraduationDate).HasColumnName("graduation_date");
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .HasColumnName("last_name");
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(15)
                .HasColumnName("phone_number");

            entity.HasOne(d => d.Car).WithOne(p => p.Person1)
                .HasForeignKey<Person1>(d => d.CarId)
                .HasConstraintName("persons_car_id_fkey");
        });

        modelBuilder.Entity<PlayersDbSet>(entity =>
        {
            entity.ToTable("PlayersDbSet");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.ProductId).HasName("products_pkey");

            entity.ToTable("products");

            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.CatagoryId).HasColumnName("catagory_id");
            entity.Property(e => e.NetPrice).HasColumnName("net_price");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.ProductName)
                .HasMaxLength(20)
                .HasColumnName("product_name");
        });

        modelBuilder.Entity<Productsnew>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("productsnew_pkey");

            entity.ToTable("productsnew");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.Price)
                .HasPrecision(5, 2)
                .HasColumnName("price");
        });

        modelBuilder.Entity<Pythonclass>(entity =>
        {
            entity.HasKey(e => e.SId).HasName("pythonclass_pkey");

            entity.ToTable("pythonclass");

            entity.HasIndex(e => e.EMail, "pythonclass_e_mail_key").IsUnique();

            entity.Property(e => e.SId)
                .ValueGeneratedNever()
                .HasColumnName("s_id");
            entity.Property(e => e.Department)
                .HasMaxLength(5)
                .HasColumnName("department");
            entity.Property(e => e.EMail).HasColumnName("e_mail");
            entity.Property(e => e.Fees).HasColumnName("fees");
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .HasColumnName("gender");
            entity.Property(e => e.PythonStudent)
                .HasMaxLength(20)
                .HasColumnName("python_student");
            entity.Property(e => e.SNo)
                .ValueGeneratedOnAdd()
                .HasColumnName("s_no");
        });

        modelBuilder.Entity<Raja>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("raja");

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Raja2>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("raja2");

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
        });

        modelBuilder.Entity<SampleTable>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("sample_table");

            entity.Property(e => e.CreatedOn).HasColumnName("created_on");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Shift>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("shifts_pkey");

            entity.ToTable("shifts");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.EndAt).HasColumnName("end_at");
            entity.Property(e => e.ShiftName)
                .HasColumnType("character varying")
                .HasColumnName("shift_name");
            entity.Property(e => e.StartAt).HasColumnName("start_at");
        });

        modelBuilder.Entity<StockAvailability>(entity =>
        {
            entity.HasKey(e => e.ProductId).HasName("stock_availability_pkey");

            entity.ToTable("stock_availability");

            entity.Property(e => e.ProductId)
                .ValueGeneratedNever()
                .HasColumnName("product_id");
            entity.Property(e => e.Available)
                .HasDefaultValue(false)
                .HasColumnName("available");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("student");

            entity.Property(e => e.StudentId)
                .ValueGeneratedOnAdd()
                .HasColumnName("student_id");
            entity.Property(e => e.StudentName)
                .HasMaxLength(255)
                .HasColumnName("student_name");
        });

        modelBuilder.Entity<Student1>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("students");

            entity.HasIndex(e => e.Email, "students_email_key").IsUnique();

            entity.Property(e => e.Address).HasColumnName("address");
            entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");
            entity.Property(e => e.DateOfJoin).HasColumnName("date_of_join");
            entity.Property(e => e.Email)
                .HasMaxLength(30)
                .HasColumnName("email");
            entity.Property(e => e.EnglishMark).HasColumnName("english_mark");
            entity.Property(e => e.FirstName)
                .HasMaxLength(20)
                .HasColumnName("first_name");
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .HasColumnName("gender");
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
            entity.Property(e => e.LastName)
                .HasMaxLength(20)
                .HasColumnName("last_name");
            entity.Property(e => e.MathsMark).HasColumnName("maths_mark");
            entity.Property(e => e.Percentage)
                .HasPrecision(4, 2)
                .HasColumnName("percentage");
            entity.Property(e => e.TamilMark).HasColumnName("tamil_mark");
        });

        modelBuilder.Entity<StudentsList>(entity =>
        {
            entity.ToTable("StudentsList");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.EmailId).HasColumnName("EmailID");
        });

        modelBuilder.Entity<StudentsTable>(entity =>
        {
            entity.ToTable("studentsTable");
        });

        modelBuilder.Entity<T1>(entity =>
        {
            entity.HasKey(e => e.Label).HasName("t1_pkey");

            entity.ToTable("t1");

            entity.Property(e => e.Label)
                .HasMaxLength(1)
                .ValueGeneratedNever()
                .HasColumnName("label");
        });

        modelBuilder.Entity<T2>(entity =>
        {
            entity.HasKey(e => e.Score).HasName("t2_pkey");

            entity.ToTable("t2");

            entity.Property(e => e.Score)
                .ValueGeneratedNever()
                .HasColumnName("score");
        });

        modelBuilder.Entity<TimestampDemo>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("timestamp_demo");

            entity.Property(e => e.Ts)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("ts");
            entity.Property(e => e.Tstz).HasColumnName("tstz");
        });

        modelBuilder.Entity<TopRatedFilm>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("top_rated_films");

            entity.Property(e => e.ReleaseYear).HasColumnName("release_year");
            entity.Property(e => e.Title)
                .HasColumnType("character varying")
                .HasColumnName("title");
        });

        modelBuilder.Entity<Url>(entity =>
        {
            entity.HasKey(e => e.LinkId).HasName("links_pkey");

            entity.ToTable("urls");

            entity.HasIndex(e => e.LinkId, "unique_url").IsUnique();

            entity.Property(e => e.LinkId)
                .HasDefaultValueSql("nextval('links_link_id_seq'::regclass)")
                .HasColumnName("link_id");
            entity.Property(e => e.Active).HasColumnName("active");
            entity.Property(e => e.LinkTitle)
                .HasMaxLength(512)
                .HasColumnName("link_title");
            entity.Property(e => e.Target)
                .HasMaxLength(10)
                .HasColumnName("target");
        });

        modelBuilder.Entity<VivoTable>(entity =>
        {
            entity.ToTable("VivoTable");
        });

        modelBuilder.Entity<Weightclass>(entity =>
        {
            entity.HasKey(e => e.ClassId).HasName("weightclasses_pkey");

            entity.ToTable("weightclasses");

            entity.Property(e => e.ClassId).HasColumnName("class_id");
            entity.Property(e => e.WeightclassName)
                .HasMaxLength(255)
                .HasColumnName("weightclass_name");
        });

        modelBuilder.Entity<YopRatedFilm>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("yop_rated_films");

            entity.Property(e => e.ReleaseYear).HasColumnName("release_year");
            entity.Property(e => e.Title)
                .HasColumnType("character varying")
                .HasColumnName("title");
        });

        modelBuilder.Entity<ZooTable>(entity =>
        {
            entity.HasKey(e => e.EmployeeId);

            entity.ToTable("ZooTable");

            entity.Property(e => e.EmployeeId).HasColumnName("EmployeeID");
            entity.Property(e => e.CageId).HasColumnName("CageID");
            entity.Property(e => e.Email).HasColumnName("EMail");
        });
        modelBuilder.HasSequence("mysequence")
            .StartsAt(100L)
            .IncrementsBy(5);
        modelBuilder.HasSequence("s_id")
            .StartsAt(223L)
            .IncrementsBy(3);
        modelBuilder.HasSequence("three")
            .IncrementsBy(-1)
            .HasMin(1L)
            .HasMax(3L);

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
