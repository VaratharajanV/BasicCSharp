﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Coloridentity
{
    public int ColorId { get; set; }

    public string ColorName { get; set; } = null!;
}
