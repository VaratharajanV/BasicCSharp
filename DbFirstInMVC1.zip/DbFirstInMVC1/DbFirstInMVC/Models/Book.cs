﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DbFirstInMVC.Models;

public partial class Book
{
    [Key]
    public int BookId { get; set; }
    [Required]
    public string BookName { get; set; } = null!;

    public string Author { get; set; } = null!;

    public int PageCount { get; set; }
}
