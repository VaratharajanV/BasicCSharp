﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Employee
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int Age { get; set; }

    public string Address { get; set; } = null!;

    public string Mobilenumber { get; set; } = null!;
}
