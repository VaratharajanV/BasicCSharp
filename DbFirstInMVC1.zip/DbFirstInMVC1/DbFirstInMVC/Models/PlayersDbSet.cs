﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class PlayersDbSet
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Country { get; set; } = null!;

    public string Specialization { get; set; } = null!;
}
