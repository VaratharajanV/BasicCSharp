﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class EmployeesDept
{
    public int? UserId { get; set; }

    public string? Name { get; set; }

    public string? TeamName { get; set; }

    public int? Experience { get; set; }

    public int? LeaveTaken { get; set; }

    public virtual Employee1? User { get; set; }
}
