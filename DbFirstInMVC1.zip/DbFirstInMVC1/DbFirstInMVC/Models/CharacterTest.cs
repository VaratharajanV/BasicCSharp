﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class CharacterTest
{
    public int Id { get; set; }

    public char? X { get; set; }

    public string? Y { get; set; }

    public string? Z { get; set; }
}
