﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class FilmDirector
{
    public int Id { get; set; }

    public string DirectorName { get; set; } = null!;

    public int MoviesCount { get; set; }

    public int HitMoviesCount { get; set; }

    public string BestOfHisMovies { get; set; } = null!;
}
