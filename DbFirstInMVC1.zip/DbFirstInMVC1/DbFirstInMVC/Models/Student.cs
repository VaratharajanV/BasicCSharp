﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Student
{
    public int StudentId { get; set; }

    public string? StudentName { get; set; }
}
