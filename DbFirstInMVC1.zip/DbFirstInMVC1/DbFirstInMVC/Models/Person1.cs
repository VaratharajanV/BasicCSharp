﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Person1
{
    public int StudentId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public DateOnly? DateOfBirth { get; set; }

    public char Gender { get; set; }

    public string? Email { get; set; }

    public string? PhoneNumber { get; set; }

    public string? Address { get; set; }

    public DateOnly? GraduationDate { get; set; }

    public decimal? Gpa { get; set; }

    public int? CarId { get; set; }

    public virtual Car1? Car { get; set; }
}
