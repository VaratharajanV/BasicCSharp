﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Filmss
{
    public string? Title { get; set; }

    public string? Rating { get; set; }

    public string? RatingDescription { get; set; }
}
