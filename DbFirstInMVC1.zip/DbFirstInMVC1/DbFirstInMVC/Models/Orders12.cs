﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Orders12
{
    public int Id { get; set; }

    public string Info { get; set; } = null!;
}
