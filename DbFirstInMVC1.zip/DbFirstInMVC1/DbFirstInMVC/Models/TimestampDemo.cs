﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class TimestampDemo
{
    public DateTime? Ts { get; set; }

    public DateTime? Tstz { get; set; }
}
