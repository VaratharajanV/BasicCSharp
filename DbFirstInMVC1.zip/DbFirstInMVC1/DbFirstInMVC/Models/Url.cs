﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Url
{
    public int LinkId { get; set; }

    public string LinkTitle { get; set; } = null!;

    public bool? Active { get; set; }

    public string? Target { get; set; }
}
