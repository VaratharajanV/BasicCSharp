﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class T2
{
    public int Score { get; set; }
}
