﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class MarkSystem
{
    public int StudentId { get; set; }

    public string StudentName { get; set; } = null!;

    public string MarkId { get; set; } = null!;

    public int TotalMark { get; set; }
}
