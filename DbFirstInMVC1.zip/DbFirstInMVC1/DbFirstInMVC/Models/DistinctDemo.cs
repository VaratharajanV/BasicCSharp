﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class DistinctDemo
{
    public int? Id { get; set; }

    public string? Bcolor { get; set; }

    public string? Fcolor { get; set; }
}
