﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Student1
{
    public int Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public DateOnly DateOfBirth { get; set; }

    public DateOnly DateOfJoin { get; set; }

    public double? TamilMark { get; set; }

    public double? EnglishMark { get; set; }

    public double? MathsMark { get; set; }

    public char? Gender { get; set; }

    public string? Email { get; set; }

    public string? Address { get; set; }

    public decimal? Percentage { get; set; }
}
