﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Fighter
{
    public int FighterId { get; set; }

    public string? FighterName { get; set; }

    public int? ClassId { get; set; }

    public string? Country { get; set; }

    public decimal? Salary { get; set; }

    public string? Gender { get; set; }
}
