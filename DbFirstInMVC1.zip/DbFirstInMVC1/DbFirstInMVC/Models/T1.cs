﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class T1
{
    public char Label { get; set; }
}
