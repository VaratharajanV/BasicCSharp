﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class EmployeesDetail
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public int Age { get; set; }

    public string? MobileNumber { get; set; }

    public string EmailAddress { get; set; } = null!;
}
