﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class Demo2
{
    public int? Num { get; set; }
}
