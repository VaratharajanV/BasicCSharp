﻿using System;
using System.Collections.Generic;

namespace DbFirstInMVC.Models;

public partial class MostPopularFilm
{
    public string Title { get; set; } = null!;

    public short? ReleaseYear { get; set; }
}
