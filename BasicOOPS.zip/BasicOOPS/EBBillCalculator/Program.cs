﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//Properties - Meter ID -(EB1001), Username, Phone number, Mail id, Units Used =0
//Methods – Calculate Amount
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
namespace EBBillCalculator;
public class Program{
    public static List<EBBills> listEBBills=new List<EBBills>();
    public static EBBills CurrentEB;
    public static void Main(string[] args)
    {
        
        MainMenu();
        
    }
    public static void Login(){
        System.Console.WriteLine("Enter Login ID :");
        string login=Console.ReadLine();
        foreach(EBBills eB in listEBBills){
            if(login==eB.MeterID){
            System.Console.WriteLine("Login Successfully .....!");
            CurrentEB=eB;
            SubMenu();
            break;
            }

        }
        

        
        
    }
    public static void SubMenu(){
        bool flagOption = true;
        do
        {
            System.Console.WriteLine("Enter \n 1. Calculate Amount\n 2. Display user Details\n 3. Exit");
            int subOption = Convert.ToInt32(Console.ReadLine());
            switch (subOption)
            {
                case 1:
                    {
                        CalculateAmount();
                        break;
                    }
                case 2:
                    {
                        DisplayUserDetails();
                        break;
                    }
               
                case 3:
                    {
                        flagOption = false;
                        break;
                    }
                default:
                {
                    System.Console.WriteLine("Plz Enter Valid and correct input from 1-3 .Thank You");
                    break;
                }
            }
        } while (flagOption);

    }

public static void DisplayUserDetails()
    {
        //throw new NotImplementedException();
        //Meter ID -(EB1001), Username, Phone number, Mail id
        foreach(EBBills eB in listEBBills){
        System.Console.WriteLine("MeterID :"+CurrentEB.MeterID);
        System.Console.WriteLine("UserName :"+CurrentEB.UserName);
        System.Console.WriteLine("Mobile Number :"+CurrentEB.Phone);
        System.Console.WriteLine("MailID :"+CurrentEB.MailID);

        }
       

    }

    public static void CalculateAmount()
    {
        //hrow new NotImplementedException();
        //. Selected ask user to enter unit details and based on unit entered calculate Rs. 5 / Unit and Display Bill - ID, User Name and unit and Amount
        // System.Console.WriteLine("Enter How many Units :");
        // double totalUnit=double.Parse(Console.ReadLine());
        //CurrentEB.UnitsUsed;
        double totalAmount=CurrentEB.UnitsUsed*5;
        Console.WriteLine("Your Total Amount you need to pay : "+totalAmount);
        Console.WriteLine("Your Total MeterID : "+CurrentEB.MeterID);
        Console.WriteLine("Your UserNaame : "+CurrentEB.UserName);
        Console.WriteLine("Your Total Units Used : "+CurrentEB.UnitsUsed);
    }

    public static void Registration()
    {
        //. Registration selected ask Username, Phone number, Mail id, create object, show Meter ID and store it to list
        Console.WriteLine("***********Welcome To REGISTRATION****************");
        Console.WriteLine("Enter your Name :");
        string userName = Console.ReadLine();
        Console.WriteLine("Enter Your Phone Number");
        long phone = long.Parse(Console.ReadLine());
        Console.WriteLine("Enter Your EMAIL ID");
        string mailId = Console.ReadLine();
        System.Console.WriteLine("Enter the Units : ");
        double unitsUsed=Convert.ToDouble(Console.ReadLine());
        
       EBBills eB=new EBBills(userName,phone,mailId,unitsUsed);
       listEBBills.Add(eB);
        System.Console.WriteLine("Successfully Registered . Your Registered Id is .." + eB.MeterID);
    }
    public static void MainMenu()
    {
        bool finalAction = true;
        do
        {
           
            Console.WriteLine("Enter \n 1 for Registration\n 2 for Login\n 3 for Exit from app");
            int UserInput = Convert.ToInt32(Console.ReadLine());

            switch (UserInput)
            {

                case 1:
                    {
                        Registration();
                        System.Console.WriteLine();
                        break;
                    }
                case 2:
                    {
                        Login();
                        System.Console.WriteLine();
                        break;
                    }

                case 3:
                    {
                        finalAction = false;
                        System.Console.WriteLine("Thank You !!!!");
                        System.Console.WriteLine();
                        break;

                    }
                default:
                {
                    System.Console.WriteLine("Plz Enter Correct and Valid Number from 1-3");
                    System.Console.WriteLine();
                    break;
                }
            }
        } while (finalAction == true);

    }
}
