﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Runtime.Intrinsics.Arm;
namespace EmployeePayroll;
public class Program{
    public static List<EmployeeDetails> listEmployee=new List<EmployeeDetails>();
    public static EmployeeDetails CurrentEmployee;
    public static void Main(string[] args)
    {
        
        System.Console.WriteLine("Welcome To User Registration....!");
        MainMenu();
    }

    public static void MainMenu()
    {
        //throw new NotImplementedException();
        bool finalAction = true;
        do
        {
           
            Console.WriteLine("Enter \n 1 for Registration\n 2 for Login\n 3 for Exit from app");
            int UserInput = Convert.ToInt32(Console.ReadLine());

            switch (UserInput)
            {

                case 1:
                    {
                        Registration();
                        System.Console.WriteLine();
                        break;
                    }
                case 2:
                    {
                        Login();
                        System.Console.WriteLine();
                        break;
                    }

                case 3:
                    {
                        finalAction = false;
                        System.Console.WriteLine("Thank You !!!!");
                        System.Console.WriteLine();
                        break;

                    }
                default:
                {
                    System.Console.WriteLine("Plz Enter Correct and Valid Number from 1-3");
                    System.Console.WriteLine();
                    break;
                }
            }
        } while (finalAction == true);

    }

    public static void Login()
    {
        //throw new NotImplementedException();
        System.Console.WriteLine("Welcome to Login Page ...!");
        System.Console.WriteLine("Enter Your Login ID : ");
        string userLoginID=Console.ReadLine();
        bool flag=true;
        foreach(EmployeeDetails employee in listEmployee){
            if(userLoginID==employee.EmployeeID){
                flag=false;
                CurrentEmployee=employee;
                System.Console.WriteLine("Login Verification completed");
                SubMenu();
            }
        }
        if(flag){
            System.Console.WriteLine("Login Failed...Plz try again Login again");
        }

    }

    public static void SubMenu()
    {
        //throw new NotImplementedException();
        //     1. Calculate salary 2. display details 3. exit
        bool flagOption = true;
        do
        {
            System.Console.WriteLine("Enter \n 1. Calculate Salary\n 2. Display Details\n 3. Exit");
            int subOption = Convert.ToInt32(Console.ReadLine());
            switch (subOption)
            {
                case 1:
                    {
                        CalculateSalary();
                        break;
                    }
                case 2:
                    {
                        DisplayDetails();
                        break;
                    }
               
                case 3:
                    {
                        flagOption = false;
                        break;
                    }
                default:
                {
                    System.Console.WriteLine("Plz Enter Valid and correct input from 1-3 .Thank You");
                    break;
                }
            }
        } while (flagOption);

    }

    public static void DisplayDetails()
    {
        //throw new NotImplementedException();
        foreach(EmployeeDetails employee in listEmployee){
            System.Console.WriteLine("Employee ID : "+employee.EmployeeID);
            System.Console.WriteLine("EmployeeName : "+employee.EmployeeName);
            System.Console.WriteLine("Role : "+employee.Role);
            System.Console.WriteLine("Gender : "+employee.Gender);
            System.Console.WriteLine("Team : "+employee.Team);
            System.Console.WriteLine("Number Of Leave taken : "+employee.NumberOfLeaveTaken);
            System.Console.WriteLine("Working Days : "+employee.NumberOfWorkingDays);
           
        }
    }

    public static void CalculateSalary()
    {
        //throw new NotImplementedException();
        //. Selected calculate salary based on Rs. 500 / One Working day  
        double result=CurrentEmployee.SalaryCalculation();
        System.Console.WriteLine("Your salary is : "+result);

    }


    public static void Registration()
    {
        //throw new NotImplementedException();
        System.Console.WriteLine("Welcome To Registration .....!");
        //1.	If employee  selected 1. Registration selected ask all property details listed above, create object, display employee ID and store it to list
        System.Console.WriteLine("Enter your Name :");
        string employeeName=Console.ReadLine();
        System.Console.WriteLine("Enter your role");
        string role=Console.ReadLine();
        System.Console.WriteLine("Enter your Work Location");
        WorkLocation workLocation=Enum.Parse<WorkLocation>(Console.ReadLine(),true);
        System.Console.WriteLine("Enter Your Team Name");
        Team team=Enum.Parse<Team>(Console.ReadLine(),true);
        System.Console.WriteLine("Enter Your Date of Joining");
        DateTime doj=DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null);
        System.Console.WriteLine("Enter Your number of working Days");
        int numberOfWorkingDays=Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("Enter your Number of Leave Taken");
        int numberOfLeaveTaken=Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("Enter your Gender");
        Gender gender=Enum.Parse<Gender>(Console.ReadLine(),true);
        EmployeeDetails employee=new EmployeeDetails(employeeName,role,workLocation,team, doj,numberOfWorkingDays,numberOfLeaveTaken,gender);
        listEmployee.Add(employee);
        System.Console.WriteLine("Congratuslations ! Your Registration is completed .Your Registration id is :"+employee.EmployeeID);
    }
}
