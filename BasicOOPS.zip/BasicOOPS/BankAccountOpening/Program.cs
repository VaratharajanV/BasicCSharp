﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Security;
namespace BankAccountOpening;
class Program
{
    public static List<BankAccount> listDetails = new List<BankAccount>();
    public static BankAccount CurrentLoggedIn;
    public static void Main(string[] args)
    {
        //Designing Main Menu
        MainMenu();


    }
    public static void SubMenu()
    {

        bool flagOption = true;
        do
        {
            System.Console.WriteLine("Enter \n 1.Deposit \n2.Withdraw\n3.BankBlance\n4.Exit");
            int subOption = Convert.ToInt32(Console.ReadLine());
            switch (subOption)
            {
                case 1:
                    {
                        System.Console.WriteLine("Enter the amount you want to Deposit ?");
                        double amount = double.Parse(Console.ReadLine());
                        Deposit(amount);
                        System.Console.WriteLine("Your deposit is succeful .Your balance is " + CurrentLoggedIn.Balance);
                        break;
                    }
                case 2:
                    {
                        System.Console.WriteLine("Enter the amount you want to Withdrawl ! ");
                        double amount = double.Parse(Console.ReadLine());
                        Withdraw(amount);
                        System.Console.WriteLine("Your withdrawl is successful .Your balance is " + CurrentLoggedIn.Balance);
                        break;
                    }
                
                  
                case 3:
                    {
                        flagOption = false;
                        break;
                    }
                default:
                {
                    System.Console.WriteLine("Plz Enter Valid and correct input from 1-4 .Thank You");
                    break;
                }
            }
        } while (flagOption == true);



    }

    public static void BankBalance()
    {
        //  throw new NotImplementedException();
        double currentBalance = CurrentLoggedIn.Balance;
        System.Console.WriteLine(currentBalance);
    }

    public static void Withdraw(double amount)
    {

        CurrentLoggedIn.Balance = CurrentLoggedIn.Balance - amount;
    }

    public static void Deposit(double amount)

    {
        //string opt="";


        CurrentLoggedIn.Balance = amount + CurrentLoggedIn.Balance;
        //throw new NotImplementedException();






    }

    public static void Login()
    {
        //ask the customer ID
        System.Console.WriteLine("Enter your Customer ID : ");
        string ID = Console.ReadLine();
        bool flag = true;
        foreach (BankAccount person in listDetails)
        {
            if (ID == person.CustomerId)
            {
                System.Console.WriteLine("Logged IN Successfully .......");
                CurrentLoggedIn = person;
                flag = false;
                SubMenu();
            }
        }
        if (flag == true)
        {
            System.Console.WriteLine("You Entered wrong Customer ID ");
        }
    }
    public static void Registration()
    {
        Console.WriteLine("***********Welcome To REGISTRATION****************");
        Console.WriteLine("Enter your Name :");
        string customerName = Console.ReadLine();
        Console.WriteLine("Enter your Balance");
        long balance = long.Parse(Console.ReadLine());
        Console.WriteLine("Enter your Gender");
        //Gender gender=Enum.Parse<Gender>(Console.ReadLine(),true);
        Gender gender = Enum.Parse<Gender>(Console.ReadLine(), true);
        Console.WriteLine("Enter Your Phone Number");
        string phone = (Console.ReadLine());
        Console.WriteLine("Enter Your EMAIL ID");
        string emailId = Console.ReadLine();
        Console.WriteLine("Enter Your Date Of Birth");
        DateTime dob = DateTime.Parse(Console.ReadLine());
        BankAccount person1 = new BankAccount(customerName, balance, gender, phone, emailId, dob);
        listDetails.Add(person1);
        System.Console.WriteLine("Successfully Registered . Your Registered Id is .." + person1.CustomerId);
    }
    public static void MainMenu()
    {
        bool finalAction = true;
        do
        {
            List<BankAccount> list1 = new List<BankAccount>();
            Console.WriteLine("Enter 1 for Registration 2 for Login 3 for Exit from app");
            int UserInput = Convert.ToInt32(Console.ReadLine());

            switch (UserInput)
            {

                case 1:
                    {
                        Registration();
                        System.Console.WriteLine();
                        break;
                    }
                case 2:
                    {
                        Login();
                        System.Console.WriteLine();
                        break;
                    }

                case 3:
                    {
                        finalAction = false;
                        System.Console.WriteLine("Thank You !!!!");
                        System.Console.WriteLine();
                        break;

                    }
                default:
                {
                    System.Console.WriteLine("Plz Enter Correct and Valid Number from 1-3");
                    System.Console.WriteLine();
                    break;
                }
            }
        } while (finalAction == true);

    }
}
