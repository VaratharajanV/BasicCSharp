using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
public enum Status{Default, Borrowed, Returned}

namespace OnlineLibraryManagement
{
    public class BorrowDetails
    {
        /*
        Properties:
•	BorrowID (Auto Increment – LB2000)
•	BookID 
•	UserID
•	BorrowedDate – ( Current Date and Time )
•	BorrowBookCount 
•	Status –  ( Enum - Default, Borrowed, Returned )
•	PaidFineAmount
        */
        private static int s_borrowID=1999;

        

        public string BorrowID { get; set; }
        public string BookID { get; set; }
        public string UserID { get; set; }
        public DateTime BoorowedDate { get; set; }
        public int BorrowBookCount { get; set; }
        public Enum Status { get; set; } 
        public int PaidFineAmount { get; set; }

        public BorrowDetails(string bookID, string userID, DateTime boorowedDate, int borrowBookCount, Enum status, int paidFineAmount)
        {
            s_borrowID++;
            BorrowID ="LB"+ s_borrowID;
            BookID = bookID;
            UserID = userID;
            BoorowedDate = boorowedDate;
            BorrowBookCount = borrowBookCount;
            Status = status;
            PaidFineAmount = paidFineAmount;
        }
    }
}