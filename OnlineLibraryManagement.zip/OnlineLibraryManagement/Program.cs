﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
namespace OnlineLibraryManagement;

public class Program{
    public static List<UserDetails> listUserDetails=new List<UserDetails>();
    public static List<BookDetails> listBookDetails=new List<BookDetails>();
     public static List<BorrowDetails> listBorrowDetails=new List<BorrowDetails>();
     public static UserDetails CurrentLoggedId;
     public static BorrowDetails BorrowCount;
    public static void Main(string[] args)
    {
        DefaultDetails();
        System.Console.WriteLine("Application For Online Library Management in Syncfusion College");
        MainMenu();

      
    }
    public static void BorrowBooks(){
        //System.Console.WriteLine("Borrowbooks");
        //1.	Show the list of Books available by printing BookID, BookName, AuthorName, BookCount.
        foreach(BookDetails book in listBookDetails ){
            System.Console.WriteLine("-----------------------------------------");
            System.Console.WriteLine(book.BookID);
            System.Console.WriteLine(book.BookName);
            System.Console.WriteLine(book.AuthorName);
            System.Console.WriteLine(book.BookCount);
            System.Console.WriteLine("-----------------------------------------");
        }
        //2.	Then Ask the user to pick one book by Asking “Enter Book ID to borrow”.
        System.Console.WriteLine("Enter the Book ID You want to borrow");
        string userInputBookID=Console.ReadLine();
        //3.	Check whether “BookID” is available or not. 
        //4.	If not available display “ Invalid Book ID, Please enter valid ID”, else ask the user to “Enter the count of the book”. 
        foreach(BookDetails book in listBookDetails ){
            bool flag1=true;
            bool flagCount=true;
            bool flagBorrowCount=true;
            if(book.BookID==userInputBookID){
                flag1=false;
                System.Console.WriteLine("How many books do You want to borrow ? ");
                int userWantBookCount=Convert.ToInt32(Console.ReadLine());
                //5.	Check the book count availability of the book
                if(book.BookCount>=userWantBookCount){
                    flagCount=false;
                    //need to check whether the user already have any borrowed book. Because user can have a maximum of only 3 borrowed books at a time. 
                    foreach(BorrowDetails borrow in listBorrowDetails){
                        if(CurrentLoggedId.UserID==borrow.UserID){

                            if(borrow.BorrowBookCount<3){
                                flagBorrowCount=false;
                                System.Console.WriteLine("Allocate this book to you");
                                borrow.Status=Status.Borrowed;
                                borrow.BoorowedDate=DateTime.Now;
                                borrow.PaidFineAmount=0;
                                borrow.BorrowBookCount+=userWantBookCount;
                                BorrowDetails b=new BorrowDetails(book.BookID, CurrentLoggedId.UserID, borrow.BoorowedDate, borrow.BorrowBookCount, borrow.Status,borrow.PaidFineAmount); 
                                System.Console.WriteLine("Succesfully Borrowed : ");
                                System.Console.WriteLine(b.BookID);
                               // System.Console.WriteLine(b.BoorowedDate);
                                //System.Console.WriteLine(b.BorrowBookCount);
                                //System.Console.WriteLine(b.BorrowID);
                            }
                            if(flagBorrowCount==true){
                                if(borrow.BorrowBookCount==3){
                                    System.Console.WriteLine("You have borrowed 3 books already”.");
                                }
                                else{
                                    System.Console.WriteLine($"You can have maximum of 3 borrowed books. Your already borrowed books count is {borrow.BorrowBookCount} and requested count is {userWantBookCount}, which exceeds 3 ”.");
                                }
                                flagBorrowCount=false;
                                
                            }
                           
                        }
                    }
                     


                }
                if(flagCount==true){
                    //5.	Check the book count availability of the book selected. 
//o	If there is no book available, display as “Books are not available for the selected count”. 
//o	And print the next available date of book by getting that book’s “BorrowedDate” from the borrowed history information and adding with 15 days  the borrowed date of that book. 
//o	Show “The book will be available on {borrowed date + 15 days}”.  
                        
                            
                            foreach(BorrowDetails borrow in listBorrowDetails){
                                
                                if(borrow.BookID==userInputBookID){
                                    System.Console.WriteLine("Books are not available for the selected count");
                                    DateTime AvailableDate=borrow.BoorowedDate.AddDays(15);
                                    System.Console.WriteLine("The book will be available on "+ AvailableDate);
                                }
                            }
                            flagCount=false;
                        



                }
            }
            if(flag1==true){
                System.Console.WriteLine("Invalid Book ID, Please enter valid ID");
                flag1=false;
            }
        }
        


    }
    public static void ShowBorrowedHistory(){
        System.Console.WriteLine("show borrowed books");
        System.Console.WriteLine("Enter UserId ");
        foreach(BorrowDetails borrow in listBorrowDetails){
            if(borrow.UserID==CurrentLoggedId.UserID){
                System.Console.WriteLine(borrow.BookID);
                System.Console.WriteLine(borrow.BoorowedDate);
                System.Console.WriteLine(borrow.BorrowBookCount);
                System.Console.WriteLine(borrow.BorrowID);
                System.Console.WriteLine(borrow.UserID);
            }
        }
    }
    public static void ReturnsBooks(){
        System.Console.WriteLine("Returns Books");
    }
    
    public static void SubMenu(){
        bool flag=true;
        do{
            System.Console.WriteLine("Enter\n1Borrowbook.\n2.ShowBorrowedhistory.\n3.ReturnBooks\n4WalletRecharge \n5.Exit");
        int subOption=Convert.ToInt32(Console.ReadLine());
        switch(subOption){
            case 1:
            {
                BorrowBooks();
                break;
            }
            case 2:
            {
                ShowBorrowedHistory();
                break;
            }
            case 3:
            {
                ReturnsBooks();
                break;
            }
            case 4:{
                WalletRecharge();
                break;
            }
            case 5:
            {
                flag=false;
                break;
            }
        }

        }while(flag==true);
        
        
    }
    public static void WalletRecharge(){

        System.Console.WriteLine("wallet Recharge");
        System.Console.WriteLine("Do you want to Recharge to your account");
        string isRecharge=Console.ReadLine();
        if(isRecharge=="yes"){
            System.Console.WriteLine("How much do you want to Recharge ? ...");
            double amount=Convert.ToInt32(Console.ReadLine());
            WalletBalance+=amount;
            System.Console.WriteLine(WalletBalance);
          

        }
        else{
            flag=false;
        }
        
    }
    public static void UserRegistration(){
        System.Console.WriteLine("Welcome to user Registration");
        
        System.Console.WriteLine("Enter UserName");
        string userName=Console.ReadLine();
        System.Console.WriteLine("Enter Your Gender");
        Gender gender=Enum.Parse<Gender>(Console.ReadLine(),true);
        System.Console.WriteLine("Enter your Department");
        Department department=Enum.Parse<Department>(Console.ReadLine(),true);
        System.Console.WriteLine("Enter your Mobile Number");
        long mobileNumber=long.Parse(Console.ReadLine());
        System.Console.WriteLine("Enter your EmailID");
        string mailID=Console.ReadLine();
        System.Console.WriteLine("Enter Your WalletBalance");
        double walletBalance=Convert.ToInt32(Console.ReadLine());
        UserDetails user1=new UserDetails(userName,gender,department,mobileNumber,mailID,walletBalance);
        listUserDetails.Add(user1);
        System.Console.WriteLine(user1.UserID);


    }
    public static void UserLogin(){
        //System.Console.WriteLine("Welcome to UserLogin");

        System.Console.WriteLine("Enter userID");
        string inputUserID=Console.ReadLine();
        foreach(UserDetails user in listUserDetails){

            if(user.UserID==inputUserID){
               CurrentLoggedId =user;
                SubMenu();
            }
        }
    }
    public static void MainMenu(){
            
            bool flag=true;
            do{
                System.Console.WriteLine("Enter\n1.UserRegistration\n2.UserLogin\n3.Exit");
            int option=Convert.ToInt32(Console.ReadLine());
                switch(option){
                case 1:
                {
                    UserRegistration();
                    break;
                }
                case 2:
                {
                    UserLogin();
                    break;
                }
                case 3:
                {
                    flag=false;
                    break;
                }
                default:
                {
                    System.Console.WriteLine("Invalid Entry Plz Try To Type Correct Input for you Process .");
                    break;
                }
            }
            }while(flag==true);
    }
    public static void DefaultDetails(){
        UserDetails user1=new UserDetails("Ravichandran",Gender.male,Department.EEE,9938388333,"ravi@gmail.com",100);
        UserDetails user2=new UserDetails("Ravichandran",Gender.male,Department.EEE,9938388333,"ravi@gmail.com",100);
        listUserDetails.Add(user1);
        listUserDetails.Add(user2);
         BookDetails book1=new BookDetails("C#","Author1",3);
        BookDetails book2=new BookDetails("HTML","Author1",3);
        BookDetails book3=new BookDetails("CSS","Author1",3);
        BookDetails book4=new BookDetails("Js","Author1",3);
        BookDetails book5=new BookDetails("TS","Author1",3);
        listBookDetails.Add(book1);
        listBookDetails.Add(book2);
        listBookDetails.Add(book3);
        listBookDetails.Add(book4);
        listBookDetails.Add(book5);
        BorrowDetails borrow1=new BorrowDetails("BID1001"	,"SF3001",	DateTime.Parse("09/10/2023"),	2,	Status.Borrowed,	0);
        listBorrowDetails.Add(borrow1);
        BorrowDetails borrow2=new BorrowDetails("BID1003"	,"SF3001",	DateTime.Parse("09/12/2023"),	1,	Status.Borrowed,	0);
        listBorrowDetails.Add(borrow2);
        BorrowDetails borrow3=new BorrowDetails("BID1004"	,"SF3001",	DateTime.Parse("09/14/2023"),	1,	Status.Borrowed,	0);
        listBorrowDetails.Add(borrow3);
        BorrowDetails borrow4=new BorrowDetails("BID1002"	,"SF3002",	DateTime.Parse("09/11/2023"),	2,	Status.Borrowed,	0);
        listBorrowDetails.Add(borrow4);
        BorrowDetails borrow5=new BorrowDetails("BID1005"	,"SF3002",	DateTime.Parse("09/09/2023"),	1,	Status.Borrowed,	0);
        listBorrowDetails.Add(borrow5);
    }

}