using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayRollManagementSystem
{
    public class AttendenceDetails
    {
        //Attendance Details Class

	//Properties:
//•	AttendanceID – AID1001
//•	EmployeeID
//•	Date
//•	CheckInTime
//•	CheckOutTime
//•	HoursWorked
    private static  int s_attendenceID=1000;

        
        public string AttendanceID { get; set; }
    public string EmployeeID { get; set; }
    public DateTime Date { get; set; }
    public DateTime CheckInTime { get; set; }
    public DateTime CheckOutTime { get; set; }
    public int HoursWorked { get; set; }
    
    public AttendenceDetails(string employeeID, DateTime date, DateTime checkInTime, DateTime checkOutTime, int hoursWorked)
        {
            s_attendenceID++;
            AttendanceID="AID"+s_attendenceID;
            EmployeeID = employeeID;
            Date = date;
            CheckInTime = checkInTime;
            CheckOutTime = checkOutTime;
            HoursWorked = hoursWorked;
        }



    }
}