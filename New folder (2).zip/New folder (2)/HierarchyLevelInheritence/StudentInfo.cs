using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchyLevelInheritence
{
    public enum Degree{
        BE,
        BSC
    }
    public enum Department{CIVIL,EEE,ECE,MECH,CSE}
    public class StudentInfo : PersonalInfo 
    {
        private static int s_studentID=7000;

        public StudentInfo(string name, string fatherName, DateTime dOB, long phone, Gender gender, string mail,Degree degree, Department department, int semester):base(name,fatherName,dOB,phone,gender,mail)
        {
            s_studentID++;
            StudentID="Student"+s_studentID;
            Degree = degree;
            Department = department;
            Semester = semester;
        }

        //Class StudentInfo inherit PersonalInfo
        //Properties: StudentID, Degree, Department, semester 
        public string StudentID { get; }
        public Degree Degree { get; set; }
        public Department Department { get; set; }
        public int Semester { get; set; }
    }
}