using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchyLevelInheritence
{
    public class Teacher:PersonalInfo
    {
        private static int s_teacherID=5000;

        /*Class Teacher Inherit PersonalInfo
Properties: TeacherID, Department, Subject teaching, Qualification, YearOfExperience, DateOfJoining
*/
        public string TeacherID { get; }
        public Department Department { get; set; }
        public string SubjectTeaching { get; set; }
        public string Qualification { get; set; }
        public int YearOfExperience { get; set; }
        public DateTime DateOfJoining { get; set; }
        public Teacher(string name, string fatherName, DateTime dOB, long phone, Gender gender, string mail,Department department, string subjectTeaching, string qualification, int yearOfExperience, DateTime dateOfJoining):base(name,fatherName,dOB,phone,gender,mail)
        {
            s_teacherID++;
            TeacherID="Teacher"+s_teacherID;
            Department = department;
            SubjectTeaching = subjectTeaching;
            Qualification = qualification;
            YearOfExperience = yearOfExperience;
            DateOfJoining = dateOfJoining;
        }
    }
}