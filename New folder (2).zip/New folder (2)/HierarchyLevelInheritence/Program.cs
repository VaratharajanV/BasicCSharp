﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace HierarchyLevelInheritence;
public class Program{
    public static void Main(string[] args)
    {
        /*
        1.	Create an application for a College Administration, create two objects for teacher, student and principal and show their info.

Class PersonalInfo:
Properties: UserID, Name, FatherName, DOB, Phone, Gender, Mail

Class Teacher Inherit PersonalInfo
Properties: TeacherID, Department, Subject teaching, Qualification, YearOfExperience, DateOfJoining

Class StudentInfo inherit PersonalInfo
Properties: StudentID, Degree, Department, semester 

Class PrincipalInfo inherit PersonalInfo
Properties: PrincipalID, Qualification, YearOfExperience, DateOfJoining

Requirement: Need to create 2 objects each for the above classes (ID’s are auto incremented) and must display the details in Program.cs

        */
        PersonalInfo person1=new PersonalInfo("raja","venkatesan",new DateTime(04/07/2002),725272,Gender.male,"varatharajan60782@gmail.com");
        PersonalInfo person2=new PersonalInfo("raju","velpandian",new DateTime(05/07/2002),725271,Gender.male,"rajan60782@gmail.com")
        ;StudentInfo student1=new StudentInfo(person1.Name,person1.FatherName,person1.DOB,person1.Phone,person1.Gender,person1.Mail,Degree.BE,Department.CIVIL,8);
        ;StudentInfo student2=new StudentInfo(person2.Name,person2.FatherName,person2.DOB,person2.Phone,person2.Gender,person2.Mail,Degree.BE,Department.MECH,8);
        Teacher teacher1=new Teacher("mam","mam father",new DateTime(09/09/2000),712621,Gender.female,"shfss@",Department.ECE,"beee","MTECH",4,new DateTime(09/09/2006));
        Teacher teacher2=new Teacher("mam","mam father",new DateTime(09/09/2000),712621,Gender.female,"shfss@",Department.ECE,"beee","MTECH",4,new DateTime(09/09/2006));
        ;PrincipleInfo principle1=new PrincipleInfo("haja","wdhhg",new DateTime(09/08/1970),2782652,Gender.male,"vsjhsf@","PHD",20,new DateTime(01/01/2000));
        ;PrincipleInfo principle2=new PrincipleInfo("haja","wdhhg",new DateTime(09/08/1970),2782652,Gender.male,"vsjhsf@","PHD",20,new DateTime(01/01/2000));
        System.Console.WriteLine(person1.UserID);
        System.Console.WriteLine(person2.UserID);
        System.Console.WriteLine(student1.UserID);
        System.Console.WriteLine(student1.StudentID);

        System.Console.WriteLine(student2.UserID);
        System.Console.WriteLine(student2.StudentID);
        System.Console.WriteLine(teacher1.UserID);
        System.Console.WriteLine(teacher1.TeacherID);
        System.Console.WriteLine(teacher2.UserID);
        System.Console.WriteLine(teacher2.TeacherID);
        System.Console.WriteLine(principle1.UserID);
        System.Console.WriteLine(principle1.PrincipleID);
        System.Console.WriteLine(principle2.UserID);
         System.Console.WriteLine(principle2.PrincipleID);
    }
}