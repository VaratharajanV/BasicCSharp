using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchyLevelInheritence
{
    public enum Gender{
        male,
        female,
        transgrander
    }
    public class PersonalInfo
    {
       private static int s_userID=100;

        public string UserID { get; }
        public string Name { get; set; }
        public string FatherName { get; set; }
        public DateTime DOB { get; set; }
        public long Phone { get; set; }
        public Gender Gender { get; set; }
        public string Mail { get; set; }
        //Properties: UserID, Name, FatherName, DOB, Phone, Gender, Mail
         public PersonalInfo(string name, string fatherName, DateTime dOB, long phone, Gender gender, string mail)
        {
            s_userID++;
            UserID="SF"+s_userID;
            Name = name;
            FatherName = fatherName;
            DOB = dOB;
            Phone = phone;
            Gender = gender;
            Mail = mail;
        }
    }
}