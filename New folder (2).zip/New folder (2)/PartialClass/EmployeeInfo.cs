using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialClass
{
    public enum Gender{male,female,transgender}
    
    public partial class EmployeeInfo
    {
        //EmployeeID,Name,Gender,DOB, Mobile and Declare partial method -> Update
        private static int s_employeeID=1000;

        public EmployeeInfo(Gender gender, DateTime dOB, long mobile)
        {
            s_employeeID++;
            EmployeeID="EMP"+s_employeeID;
            Gender = gender;
            DOB = dOB;
            Mobile = mobile;
        }

        public string EmployeeID { get; set; }
        public Gender Gender { get; set; }
        public DateTime DOB { get; set; }
        public long Mobile { get; set; }

        public string Update(){
                string UpdatedInformation=EmployeeID+" "+Gender+" "+DOB+" "+Mobile;
                return UpdatedInformation;
        }
       
    }
}