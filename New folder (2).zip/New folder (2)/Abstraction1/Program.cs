﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
namespace Abstraction1;
public class Program{
    /*1.	Create application for calculate area and volume of different shapes

Abstract class Shape
Abstract Properties: Area, Volume
Non abstract properties: Radius, Height, Width, Page - a
Abstract methods: CalculateArea, CalculateVolume

Class Cylinders inherit Shape
Overridden methods: CalculateArea - 2 π r(r+h) , CalculateVolume π r2 h

Class Cubes inherit Shape
Overridden methods: CalculateArea -  6a2 , CalculateVolume - a3 

Requirement : Create two objects for cylinder and cube and calculate area and volume of both and display the details.

    */


   
    
    public static void Main(string[] args)
    {
        Cylinders cylinders=new Cylinders(4,2,3,5,1,1);
        cylinders.CalculateArea();
        System.Console.WriteLine(cylinders.Area);
        cylinders.CalculateVolume();
        System.Console.WriteLine(cylinders.Volume);
        Cylinders cylinders1=new Cylinders(4.2,2.8,3.7,5.1,1.9,1.3);
        cylinders1.CalculateArea();
        System.Console.WriteLine(cylinders1.Area);
         cylinders1.CalculateVolume();
        System.Console.WriteLine(cylinders1.Volume);

        Cube cube=new Cube(2,3,4,5,1,1);
        ;
        System.Console.WriteLine(cube.CalculateArea());
       
        System.Console.WriteLine( cube.CalculateVolume());

        
    }
    
    
}
