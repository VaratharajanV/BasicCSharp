using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Abstraction1
{
    public class Cylinders:Shape
    {
       

        //Class Cylinders inherit Shape
        //Overridden methods: CalculateArea - 2 π r(r+h) , CalculateVolume π r2 h

        public override double Area { get;set; }
        public override double Volume { get;set; }
         public Cylinders(double radius,double height,double width,double a,double area, double volume)
        {
            Area = area;
            Volume = volume;
            
        }
        public override double CalculateArea()
        {
            //throw new NotImplementedException();
            
            Area=2*3.14*Radius*(Radius+Height);
            return Area;

        }
        public override double CalculateVolume()
        {
           // throw new NotImplementedException();
           Volume=3.14*Math.Pow(Radius,2)*Height;
           return Volume;
        }

    }
}
