using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SingleInheritence
{
    public enum BranchName{Kilpauck,Chetpet,AnnaNagar}
    public class AccountInfo:PersonalInfo
    {
       private static int s_accountID=1000;
       private double _balance;
    
      // private static int s_userID=1000;
       

        /*Class AccountInfo : Inherit PersonalInfo
Properties: AccountNumber, BranchName, IFSCCode, Balance
Methods: Deposit , Withdraw
*/
        public string AccountID { get; }
       // ublic string UserID{get;set;}
        public string AccountNumber { get; set; }
       public BranchName BranchName { get; set; }
       public string IFSCCode { get; set; }
       public double Balance { get{return _balance;} }
       //public string UserID { get; set; }
        public AccountInfo(string userID,string name, string fatherName, long phone, string mail, DateTime dOB, Gender gender,string accountNumber, BranchName branchName, string iFSCCode, double balance):base(userID,name,fatherName,phone,mail,dOB,gender)
        {
            s_accountID++;
            AccountID="AX"+s_accountID;
            //UserID=userID;
            AccountNumber = accountNumber;
            BranchName = branchName;
            IFSCCode = iFSCCode;
            _balance = balance;
        }

        public void Deposit(double amount){
            _balance+=amount;

        }
        public void Withdraw(double amount){
            _balance-=amount;
        }
      
    }
}