using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SingleInheritence4
{
    public enum Gender{male,female,transgender}
public enum Branch{AnnaNagar,Chetpet,NungamPakkam}
    public class EmployeeInfo:Salary
    {
        private static int s_employeeID=1000;


        //Properties: EmployeeID, Name,FatherName,Gender,Mobile,DOB, Branch,
        public string EmployeeID { get;}
        public string Name { get; set; }
        public string FatherName { get; set; }
        public Gender Gender { get; set; }
        public long Mobile { get; set; }
        public DateTime DOB { get; set; }
        public Branch Branch { get; set; }

        public EmployeeInfo(DateTime date, int numberOfHoursWorked,double salaryOfTheMonth, int month,string name, string fatherName, Gender gender, long mobile, DateTime dOB, Branch branch):base(date,numberOfHoursWorked,salaryOfTheMonth,month)
        {
            s_employeeID++;
            EmployeeID="EM"+s_employeeID;
            Name = name;
            FatherName = fatherName;
            Gender = gender;
            Mobile = mobile;
            DOB = dOB;
            Branch = branch;
        }

        public static void LogAttendance(){

        }

    }
}