using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SingleInheritence4
{
    public class Salary:Attendence
    {
        /*Class SalaryInfo  
Properties: SalaryID, SalaryOfTheMonth, Month
Method: CalculateSalary-> for given month  
        */
        private static int s_salaryID=2000;

       public string SalaryID { get;  }

        public  double SalaryOfTheMonth { get; set; }
        public int Month { get; set; }
         public Salary(DateTime date, int numberOfHoursWorked,double salaryOfTheMonth, int month):base(date,numberOfHoursWorked)
        {
            s_salaryID++;
            SalaryID="SA"+s_salaryID;
            SalaryOfTheMonth = salaryOfTheMonth;
            Month = month;
        }

        public static void CalculateSalary(int month){
            
            

        }
    }
}