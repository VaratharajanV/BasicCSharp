using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SingleInheritenceOnlineLibrary
{
    public class BookInfo:DepartmentDetails
    {
        private static int s_bookId=5000;

       

        //Properties: BookID, BookName, AuthorName, Price
        public string BookId { get;}
        public string BookName { get; set; }
        public string  AuthorName { get; set; }
        public double Price { get; set; }
         public BookInfo(string depID,string departmentName, string degree,string bookName, string authorName, double price):base(depID,departmentName,degree)
        {
           // DepartmentID=depID;
            s_bookId++;
            BookId="BOOK"+s_bookId;
            BookName = bookName;
            AuthorName = authorName;
            Price = price;
        }
        
    }
}