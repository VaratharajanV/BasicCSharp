using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SingleInheritenceOnlineLibrary
{
    public class DepartmentDetails
    {
        private static int s_departmentID=1000;

       

        //Properties: DepartmentID, DepartmentName, Degree
        public string DepartmentID { get;}
        public string DepartmentName { get; set; }
        public string Degree { get; set; }

         public DepartmentDetails(string departmentName, string degree)
        {
            s_departmentID++;
            DepartmentID="DEP"+s_departmentID;
            DepartmentName = departmentName;
            Degree = degree;
        }
         public DepartmentDetails(string departmentID,string departmentName, string degree)
        {
            DepartmentID=departmentID;
            DepartmentName = departmentName;
            Degree = degree;
        }
    }
}