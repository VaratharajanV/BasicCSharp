using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbstractMethod1
{
    public class SuzukiCiaz:Car
    {
        /*class SuzukiCiaz: inherit Cars
override methods: get engine type, get no. of seats, get price, get car type
        */

         public SuzukiCiaz(EngineType engineType, int noOfSeats, double price, CarType carType):base(engineType,noOfSeats,price,carType){
             EngineType = engineType;
            NoOfSeats = noOfSeats;
            Price = price;
            CarType = carType;
            //MyProperty = myProperty;
        }

        public override EngineType GetEngineType()
        {
            //throw new NotImplementedException();
            return EngineType;
        }
        public override int GetNoSeats(){
            return NoOfSeats;
        }
        public override double GetPrice(){
            return Price;
        }
        public override CarType GetCarType(){
            return CarType;
        }   
    }
}