﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography.X509Certificates;
namespace SyncKart;
class Program
{
    public static List<CustomerDetails> customerList = new List<CustomerDetails>();
    public static List<ProductDetails> productList = new List<ProductDetails>();
    public static List<OrderDetails> orderList = new List<OrderDetails>();
    static CustomerDetails CurrentCustomer;
    public static void Main(string[] args)
    {
        LoadDefaultData();

        string flag = "yes";
        do
        {
            System.Console.WriteLine("Enter\n 1.registration \n 2.Login \n 3.Exit");
            int option = Convert.ToInt32(Console.ReadLine());
            switch (option)
            {
                case 1:
                    {
                        CustomerRegistration();
                        break;
                    }
                case 2:
                    {
                        Login();

                        break;
                    }
                case 3:
                    {
                        flag = "no";
                        System.Console.WriteLine("Thank You ...! ");
                        break;
                    }
                default:
                    {
                        Console.WriteLine("OOPS ! Invalid Option selected");

                        break;
                    }

            }
            //System.Console.WriteLine("Again you want to continue press 'yes' or else press 'no' . ");
            //flag=Console.ReadLine().ToLower();

        } while (flag == "yes");


    }
    public static void CustomerRegistration()
    {
        //System.Console.WriteLine("Customer Registration method called .");
        //get the details
        System.Console.WriteLine("Plz Enter Your Name");
        string customerName = Console.ReadLine();
        System.Console.WriteLine("Plz Enter your City");
        string city = Console.ReadLine();
        System.Console.WriteLine("Plz Enter your Mobile Number");
        long mobileNumber = Convert.ToUInt32(Console.ReadLine());
        System.Console.WriteLine("Plz Enter Wallet Balance");
        double walletBalance = Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("Plz Enter EmailID");
        string emailID = Console.ReadLine();
        //create the object
        CustomerDetails customer = new CustomerDetails(customerName, city, mobileNumber, walletBalance, emailID);

        //add this into list
        customerList.Add(customer);

        System.Console.WriteLine("Customer Details are stored via Registration .Your Customer ID is : " + customer.CustomerID);


    }
    public static void Login()
    {
        //System.Console.WriteLine("Customer Login method called .");
        //get the customerID
        System.Console.WriteLine("Enter your customer Id : ");
        string ID = Console.ReadLine();
        bool flag2=true;

        //validate the id
        foreach (CustomerDetails customer in customerList)
        {
            if (ID.Equals(customer.CustomerID))
            {
                flag2=false;
                //System.Console.WriteLine("Display SubMenu");
                CurrentCustomer = customer;
                SubMenu();
            }
        }
        if(flag2){
        System.Console.WriteLine("Customer ID is not found .So try to create Registration ////first");
        }
    }

    public static void SubMenu()
    {
        bool flag3 = true;
        //System.Console.WriteLine("SubMenu method called .");
        do
        {
            System.Console.WriteLine("Enter \n 1 purchase \n 2 orderhistory\n 3 cancelOrder\n 4 walletBalance \n5 wallet recharge \n 6 exit ");
            int input1 = Convert.ToInt32(Console.ReadLine());

            switch (input1)
            {
                case 1:
                    {
                        purchase();
                        break;
                    }
                case 2:
                    {
                        OrderHistory();
                        break;
                    }
                case 3:
                    {
                        CancelOrder();
                        break;
                    }
                case 4:
                    {
                        System.Console.WriteLine("Your Wallet Current Balance : "+CurrentCustomer.WalletBalance);
                        break;
                    }
                case 5:
                    {
                        WalletRecharge();
                        
                        break;
                    }
                case 6:
                    {
                        flag3 = false;
                        break;

                    }
                default:
                    {
                        System.Console.WriteLine(" OOOPS ....!!!!! unavailable Try to Type Correct Input ");
                        break;
                    }
            }

        } while (flag3 == true);

    }
    public static void WalletRecharge()
    {
        System.Console.WriteLine("After Recharge your current Blance is :" + CurrentCustomer.WalletBalance);
        System.Console.WriteLine("Enter the amount you wat to add ");
        double amount=Convert.ToInt32(Console.ReadLine());
        CurrentCustomer.WalletRecharge(amount);
        System.Console.WriteLine("After Recharge your current Blance is : "+CurrentCustomer.WalletBalance);
    }

    public static void purchase()
    {

        //Display the product details
        foreach (ProductDetails product1 in productList)
        {
            Console.WriteLine("ProductID : " + product1.ProductID);
            Console.WriteLine("productName : " + product1.ProductName);
            Console.WriteLine("product stock :" + product1.Stock);
            Console.WriteLine("product price : " + product1.Price);
            Console.WriteLine("product shippingDuration : " + product1.ShippingDuration);
            Console.WriteLine();

        }
        //get the productID to be purchsed from the customer
        System.Console.WriteLine("Enter the productID which one you want to buy");
        string PID = Console.ReadLine();
        bool flag=true;
        foreach (ProductDetails product in productList)
        {
            
            //validate the productID
            if (PID == product.ProductID)
            {
                flag=false;
                //if valid get the quantity from the customer
                System.Console.WriteLine("Quantity of the product which you want ");
                int count = Convert.ToInt32(Console.ReadLine());
                //validate ensure the stock availability
                if (count <= product.Stock)
                {
                    //calculate totalPrice
                    double TotalAmount = (count * product.Price) + 50;


                    System.Console.WriteLine("Total Amount you need to be pay :  "+TotalAmount);
                    //validate walletbalance
                    if (TotalAmount   <=  CurrentCustomer.WalletBalance)
                    {
                        //deduct the total amount from the customer wallet 
                        CurrentCustomer.DeductBalance(TotalAmount);
                        System.Console.WriteLine("Your Current Balance is : "+CurrentCustomer.WalletBalance);
                        //reduce purchase count from the product stock 
                        product.Stock -= count;
                        //create orderr object
                        OrderDetails order = new OrderDetails(CurrentCustomer.CustomerID, product.ProductID, TotalAmount, DateTime.Now, product.Stock, OrderStatus.Ordered);
                        string StoreOrderID = order.OrderID;
                        DateTime StorePurchaseDate = order.PurchaseDate;
                        orderList.Add(order);
                        //place the order
                        //Show success message . Display the order details with id and delivery date
                        System.Console.WriteLine($"Your ordered is confirmed : {StoreOrderID} and your delivery time is {StorePurchaseDate.AddDays(product.ShippingDuration)}");
                    }
                    else{
                        System.Console.WriteLine("Insufficient Wallet Balance. Please recharge your wallet and do purchase again");

                        //CurrentCustomer.WalletRecharge(TotalAmount);
                        //System.Console.WriteLine("Your Wallet Balance is : "+CurrentCustomer.WalletBalance);
                    }
                }
                else{
                    System.Console.WriteLine($"Required count not available. Current availability is {product.Stock}");
                }
            }
        }if(flag){
            System.Console.WriteLine("Invalid ProductID");
        }
    }
    
    public static void CancelOrder()
    {
        
        //Display the order details of the current logged in user which order details is order

        
        //validate the orderid customerid and the orderstatus 
        //refund the amount to the customer
        foreach(OrderDetails order in orderList){

            if(CurrentCustomer.CustomerID==order.CustomerID )
            {
                if(order.OrderStatus==OrderStatus.Ordered)
                {

                
            System.Console.WriteLine("Order Id : "+order.OrderID);
            System.Console.WriteLine(" Customer ID : "+order.CustomerID);
            System.Console.WriteLine(" Product ID : "+order.ProductID);
            System.Console.WriteLine("TotalPrice : "+order.TotalPrice);
            System.Console.WriteLine(" PurchaseDate : "+order.PurchaseDate);
            System.Console.WriteLine("Quantity : "+order.Quantity);
            System.Console.WriteLine("Order Status : "+order.OrderStatus);
            System.Console.WriteLine();
                }
            }
            
        }
        System.Console.WriteLine("Enter the orderID that You Want to Cancel");
        //get the order id from the customer
        string UserCancelId=Console.ReadLine();
        bool flag2=true;
        foreach(OrderDetails order in orderList){
            if(UserCancelId==order.OrderID){
                flag2=false;
                 if(order.OrderStatus==OrderStatus.Ordered){
                    
                    foreach(ProductDetails product in productList){
                        if(order.ProductID==product.ProductID){
                            product.Stock+=order.Quantity;
                            double TotalAmount=order.TotalPrice-50;
                            CurrentCustomer.WalletRecharge(TotalAmount);
                            order.OrderStatus=OrderStatus.Cancelled;
                            Console.WriteLine("your order had been cancelled "+order.OrderID +" and your Current Blance is : "+CurrentCustomer.WalletBalance);
                        }
                    }
            }
           
                

        }
        if(flag2){
            System.Console.WriteLine("Invalid OrderId You Entered ");
        }
        }
        
        //
    }
   


    public static void LoadDefaultData()

    {
        /*
        PID101	Mobile (Samsung)	10	10000	3
PID102	Tablet (Lenovo)	5	15000	2
PID103	Camara (Sony)	3	20000	4
PID104	iPhone 	5	50000	6
PID105	Laptop (Lenovo I3)	3	40000	3
PID106	HeadPhone (Boat)	5	1000	2
PID107	Speakers (Boat)	4	500	2

        */

        ProductDetails product1 = new ProductDetails("Mobile (Samsung)", 10, 10000, 3);
        ProductDetails product2 = new ProductDetails("Tablet (Lenovo)", 5, 15000, 2);
        ProductDetails product3 = new ProductDetails("Camara (Sony)", 3, 20000, 4);
        ProductDetails product4 = new ProductDetails("iPhone ", 5, 50000, 6);
        ProductDetails product5 = new ProductDetails("Laptop (Lenovo I3)", 3, 40000, 3);
        ProductDetails product6 = new ProductDetails("HeadPhone (Boat)", 5, 1000, 2);
        ProductDetails product7 = new ProductDetails("Speakers (Boat)", 4, 500, 2);
        
        productList.Add(product1);
        productList.Add(product2);
        productList.Add(product3);
        productList.Add(product4);
        productList.Add(product5);
        productList.Add(product6);
        productList.Add(product7);

        /*
        Customer ID	Name 	City	Mobile	Balance	Mail
CID1001	Ravi	Chennai	9885858588	50000	ravi@mail.com
CID1002	Baskaran	Chennai	9888475757	60000	baskaran@mail.com
        */
        CustomerDetails customer1 = new CustomerDetails("Ravi", "Chennai", 9885858588, 50000, "ravi@mail.com");
        CustomerDetails customer2 = new CustomerDetails("Baskaran", "Chennai", 9888475757, 60000, "baskaran@mail.com");
        
        customerList.Add(customer1);
        customerList.Add(customer2);


        /*
        Order ID	Customer ID	ProductID	TotalPrice	Purchase Date	Quantity Purchased	Order Status
OID1001	CID1001	PID101	20000	DateTime.Now	2	Ordered
OID1002	CID1002	PID103	40000	DateTime.Now	2	Ordered
        */
        OrderDetails order1 = new OrderDetails("CID1001", "PID101", 20000, DateTime.Now, 2, OrderStatus.Ordered);
        OrderDetails order2 = new OrderDetails("CID1002", "PID103", 40000, DateTime.Now, 2, OrderStatus.Ordered);
       
        orderList.Add(order1);
        orderList.Add(order2);

    }


    

    public static void OrderHistory(){
        foreach(OrderDetails order in orderList){

            if(CurrentCustomer.CustomerID==order.CustomerID){
            System.Console.WriteLine("Order Id : "+order.OrderID);
            System.Console.WriteLine(" Customer ID : "+order.CustomerID);
            System.Console.WriteLine(" Product ID : "+order.ProductID);
            System.Console.WriteLine("TotalPrice : "+order.TotalPrice);
            System.Console.WriteLine(" PurchaseDate : "+order.PurchaseDate);
            System.Console.WriteLine("Quantity : "+order.Quantity);
            System.Console.WriteLine("Order Status : "+order.OrderStatus);
            System.Console.WriteLine();
            }
            
        }
    }
}

