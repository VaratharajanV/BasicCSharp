using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

public enum Gender { Male, Female, Transgender }

namespace StudentsAdmission
{
    public class StudentDetails
    {

        private static int s_studentID = 2999;



        //properties
        public string StudentID { get; }
        public string StudentName { get; set; }
        public string FatherName { get; set; }
        public DateTime DOB { get; set; }
        public Gender Gender { get; set; }
        public int Physics { get; set; }
        public int Chemistry { get; set; }
        public int Maths { get; set; }

        //Constructor
        public StudentDetails(string studentName, string fatherName, DateTime dOB, Gender gender, int physics, int chemistry, int maths)
        {
            s_studentID++;
            StudentID = "SF" + s_studentID;
            StudentName = studentName;
            FatherName = fatherName;
            DOB = dOB;
            Gender = gender;
            Physics = physics;
            Chemistry = chemistry;
            Maths = maths;
        }




        public bool CheckEligibility(double cutoff)
        {
            double average = Physics + Chemistry + Maths;
            if (average >= cutoff)
            {
                return true;
            }
            else
            {
                return false;
            }
        } 
    }
}