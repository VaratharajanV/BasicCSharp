﻿using Microsoft.AspNetCore.Mvc;
using ProductList.Models;
using ProductList.Models.Irepository;

namespace ProductList.Controllers
{
    public class ProductController : Controller
    {
        private  IProduct _productRepository;

        public ProductController(IProduct productRepository)
        {
            _productRepository = productRepository;
        }
        public IActionResult Index()
        {
            var products = _productRepository.GetAll();
            return View(products);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Product product)
        {
          //productRepository.Add(product);
            
            if (ModelState.IsValid)
            {
                var Newproduct = new Product()
                {
                    Name = product.Name,
                    Price = product.Price,
                };
                _productRepository.Add(Newproduct);
                return RedirectToAction("Index", new {Id=Newproduct.ProductId});
            }
           
            return View(product);
        }
        public IActionResult Edit(int id)
        {
            var product = _productRepository.GetById(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }
        [HttpPost]
        public IActionResult Edit(int id, Product updatedProduct)
        {
            var existingProduct = _productRepository.GetById(id);
            if (existingProduct == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                existingProduct.Name = updatedProduct.Name;
                existingProduct.Price = updatedProduct.Price;
                _productRepository.Update(existingProduct);
                return RedirectToAction("Index");
            }

            return View(updatedProduct);
        }
       
        public IActionResult Delete(int id)
        {
            var product = _productRepository.GetById(id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }
        [HttpPost]
        [Route("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
           // var existingProduct = _productRepository.GetById(id);
            _productRepository.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
