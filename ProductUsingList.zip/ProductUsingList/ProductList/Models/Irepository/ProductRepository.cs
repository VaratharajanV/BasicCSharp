﻿
using Microsoft.AspNetCore.Http.HttpResults;

namespace ProductList.Models.Irepository
{
    public class ProductRepository : IProduct
    {
        private readonly List<Product> _products;
        public ProductRepository()
        {
            _products = new List<Product>
        {
            new Product(1,"Mary Gold",20.8),
            new Product(2,"Dark Fantasy",30.67)
        };
        }
        public void Add(Product product)
        {
            product.ProductId = _products.Count + 1;
            _products.Add(product);
        }

        public void Delete(int id)
        {
            var product = _products.FirstOrDefault(p => p.ProductId == id);
            if (product != null)
            {
                _products.Remove(product);
            }
        }

       

        public IEnumerable<Product> GetAll()
        {
            return _products;
        }

        public Product GetById(int id)
        {
            return _products.FirstOrDefault(p => p.ProductId == id);


        }

        public void Update(Product product)
        {
            var existingProduct = _products.FirstOrDefault(p => p.ProductId == product.ProductId);
            if (existingProduct != null)
            {
                existingProduct.Name = product.Name;
                existingProduct.Price = product.Price;
            }

        }
    }
}
